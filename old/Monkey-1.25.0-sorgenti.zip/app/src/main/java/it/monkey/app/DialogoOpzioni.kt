package it.monkey.app

/*
 * Subito+ — pannello "Opzioni"
 * v1.24.0 (2026-08-31) — nuovo.
 *
 * Primo pezzo di un menu pensato per crescere: oggi una sola voce, ma il
 * dialogo e AzioniOpzioni sono gia' fatti per accoglierne altre senza
 * riscrivere la struttura (una Column con dentro tante sezioni, non un
 * singolo controllo isolato). Stessa forma di DialogoRicerche: un AlertDialog
 * invece di un foglio dal basso, per lo stesso motivo — la barra dei comandi
 * vive in una ComposeView alta poche decine di pixel.
 *
 * Prima voce: cosa fare all'avvio. Da sempre (v1.17.0) l'app riparte da sola
 * sull'ultima ricerca fatta se il processo e' stato chiuso — comodo per chi
 * cerca sempre la stessa cosa, fastidioso per chi preferisce vedere prima le
 * ultime proposte (la home). Ora e' una scelta, non un comportamento fisso.
 */

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Le azioni che il pannello Opzioni puo' scatenare. Una per voce. */
class AzioniOpzioni(
    /** true = all'avvio vai alla home; false = riprendi l'ultima ricerca. */
    val cambiaAvvioHome: (Boolean) -> Unit
)

@Composable
fun DialogoOpzioni(
    avvioHome: Boolean,
    azioni: AzioniOpzioni,
    chiudi: () -> Unit
) {
    AlertDialog(
        onDismissRequest = chiudi,
        confirmButton = { TextButton(onClick = chiudi) { Text("Chiudi") } },
        title = { Text("Opzioni") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "All'avvio",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                VoceScelta(
                    testo = "Riprendi l'ultima ricerca",
                    selezionata = !avvioHome,
                    onClick = { azioni.cambiaAvvioHome(false) }
                )
                VoceScelta(
                    testo = "Vai alla home (le tue ultime proposte)",
                    selezionata = avvioHome,
                    onClick = { azioni.cambiaAvvioHome(true) }
                )
            }
        }
    )
}

/** Una riga radio-button + testo, tutta cliccabile. */
@Composable
private fun VoceScelta(testo: String, selezionata: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .selectable(selected = selezionata, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selezionata, onClick = onClick)
        Text(testo, style = MaterialTheme.typography.bodyMedium)
    }
}
