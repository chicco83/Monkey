package it.zecchi.subitoplus

/*
 * Subito+ — motore della ricerca unificata
 * v0.4.0 (2026-08-30) — nuovo, Fase 3
 *
 * PERCHE' PASSA DAL WEBVIEW
 * Le due piattaforme non rispondono a un client HTTP scritto a mano: Akamai
 * davanti a Subito, protezioni analoghe davanti a Vinted. Qui la chiamata parte
 * da DENTRO una pagina della fonte, con la sua sessione e i suoi cookie, con
 * una fetch identica a quelle che fa il sito. Non sostituiamo nulla: chiamiamo.
 *
 * Ogni fonte ha un WebView proprio, tenuto fuori schermo, che ospita la sessione.
 */

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MotoreRicerca(
    private val ctx: Context,
    private val nomePonte: String,
    /** Contenitore in cui agganciare le sessioni con dimensione 1x1:
     *  un WebView mai attaccato puo' comportarsi in modo diverso fra versioni. */
    private val ancora: android.view.ViewGroup? = null
) {
    interface Ascoltatore {
        fun risultati(fonte: String, annunci: List<Annuncio>, diagnostica: String)
        fun errore(fonte: String, messaggio: String)
    }

    private val ui = Handler(Looper.getMainLooper())
    private val sessioni = HashMap<String, WebView>()
    private val pronte = HashMap<String, Boolean>()
    private val inAttesa = HashMap<Int, Fonte>()
    private var contatore = 1
    var ascoltatore: Ascoltatore? = null

    /** Diagnostica dell'ultima ricerca: URL usati, stato, conteggi, chiavi trovate. */
    val diagnostica = StringBuilder()

    private fun sessione(f: Fonte): WebView {
        sessioni[f.nome]?.let { return it }
        val w = WebView(ctx)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.addJavascriptInterface(PonteRicerca(), nomePonte)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                w, Prologo.script(nomePonte),
                setOf("https://*.subito.it", "https://subito.it",
                      "https://*.vinted.it", "https://vinted.it")
            )
        }
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { pronte[f.nome] = true }
        }
        pronte[f.nome] = false
        ancora?.addView(w, android.view.ViewGroup.LayoutParams(1, 1))
        w.loadUrl(f.origine)
        sessioni[f.nome] = w
        return w
    }

    /** Scalda le sessioni senza cercare nulla: rende immediata la prima ricerca. */
    fun prepara(fonti: List<Fonte>) = fonti.forEach { sessione(it) }

    fun cerca(q: String, pagina: Int, ordine: String, fonti: List<Fonte>) {
        if (pagina == 1) diagnostica.setLength(0)
        fonti.forEach { f -> avvia(f, q, pagina, ordine, 0) }
    }

    private fun avvia(f: Fonte, q: String, pagina: Int, ordine: String, tentativo: Int) {
        val w = sessione(f)
        if (pronte[f.nome] != true) {
            // La pagina della fonte non e' ancora caricata: si riprova a breve.
            if (tentativo > 40) { ascoltatore?.errore(f.nome, "sessione non pronta"); return }
            ui.postDelayed({ avvia(f, q, pagina, ordine, tentativo + 1) }, 400)
            return
        }
        val id = contatore++
        inAttesa[id] = f
        val url = f.url(q, pagina, ordine)
        diagnostica.append("[${f.nome}] $url\n")

        /*
         * Due tentativi. Il primo con i cookie ("include"): serve alle risposte
         * personalizzate. Se la fonte espone CORS con Allow-Origin generico,
         * quel tentativo viene rifiutato dal browser, e il secondo — senza
         * credenziali — passa. Meglio due tentativi che una regola sbagliata.
         */
        val js = """
        (function(){
          var U = '${url.replace("'", "\\'")}';
          var H = {'Accept':'application/json'};
          function consegna(s, t){ try { window['$nomePonte'].risultatoRicerca($id, s, t); } catch(e){} }
          function prova(opz, ripiego){
            try {
              fetch(U, opz)
                .then(function(r){ return r.text().then(function(t){ consegna(r.status, t); }); })
                .catch(function(e){ if (ripiego) ripiego(); else consegna(-1, String(e)); });
            } catch(e) { if (ripiego) ripiego(); else consegna(-2, String(e)); }
          }
          prova({credentials:'include', headers:H}, function(){ prova({headers:H}, null); });
        })();
        """.trimIndent()
        w.evaluateJavascript(js, null)

        ui.postDelayed({
            if (inAttesa.remove(id) != null) ascoltatore?.errore(f.nome, "nessuna risposta entro 20 s")
        }, 20000)
    }

    inner class PonteRicerca {
        @android.webkit.JavascriptInterface
        fun risultatoRicerca(id: Int, stato: Int, corpo: String) {
            val f = inAttesa.remove(id) ?: return
            ui.post {
                if (stato != 200) {
                    diagnostica.append("[${f.nome}] stato $stato — ${corpo.take(200)}\n")
                    ascoltatore?.errore(f.nome, "risposta $stato")
                    return@post
                }
                try {
                    val lista = f.leggi(corpo)
                    val chiavi = try { f.chiavi(corpo) } catch (t: Throwable) { "-" }
                    diagnostica.append("[${f.nome}] ${lista.size} annunci · campi: $chiavi\n")
                    ascoltatore?.risultati(f.nome, lista, chiavi)
                } catch (t: Throwable) {
                    diagnostica.append("[${f.nome}] lettura fallita: ${t.message} — ${corpo.take(300)}\n")
                    ascoltatore?.errore(f.nome, "risposta non interpretabile")
                }
            }
        }
    }

    fun chiudi() {
        sessioni.values.forEach { it.destroy() }
        sessioni.clear(); pronte.clear()
    }
}
