package it.zecchi.subitoplus

/*
 * Subito+ — stato della ricerca unificata
 * v0.5.2 (2026-08-30) — Fase 4, punto 2
 *
 * Separa il "cosa" dal "come si vede": qui vivono la richiesta in corso, i
 * risultati, i filtri e gli errori; la schermata (SchermataRicerca) si limita
 * a disegnarli. E' quello che rende possibile aggiungere una fonte o un filtro
 * senza toccare l'interfaccia, e viceversa.
 *
 * Sostituisce la parte di stato che stava dentro VistaRicerca.kt (viste
 * tradizionali, v0.4.0 - v0.5.1), rimosso in questa versione.
 */

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class StatoRicerca(
    private val ctx: Context,
    private val motore: MotoreRicerca,
    /** Chiamata quando cambia il fatto che ci sia o meno un caricamento in corso. */
    private val caricamento: (Boolean) -> Unit
) {
    // ---- richiesta ----
    var query by mutableStateOf("")
    var ultimaQuery by mutableStateOf("")
        private set
    private var pagina = 1
    private var attesa = 0
    var inCorso by mutableStateOf(false)
        private set
    var primaRicercaFatta by mutableStateOf(false)
        private set
    /** Vero quando una pagina non ha portato nulla di nuovo: inutile chiederne altre. */
    var esaurito by mutableStateOf(false)
        private set
    private var dimensionePrima = 0

    // ---- risultati ----
    private val grezzi = mutableStateListOf<Annuncio>()
    val errori = mutableStateMapOf<String, String>()
    val conteggi = mutableStateMapOf<String, Int>()

    // ---- filtri ----
    var usaSubito by mutableStateOf(true)
    var usaVinted by mutableStateOf(true)
    var ordine by mutableStateOf(0)          // 0 recenti, 1 prezzo cresc., 2 prezzo decr.
    var etaModo by mutableStateOf(0)         // 0 qualsiasi, 1 piu' vecchi di, 2 piu' recenti di
    var giorni by mutableStateOf("30")
    var prezzoMin by mutableStateOf("")
    var prezzoMax by mutableStateOf("")
    var mostraVenduti by mutableStateOf(false)

    /** Ricerche recenti, conservate fra un avvio e l'altro. */
    var recenti by mutableStateOf(caricaRecenti())
        private set

    init {
        motore.ascoltatore = object : MotoreRicerca.Ascoltatore {
            override fun risultati(fonte: String, annunci: List<Annuncio>, diagnostica: String) {
                errori.remove(fonte)
                conteggi[fonte] = (conteggi[fonte] ?: 0) + annunci.size
                aggiungi(annunci)
                finita()
            }
            override fun errore(fonte: String, messaggio: String) {
                errori[fonte] = messaggio
                finita()
            }
        }
    }

    // ------------------------------------------------------------------
    fun fonti(): List<Fonte> = buildList {
        if (usaSubito) add(FonteSubito)
        if (usaVinted) add(FonteVinted)
    }

    private fun chiaveOrdine() = when (ordine) {
        1 -> "prezzo_cresc"; 2 -> "prezzo_decr"; else -> "recenti"
    }

    fun cerca() {
        val q = query.trim()
        if (q.isEmpty()) return
        val f = fonti()
        if (f.isEmpty()) return
        ultimaQuery = q
        pagina = 1
        grezzi.clear(); errori.clear(); conteggi.clear()
        primaRicercaFatta = true
        esaurito = false
        ricordaRecente(q)
        avvia(f)
    }

    /** Chiamata quando lo scorrimento si avvicina al fondo. */
    fun altraPagina() {
        if (inCorso || esaurito || ultimaQuery.isEmpty()) return
        val f = fonti()
        if (f.isEmpty()) return
        pagina++
        avvia(f)
    }

    fun riprova(fonte: String) {
        val f = FONTI.firstOrNull { it.nome == fonte } ?: return
        errori.remove(fonte)
        avvia(listOf(f))
    }

    private fun avvia(f: List<Fonte>) {
        dimensionePrima = grezzi.size
        attesa += f.size
        inCorso = true
        caricamento(true)
        motore.cerca(ultimaQuery, pagina, chiaveOrdine(), f)
    }

    private fun finita() {
        if (attesa > 0) attesa--
        inCorso = attesa > 0
        if (!inCorso && pagina > 1 && grezzi.size == dimensionePrima) esaurito = true
        caricamento(inCorso)
    }

    private fun aggiungi(nuovi: List<Annuncio>) {
        val gia = grezzi.mapTo(HashSet()) { it.fonte + it.id }
        nuovi.forEach {
            if (gia.add(it.fonte + it.id) && !Nascosti.contiene(it.chiave)) grezzi.add(it)
        }
    }

    // ------------------------------------------------------------------
    /** Scarto con possibilita' di annullare: l'archivio si tocca solo alla conferma. */
    fun nascondi(a: Annuncio) {
        Nascosti.aggiungi(ctx, a.chiave, a.titolo)
        grezzi.removeAll { it.fonte == a.fonte && it.id == a.id }
    }

    fun annullaScarto(a: Annuncio) {
        Nascosti.rimuovi(ctx, a.chiave)
        if (grezzi.none { it.fonte == a.fonte && it.id == a.id }) grezzi.add(a)
    }

    // ------------------------------------------------------------------
    /** Lista visibile: filtri applicati a cio' che e' gia' stato scaricato. */
    val risultati: List<Annuncio>
        get() {
            val n = giorni.toLongOrNull() ?: 0L
            val soglia = System.currentTimeMillis() - n * 24L * 3600_000L
            val pMin = prezzoMin.replace(',', '.').toDoubleOrNull()
            val pMax = prezzoMax.replace(',', '.').toDoubleOrNull()

            val lista = grezzi.filter { a ->
                val perEta = when {
                    etaModo == 0 || n <= 0 -> true
                    a.dataMillis == 0L -> false      // senza data non si puo' affermare nulla
                    etaModo == 1 -> a.dataMillis <= soglia
                    else -> a.dataMillis >= soglia
                }
                val perPrezzo = when {
                    pMin == null && pMax == null -> true
                    a.prezzo == null -> false
                    pMin != null && a.prezzo < pMin -> false
                    pMax != null && a.prezzo > pMax -> false
                    else -> true
                }
                perEta && perPrezzo && (mostraVenduti || !a.venduto)
            }
            return when (ordine) {
                1 -> lista.sortedBy { it.prezzo ?: Double.MAX_VALUE }
                2 -> lista.sortedByDescending { it.prezzo ?: -1.0 }
                else -> lista.sortedByDescending { it.dataMillis }
            }
        }

    val esclusi: Int get() = grezzi.size - risultati.size

    val filtriAttivi: Int
        get() = listOf(
            etaModo != 0 && (giorni.toLongOrNull() ?: 0) > 0,
            prezzoMin.isNotBlank() || prezzoMax.isNotBlank(),
            mostraVenduti,
            !usaSubito || !usaVinted,
            ordine != 0
        ).count { it }

    fun azzeraFiltri() {
        etaModo = 0; giorni = "30"; prezzoMin = ""; prezzoMax = ""
        mostraVenduti = false; usaSubito = true; usaVinted = true; ordine = 0
    }

    // ------------------------------------------------------------------
    private fun prefs() = ctx.getSharedPreferences("subitoplus", Context.MODE_PRIVATE)

    private fun caricaRecenti(): List<String> =
        prefs().getString("recenti", "")?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()

    private fun ricordaRecente(q: String) {
        val nuove = (listOf(q) + recenti.filter { !it.equals(q, true) }).take(8)
        recenti = nuove
        prefs().edit().putString("recenti", nuove.joinToString("\n")).apply()
    }

    fun dimenticaRecenti() {
        recenti = emptyList()
        prefs().edit().remove("recenti").apply()
    }
}
