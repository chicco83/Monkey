package it.zecchi.subitoplus

/*
 * Subito+ — cattura delle risposte JSON dentro la pagina
 * v0.3.1 (2026-08-30) — nuovo
 *
 * Viene iniettato a document-start, quindi PRIMA che la pagina definisca le sue
 * chiamate: sostituisce fetch e XMLHttpRequest con versioni che, a risposta
 * arrivata, ne consegnano un campione al lato Kotlin.
 * Non modifica il comportamento: la risposta originale viene restituita intatta
 * (fetch usa clone(), cosi' il corpo resta leggibile dalla pagina).
 *
 * Gira su subito.it e su vinted.it: e' da qui che esce la mappa dei campi
 * su cui verra' costruita la ricerca unificata.
 *
 * Nota sintassi: niente template literal e niente simbolo dollaro nel JS.
 */
object ScriptApi {

    // v0.3.2: attivo solo in "modalita' sonda", e con nome ponte casuale
    fun script(ponte: String): String = """
    (function () {
      if (window.__spApi) return;
      window.__spApi = true;
      var MAX = 2500;

      function consegna(u, s, b) {
        try { window['$ponte'].reportApi(String(u).slice(0, 400), s | 0, String(b || '').slice(0, MAX)); } catch (e) {}
      }
      function eJson(ct) { return ct && ct.toLowerCase().indexOf('json') >= 0; }

      /* ---- fetch ---- */
      var origFetch = window.fetch;
      if (origFetch) {
        window.fetch = function () {
          var args = arguments;
          var u = (args[0] && args[0].url) ? args[0].url : args[0];
          return origFetch.apply(this, args).then(function (r) {
            try {
              if (eJson(r.headers.get('content-type'))) {
                r.clone().text().then(function (t) { consegna(u, r.status, t); }).catch(function () {});
              }
            } catch (e) {}
            return r;
          });
        };
      }

      /* ---- XMLHttpRequest ---- */
      var oOpen = XMLHttpRequest.prototype.open;
      var oSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function (m, u) { this.__spU = u; return oOpen.apply(this, arguments); };
      XMLHttpRequest.prototype.send = function () {
        var x = this;
        try {
          x.addEventListener('load', function () {
            try {
              if (eJson(x.getResponseHeader('content-type'))) consegna(x.__spU, x.status, x.responseText);
            } catch (e) {}
          });
        } catch (e) {}
        return oSend.apply(this, arguments);
      };
    })();
    """.trimIndent()
}
