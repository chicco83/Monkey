package it.zecchi.subitoplus

/*
 * Subito+ — modello comune degli annunci
 * v0.5.1 (2026-08-30)
 *
 * Ogni fonte restituisce cose diverse; qui tutto diventa la stessa cosa.
 * L'identificatore porta con se' la fonte ("subito" / "vinted") perche'
 * due piattaforme possono usare lo stesso numero per annunci diversi.
 *
 * v0.5.1 — "luogo" e "dettaglio" erano finiti nello stesso campo, e in elenco
 * accanto agli annunci Subito compariva la localita' mentre accanto a quelli
 * Vinted compariva la marca: due cose diverse nella stessa posizione.
 * Ora sono due campi distinti e ognuno va al suo posto.
 */

data class Annuncio(
    val fonte: String,          // "subito" | "vinted"
    val id: String,             // identificatore nativo della fonte
    val titolo: String,
    val prezzo: Double?,        // null quando la fonte non lo espone
    val prezzoTesto: String,
    val luogo: String,          // dove si trova la merce
    val dettaglio: String,      // marca, taglia: cio' che la fonte aggiunge di suo
    val venduto: Boolean,
    val dataMillis: Long,       // 0 se sconosciuta: finisce in fondo negli ordinamenti per data
    val immagine: String?,
    val url: String
) {
    /** Chiave usata nell'archivio degli scartati. Gli annunci Subito restano
     *  con l'ID nudo per compatibilita' con quanto gia' nascosto dalla v0.3.0. */
    val chiave: String get() = if (fonte == "subito") id else "v:$id"
}
