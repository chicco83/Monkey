package it.monkey.app

/*
 * Monkey — il testo dell'annuncio, su Vinted
 * v1.40.0 (2026-09-05) — nuovo
 *
 * IL PROBLEMA, DALLA v1.7.0
 * La vista estesa mostra il testo dell'annuncio accanto ai dati: e' l'unica
 * cosa che in elenco manca davvero, ed e' cio' che fa decidere se aprire o no.
 * Su Subito arriva gia' con i risultati (campo "body", vedi FonteSubito.leggi),
 * su Vinted no: la sonda della v1.1.0 ha elencato i campi veri di un articolo
 * del catalogo —
 *   id, title, price, is_visible, brand_title, path, user, conversion, url,
 *   promoted, photos, photo, favourite_count, is_favourite, service_fee,
 *   total_item_price, view_count, size_title, status, item_box, ...
 * — e il testo non c'e', in nessuna forma. Da allora la colonna, sugli annunci
 * Vinted, resta semplicemente vuota.
 *
 * STESSA ARCHITETTURA DI LuoghiVinted.kt, e per lo stesso motivo
 * Il dato esiste sulla piattaforma ma sta su un'altra risposta, una per
 * articolo. E' identico a com'e' andata per il luogo del venditore: il
 * catalogo non lo espone, il profilo si'. Quindi qui si ripete lo schema che
 * la' funziona da nove versioni — coda, poche richieste per volta, pausa fra
 * l'una e l'altra, cache su file — invece di inventarne un altro.
 *
 * MA CON UNA DIFFERENZA CHE CAMBIA IL DOSAGGIO
 * Un venditore lo si incontra molte volte: la sua riga in cache viene riusata
 * da tutte le ricerche future, e il costo si ammortizza. Una descrizione no:
 * vale per QUEL solo annuncio, e un annuncio dell'usato lo si incrocia una
 * volta sola. Chiedere il testo di tutti e trenta i risultati di ogni pagina
 * vorrebbe dire trenta richieste per pagina che nessuna ricerca futura
 * riusera' mai — cioe' esattamente la firma che distingue un programma da una
 * persona (vedi "COME NON SEMBRARE UN BOT" in Controllore.kt).
 *
 * Percio' qui non si chiede nulla in anticipo: si chiede il testo SOLO degli
 * annunci che finiscono davvero sotto gli occhi, e solo in vista estesa —
 * l'unica in cui quel testo si vede (in vista compatta la colonna non esiste
 * proprio, vedi RigaAnnuncio in SchermataRicerca.kt). In pratica: le quattro o
 * cinque righe visibili, poi altre poche mentre si scorre. E' la stessa
 * andatura di chi guarda gli annunci uno dopo l'altro, non di chi li aspira.
 * Per lo stesso motivo qui si va con UNA richiesta per volta (PARALLELE = 1,
 * contro le due dei luoghi) e una pausa piu' lunga.
 *
 * L'INDIRIZZO — STORIA DEI TENTATIVI
 *
 * 1° (v1.40.0, sbagliato): GET /api/v2/items/<id>, per analogia con la
 * stessa famiglia /api/v2/ usata dal resto dell'app. Una diagnostica
 * dell'utente ha mostrato 404 con la pagina generica dell'app (HTML con
 * l'illustrazione SVG "non trovato"), non un 404 JSON: la rotta non esiste.
 *
 * 2° (v1.43.0, funzionante ma incompleto): la sonda scriptSonda (sotto) ha
 * trovato il testo scorrendo gli <script> della pagina — un blocco JSON-LD
 * standard (schema.org "Product", campo "description"), gia' dentro l'HTML
 * quando la pagina arriva. Funzionava, ma portava sempre il testo ORIGINALE:
 * per un annuncio in lingua straniera, l'utente ha segnalato che la scheda
 * vera mostra la traduzione (attivata da Vinted stesso), mentre l'app
 * mostrava ancora il testo com'era scritto dal venditore.
 *
 * 3° (v1.47.0, quello vero): una nuova sonda, su un annuncio con traduzione
 * attiva, ha catturato la chiamata che il sito fa DAVVERO per comporre la
 * barra laterale della scheda:
 *
 *   GET https://api.vinted.it/item-details/plugins/<id>/translatable?localize=false
 *   -> 200 {"item":{...campi vuoti, un modello...},
 *           "plugins":[
 *             {"name":"summary", ...},
 *             {"name":"description","type":"description","section":"sidebar",
 *              "data":{"description":"Aperto solo per verifica\n\nCasa
 *                       intelligente, compatibile con Home Assistant",
 *                      "is_localized":true,"item_id":"...",
 *                      "localization":"manual","section_title":"Descrizione",
 *                      ...}}
 *           ]}
 *
 * "is_localized":true + "localization":"manual" sull'annuncio straniero della
 * sonda confermano che questo E' il testo (gia') tradotto quando Vinted
 * traduce — esattamente il dato che mancava. E' un endpoint su un altro
 * host (api.vinted.it, non www.vinted.it: un indirizzo assoluto, non piu'
 * relativo alla sessione come /api/v2/...), ma la stessa sonda l'ha
 * catturato mentre lo chiamava la pagina VERA con la sessione dell'utente:
 * se il sito lo fa da dentro www.vinted.it senza inciampare nel CORS, lo
 * stesso vale per la nostra chiamata, che parte dalla stessa pagina.
 *
 * Da questa versione si chiama questo endpoint al posto di scaricare la
 * pagina intera e cercarci dentro un blocco JSON-LD: piu' semplice (una
 * risposta JSON pulita, non piu' html-scraping), piu' leggero (una sola
 * chiamata piccola invece di un'intera pagina), e soprattutto corretto per
 * gli annunci in lingua straniera. Vedi richiedi()/leggiDescrizionePlugin()
 * piu' sotto per i dettagli; il tentativo precedente (JSON-LD dall'HTML)
 * resta commentato piu' in basso, per la cronaca e come ripiego a cui
 * tornare se questo endpoint dovesse mai sparire.
 *
 * v1.49.0 (2026-09-09) — IL BUCO DIAGNOSTICO CHE HA NASCOSTO IL PASSO
 * SUCCESSIVO
 * Dopo la v1.48.0 l'utente ha continuato a vedere il testo in lingua
 * originale in vista estesa. Quattro diagnostiche di fila (api.json della
 * sonda, anche dopo una disinstallazione completa per escludere la cache)
 * non hanno mai mostrato la chiamata a "translatable" — ne' riuscita ne'
 * fallita. Motivo, trovato guardando invece dove segnala() scrive
 * (motore.diagnostica, esportato come "ricerca-diagnostica.txt", un file
 * DIVERSO da "api.json" — la sonda vede solo il traffico della pagina
 * aperta nel tab "Sito", non le chiamate di sfondo di MotoreRicerca):
 * segnala() (piu' sotto) scriveva SOLO quando leggiDescrizionePlugin()
 * tornava null, cioe' solo sui fallimenti. Se la chiamata risponde 200 con
 * un JSON che si legge ma porta il testo SBAGLIATO (non tradotto) —
 * l'ipotesi rimasta in piedi dopo aver escluso la cache — non restava
 * traccia da NESSUNA parte, in nessuno dei due file. Da questa versione
 * segnala() scrive una riga la prima volta che risponde, che vada bene o
 * male: cosi' la prossima "ricerca-diagnostica.txt" mostra la verita'
 * qualunque cosa succeda, invece di restare muta proprio nel caso che
 * serviva vedere.
 *
 * 4° (v1.50.0, 2026-09-09) — quello che mancava: la riga aperta dalla
 * v1.49.0 ha mostrato la risposta vera, su un annuncio in tedesco cercato
 * apposta ("Biete hier ein Konvolut von Spielen..."): stato 200, testo
 * estratto regolare, ma nella lingua ORIGINALE — non tradotto. La chiamata
 * quindi non falliva mai e non restituiva mai un JSON diverso da quello
 * atteso: rispondeva "giusta" con la lingua sbagliata, in modo ripetibile.
 *
 * La causa e' la stessa gia' risolta per il cuore su Vinted, con la stessa
 * prova (v1.26.0, vedi il commento su "toggle" in Fonti.kt): la sessione
 * nascosta di MotoreRicerca carica la HOME di vinted.it una volta all'avvio
 * e ci resta sopra per tutta la vita del processo — non naviga MAI davvero
 * alla pagina di un annuncio. La sonda che aveva scoperto "translatable"
 * (3°, sopra) l'aveva pero' catturata mentre la chiamava un browser vero
 * GIA' SULLA PAGINA di quell'annuncio: e' verosimilmente quella pagina —
 * coi cookie, la cronologia di visita e l'eventuale rilevazione automatica
 * della lingua che porta con se' — a far decidere a Vinted se tradurre,
 * non la sola sessione utente autenticata. Chiamare l'endpoint da una
 * sessione ferma sulla home, come faceva l'app dalla v1.47.0, gli dava
 * tecnicamente tutto il necessario (id, cookie, intestazioni) tranne
 * proprio quel contesto.
 *
 * Rimedio: come per il cuore, "a.url" torna in richiedi() (vedi piu' sotto
 * e StatoRicerca.chiediDescrizione) e viaggia nella Chiamata come
 * "paginaPrima" — la sessione ci naviga DAVVERO prima di chiedere la
 * traduzione, la stessa sequenza gia' provata funzionante. CACHE_VERSIONE
 * sale insieme: ogni descrizione gia' in cache da prima di questa versione
 * puo' essere stata presa con la sessione ferma sulla home (lingua
 * originale, sbagliata) e va richiesta almeno una volta di piu' col nuovo
 * meccanismo.
 */

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File

object DescrizioniVinted {

    private const val FILE = "descrizioni_vinted.json"

    /*
     * Una per volta. I luoghi (LuoghiVinted) ne fanno due, ma li' la cache si
     * riusa fra ricerche diverse e la coda si esaurisce; qui ogni annuncio e'
     * una richiesta a perdere, quindi si va piu' piano — vedi il commento in
     * cima al file.
     */
    private const val PARALLELE = 1

    /** Pausa fra una richiesta e la successiva. */
    private const val PAUSA_MS = 600L

    /** Tetto della coda: si scorre in fretta, e cio' che e' gia' passato non serve piu'. */
    private const val CODA_MAX = 40

    /*
     * Quanto testo si tiene. In vista estesa se ne vedono al massimo sei righe
     * troncate (vedi RigaAnnuncio), quindi conservare l'annuncio intero
     * riempirebbe il file per niente. 800 caratteri stanno larghi dentro sei
     * righe su qualunque schermo.
     */
    private const val MAX_TESTO = 800

    /*
     * Quante descrizioni si conservano su file. A differenza dei luoghi — che
     * si riusano e quindi vale la pena tenere per sempre — queste servono
     * quasi solo a non richiedere due volte lo stesso annuncio nella stessa
     * giornata di ricerche (tornare indietro nell'elenco, ripetere una
     * ricerca, riaprire una ricerca salvata). Oltre il tetto cadono le piu'
     * vecchie: e' una cache, non un archivio.
     */
    private const val MAX_CACHE = 400

    private val ui = Handler(Looper.getMainLooper())

    /*
     * id annuncio -> testo gia' noto. Anche "" e' un valore buono: vuol dire
     * "chiesto, la piattaforma non ha dato testo" — senza, si richiederebbe
     * all'infinito lo stesso annuncio senza descrizione. LinkedHashMap perche'
     * l'ordine d'inserimento e' quello che serve per buttare via le piu'
     * vecchie quando si supera MAX_CACHE.
     */
    private val noti = LinkedHashMap<String, String>()

    private val coda = ArrayDeque<String>()

    /*
     * v1.50.0 — torna: serve di nuovo per navigare la sessione sulla pagina
     * vera dell'annuncio PRIMA di chiedere la traduzione (vedi il 4° nel
     * commento in cima al file, e Chiamata.paginaPrima in avviaProssimo).
     *
     * --- versione precedente (v1.47.0-v1.49.0, non serviva) ---
     * // "l'indirizzo si costruisce dal solo id, non serve piu' portare in
     * // coda la pagina dell'annuncio" — rivelatosi il pezzo mancante: vedi
     * // il 4° tentativo in cima al file.
     * --- fine versione precedente ---
     *
     * --- versione precedente (v1.43.0-v1.46.0) ---
     * private val urlPerId = HashMap<String, String>()
     * --- fine versione precedente ---
     */
    private val urlPerId = HashMap<String, String>()

    private val inVolo = HashSet<String>()
    private var attivi = 0
    private var caricato = false
    private var daSalvare = false

    /*
     * La diagnostica si scrive una volta sola per sessione: serve a sapere
     * COM'E' FATTA la risposta, e la prima basta. Senza questa guardia, un
     * campo sbagliato riempirebbe il log con trenta copie della stessa cosa.
     */
    private var diagnosticaScritta = false

    /*
     * v1.48.0 (2026-09-08) — CORREZIONE: "la descrizione compare sempre in
     * lingua originale", anche dopo la v1.47.0. La chiamata nuova era giusta
     * (confermata dalla sonda), ma la CACHE su file no: "noti" si carica da
     * descrizioni_vinted.json all'avvio e richiedi() scarta subito ogni id
     * gia' presente li' dentro (vedi piu' sotto) — l'app non cancella mai
     * quel file da sola fra una versione e l'altra (stesso applicationId,
     * stessi dati, vedi build.gradle.kts v1.14.0). Ogni annuncio gia' visto
     * PRIMA della v1.47.0 aveva quindi il testo ORIGINALE scritto per sempre
     * in cache, e richiedi() non lo richiedeva mai piu' — esattamente il
     * "sempre", non "a volte", segnalato dall'utente: non e' un caso che
     * fallisca la traduzione, e' che per gli annunci gia' incontrati prima
     * la nuova chiamata non partiva proprio.
     *
     * Rimedio: il file porta gia' un campo "versione" (finora scritto ma mai
     * riletto — vedi salva(), sotto). Da questa versione carica() lo
     * confronta con CACHE_VERSIONE: se non combacia, la cache e' considerata
     * scritta con il vecchio meccanismo e si riparte vuota invece di
     * caricarla — un solo "colpo a vuoto" per annuncio gia' visto, poi la
     * cache torna a funzionare normalmente con il testo giusto.
     */
    /*
     * v1.50.0 — sale di nuovo: la traduzione mancante non era la cache
     * (v1.48.0 aveva gia' escluso quell'ipotesi), ma qualunque descrizione
     * presa PRIMA di questa versione puo' comunque essere stata chiesta con
     * la sessione ferma sulla home invece che sulla pagina vera (vedi il 4°
     * tentativo in cima al file) — quindi in lingua originale quando non
     * doveva esserlo. Un altro "colpo a vuoto" per annuncio gia' visto, poi
     * la cache torna a funzionare normalmente col meccanismo corretto.
     *
     * --- versione precedente (v1.48.0-v1.49.0) ---
     * private const val CACHE_VERSIONE = "1.48.0"
     * --- fine versione precedente ---
     */
    private const val CACHE_VERSIONE = "1.50.0"

    // ------------------------------------------------------------------
    /*
     * v1.48.0 — confronto con CACHE_VERSIONE prima di caricare: vedi il
     * commento sopra per il perche'.
     *
     * --- versione precedente (fino alla v1.47.0) ---
     * @Synchronized
     * fun carica(ctx: Context) {
     *     if (caricato) return
     *     caricato = true
     *     val f = File(ctx.filesDir, FILE)
     *     if (!f.exists()) return
     *     try {
     *         val root = JSONObject(f.readText())
     *         root.optJSONObject("descrizioni")?.let { o ->
     *             o.keys().forEach { k -> noti[k] = o.optString(k) }
     *         }
     *     } catch (t: Throwable) { // file rovinato: si riparte da vuoto
     *     }
     * }
     * --- fine versione precedente ---
     */
    @Synchronized
    fun carica(ctx: Context) {
        if (caricato) return
        caricato = true
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return
        try {
            val root = JSONObject(f.readText())
            if (root.optString("versione") != CACHE_VERSIONE) return
            root.optJSONObject("descrizioni")?.let { o ->
                o.keys().forEach { k -> noti[k] = o.optString(k) }
            }
        } catch (t: Throwable) { /* file rovinato: si riparte da vuoto */ }
    }

    /** Testo gia' noto, oppure null se questo annuncio non e' ancora stato chiesto. */
    @Synchronized
    fun descrizione(id: String): String? = noti[id]

    /**
     * Chiede il testo di un annuncio Vinted, se non lo si ha gia' — la
     * versione GIA' TRADOTTA quando Vinted traduce (vedi il commento in cima
     * al file).
     *
     * Si chiama una riga per volta, da chi la sta DISEGNANDO in vista estesa
     * (vedi SchermataRicerca.RigaAnnuncio): e' il modo per chiedere solo cio'
     * che si guarda davvero — vedi il commento in cima al file.
     *
     * @param aggiornato invocato sul thread principale quando il testo e' pronto
     */
    /*
     * v1.50.0 (2026-09-09) — CORREZIONE: "url" torna, per lo stesso motivo
     * per cui era servito la prima volta (v1.43.0) e per cui era servito al
     * cuore su Vinted (v1.26.0, vedi Fonti.kt): senza una navigazione vera
     * alla pagina dell'annuncio prima della chiamata, l'endpoint di
     * traduzione risponde con la lingua originale — vedi il 4° tentativo in
     * cima al file, con la prova (un annuncio in tedesco, mai tradotto).
     *
     * --- versione precedente (v1.47.0-v1.49.0, solo id — si e' rivelato
     *     il pezzo mancante) ---
     * fun richiedi(
     *     ctx: Context,
     *     motore: MotoreRicerca,
     *     id: String,
     *     aggiornato: (id: String, testo: String) -> Unit
     * ) {
     *     carica(ctx)
     *     if (id.isBlank()) return
     *     if (noti.containsKey(id) || inVolo.contains(id) || coda.contains(id)) return
     *     if (coda.size >= CODA_MAX) return
     *     coda.addLast(id)
     *     while (attivi < PARALLELE && coda.isNotEmpty()) avviaProssimo(ctx, motore, aggiornato)
     * }
     * --- fine versione precedente ---
     *
     * --- versione precedente (v1.43.0-v1.46.0) ---
     * fun richiedi(
     *     ctx: Context,
     *     motore: MotoreRicerca,
     *     id: String,
     *     url: String,
     *     aggiornato: (id: String, testo: String) -> Unit
     * ) {
     *     carica(ctx)
     *     if (id.isBlank() || url.isBlank()) return
     *     if (noti.containsKey(id) || inVolo.contains(id) || coda.contains(id)) return
     *     if (coda.size >= CODA_MAX) return
     *     coda.addLast(id)
     *     urlPerId[id] = url
     *     while (attivi < PARALLELE && coda.isNotEmpty()) avviaProssimo(ctx, motore, aggiornato)
     * }
     * --- fine versione precedente ---
     *
     * --- versione precedente (v1.42.0, 2026-09-08) — SOSPESA ---
     * // La diagnostica mandata dall'utente ha confermato che
     * // "GET /api/v2/items/<id>" non e' una rotta vera — risponde 404 con
     * // la pagina generica dell'app (HTML con l'illustrazione SVG "non
     * // trovato"), non un 404 JSON dell'API come quelli gia' visti altrove
     * // (es. il 403 "access_denied" del cuore). E una sonda con "Modalita'
     * // sonda" attiva, aperta su una scheda vera, non ha mai visto IL
     * // CAMPIONATORE DI FETCH/XHR (ScriptApi) catturare nessuna chiamata
     * // per il dettaglio: segno che il testo non arriva mai con una
     * // richiesta separata, e' gia' dentro l'HTML della pagina quando
     * // arriva (reso lato server). Insistere con questa chiamata userebbe
     * // solo richieste a vuoto, per un endpoint che si sa gia' non
     * // esistere.
     * fun richiedi(
     *     ctx: Context,
     *     motore: MotoreRicerca,
     *     id: String,
     *     aggiornato: (id: String, testo: String) -> Unit
     * ) {
     *     // v1.42.0 — sospesa: il corpo di prima resta li', come
     *     // "versione precedente", non qui sotto irraggiungibile.
     * }
     * --- fine versione precedente ---
     *
     * --- versione precedente (fino alla v1.41.0) ---
     * fun richiedi(
     *     ctx: Context,
     *     motore: MotoreRicerca,
     *     id: String,
     *     aggiornato: (id: String, testo: String) -> Unit
     * ) {
     *     carica(ctx)
     *     if (id.isBlank()) return
     *     if (noti.containsKey(id) || inVolo.contains(id) || coda.contains(id)) return
     *     if (coda.size >= CODA_MAX) return
     *     coda.addLast(id)
     *     while (attivi < PARALLELE && coda.isNotEmpty()) avviaProssimo(ctx, motore, aggiornato)
     * }
     * --- fine versione precedente ---
     */
    @Synchronized
    fun richiedi(
        ctx: Context,
        motore: MotoreRicerca,
        id: String,
        url: String,
        aggiornato: (id: String, testo: String) -> Unit
    ) {
        carica(ctx)
        if (id.isBlank() || url.isBlank()) return
        if (noti.containsKey(id) || inVolo.contains(id) || coda.contains(id)) return
        if (coda.size >= CODA_MAX) return
        coda.addLast(id)
        urlPerId[id] = url
        while (attivi < PARALLELE && coda.isNotEmpty()) avviaProssimo(ctx, motore, aggiornato)
    }

    /*
     * v1.42.0 (2026-09-08) — sonda per trovare DAVVERO come arriva il testo
     * di un annuncio Vinted, dopo che il tentativo per chiamata separata si
     * e' escluso da solo. Ha fatto il suo lavoro (ha portato al blocco
     * JSON-LD della v1.43.0, poi superato dall'endpoint di traduzione della
     * v1.47.0 — vedi il commento in cima al file) e resta nel codice: come
     * "Modalita' sonda" in generale, serve a diagnosticare un domani se
     * Vinted cambia ancora pagina (stessa logica per cui non si toglie mai
     * "Esporta diagnostica" a bug chiuso).
     *
     * Attiva SOLO in "Modalita' sonda" (come DomProbe) e SOLO sulle pagine
     * articolo di Vinted (percorso "/items/..."): su ogni altra pagina non
     * farebbe che sprecare un confronto a vuoto. Il risultato va a finire
     * nello stesso canale gia' usato per le chiamate campionate (reportApi
     * -> ApiLog -> "api.json" in "Esporta diagnostica"), cosi' compare
     * insieme a tutto il resto invece di aprire un file a parte.
     *
     * Nota sintassi: niente template literal e niente simbolo dollaro nel
     * JS, come nel resto delle sonde di questo progetto (vedi DomProbe.kt).
     */
    fun scriptSonda(ponte: String): String = """
    (function () {
      try {
        if (String(location.pathname || '').indexOf('/items/') === -1) return;
        var scripts = document.querySelectorAll('script');
        var trovato = null;
        for (var i = 0; i < scripts.length; i++) {
          var t = scripts[i].textContent || '';
          if (t.indexOf('"description"') >= 0) { trovato = t; break; }
        }
        if (trovato) {
          var idx = trovato.indexOf('"description"');
          var pezzo = trovato.slice(Math.max(0, idx - 80), idx + 2000);
          window['$ponte'].reportApi(location.href, 'SONDA-DESCRIZIONE', '', 200, pezzo);
        } else {
          window['$ponte'].reportApi(
            location.href, 'SONDA-DESCRIZIONE', '', 404,
            '(nessuno script con "description" trovato - script totali: ' + scripts.length + ')'
          );
        }
      } catch (e) {
        try { window['$ponte'].reportApi(location.href, 'SONDA-DESCRIZIONE', '', -1, String(e)); } catch (e2) {}
      }
    })();
    """.trimIndent()

    @Synchronized
    private fun avviaProssimo(
        ctx: Context,
        motore: MotoreRicerca,
        aggiornato: (String, String) -> Unit
    ) {
        val id = coda.removeFirstOrNull() ?: return
        inVolo.add(id)
        attivi++
        /*
         * v1.50.0 — CORREZIONE: "paginaPrima" torna, e stavolta punta alla
         * pagina VERA dell'annuncio (urlPerId[id], portata da richiedi()),
         * non piu' assente. Senza, la sessione restava ferma sulla home di
         * vinted.it (caricata una volta all'avvio, vedi MotoreRicerca) e la
         * risposta arrivava sempre nella lingua originale — la stessa causa,
         * la stessa prova, gia' viste per il cuore su Vinted (v1.26.0, vedi
         * Fonti.kt "toggle" e il 4° tentativo in cima al file). "url" resta
         * un host diverso (api.vinted.it, non www.vinted.it) ma raggiunto
         * con la stessa sessione/cookie: e' un indirizzo assoluto e
         * Chiamata.url lo accetta gia' cosi' com'e' (vedi Fonti.kt).
         * "localize=false" e' il parametro visto nella sonda: nonostante il
         * nome, la risposta porta il testo tradotto quando la sessione ha
         * davvero visitato la pagina prima di chiedere.
         *
         * --- versione precedente (v1.47.0-v1.49.0, senza paginaPrima —
         *     rispondeva sempre, ma in lingua originale) ---
         * val url = "https://api.vinted.it/item-details/plugins/$id/translatable?localize=false"
         * motore.azione(FonteVinted, Chiamata("GET", url)) { stato, corpo ->
         *     val testo = if (stato in 200..299) leggiDescrizionePlugin(corpo) else null
         *     segnala(motore, id, stato, corpo, testo)
         *     concluso(ctx, motore, id, testo, aggiornato)
         * }
         * --- fine versione precedente ---
         *
         * --- versione precedente (v1.43.0-v1.46.0, pagina intera + JSON-LD) ---
         * motore.azione(FonteVinted, Chiamata("GET", url)) { stato, corpo ->
         *     val testo = if (stato in 200..299) leggiDescrizioneHtml(corpo) else null
         *     if (testo == null) segnala(motore, id, stato, corpo)
         *     concluso(ctx, motore, id, testo, aggiornato)
         * }
         * --- fine versione precedente ---
         *
         * --- versione precedente (fino alla v1.41.0) ---
         * motore.azione(FonteVinted, Chiamata("GET", "/api/v2/items/$id")) { stato, corpo ->
         *     val testo = if (stato in 200..299) leggiDescrizione(corpo) else null
         *     if (testo == null) segnala(motore, id, stato, corpo)
         *     concluso(ctx, motore, id, testo, aggiornato)
         * }
         * --- fine versione precedente ---
         */
        val pagina = urlPerId.remove(id)
        val url = "https://api.vinted.it/item-details/plugins/$id/translatable?localize=false"
        motore.azione(FonteVinted, Chiamata("GET", url, paginaPrima = pagina)) { stato, corpo ->
            val testo = if (stato in 200..299) leggiDescrizionePlugin(corpo) else null
            // v1.49.0 — segnala() si chiama SEMPRE (non solo sui fallimenti):
            // vedi il commento in cima al file, "IL BUCO DIAGNOSTICO...".
            segnala(motore, id, stato, corpo, testo)
            concluso(ctx, motore, id, testo, aggiornato)
        }
    }

    @Synchronized
    private fun concluso(
        ctx: Context,
        motore: MotoreRicerca,
        id: String,
        testo: String?,
        aggiornato: (String, String) -> Unit
    ) {
        inVolo.remove(id)
        attivi--
        if (testo != null) {
            noti[id] = testo
            // Il tetto si applica qui, subito: la piu' vecchia esce quando
            // entra la nuova, cosi' la mappa non cresce mai oltre MAX_CACHE.
            while (noti.size > MAX_CACHE) {
                val piuVecchia = noti.keys.firstOrNull() ?: break
                noti.remove(piuVecchia)
            }
            daSalvare = true
            if (testo.isNotBlank()) ui.post { aggiornato(id, testo) }
        }
        // Se la chiamata e' fallita non si registra nulla: la prossima volta
        // che l'annuncio compare si riprova. Nessuna lista di "falliti" come
        // in LuoghiVinted — li' un venditore torna spesso e insistere avrebbe
        // un costo, qui l'annuncio probabilmente non lo si rivede piu'.
        salvaFraPoco(ctx)
        if (coda.isNotEmpty()) ui.postDelayed({ avviaProssimo(ctx, motore, aggiornato) }, PAUSA_MS)
    }

    /*
     * v1.47.0 — lettura del testo dalla risposta VERA dell'endpoint di
     * traduzione: {"item":{...un modello, sempre vuoto...},"plugins":[...]}.
     * Il testo sta in "plugins", nell'elemento con "name":"description",
     * dentro "data.description" — vedi l'esempio completo in cima al file.
     * Non si presume che sia sempre il primo elemento dell'array (l'ordine
     * non e' garantito da nessuna parte): si scorre l'array e si prende il
     * primo plugin il cui nome e' "description".
     */
    private fun leggiDescrizionePlugin(corpo: String): String? = try {
        val root = JSONObject(corpo)
        val plugins = root.optJSONArray("plugins")
        var trovato: String? = null
        if (plugins != null) {
            for (i in 0 until plugins.length()) {
                val p = plugins.optJSONObject(i) ?: continue
                if (p.optString("name") != "description") continue
                val v = p.optJSONObject("data")?.optString("description")?.trim().orEmpty()
                if (v.isNotEmpty() && v != "null") { trovato = v; break }
            }
        }
        trovato?.let { pulisci(it) }
    } catch (t: Throwable) { null }

    /*
     * --- versione precedente (v1.43.0-v1.46.0, lettura dal blocco JSON-LD
     *     della pagina intera — funzionava, ma portava solo il testo
     *     ORIGINALE, mai la traduzione: vedi il commento in cima al file) ---
     * private val SCRIPT_LDJSON = Regex(
     *     "<script[^>]*type=[\"']application/ld\\+json[\"'][^>]*>([\\s\\S]*?)</script>",
     *     RegexOption.IGNORE_CASE
     * )
     * private val SCRIPT_QUALSIASI = Regex(
     *     "<script[^>]*>([\\s\\S]*?)</script>",
     *     RegexOption.IGNORE_CASE
     * )
     *
     * private fun leggiDescrizioneHtml(html: String): String? {
     *     for (m in SCRIPT_LDJSON.findAll(html)) {
     *         leggiDaBloccoJson(m.groupValues[1])?.let { return pulisci(it) }
     *     }
     *     for (m in SCRIPT_QUALSIASI.findAll(html)) {
     *         val corpo = m.groupValues[1]
     *         if (corpo.contains("\"description\"")) {
     *             leggiDaBloccoJson(corpo)?.let { return pulisci(it) }
     *         }
     *     }
     *     return null
     * }
     *
     * private fun leggiDaBloccoJson(testo: String): String? = try {
     *     val t = testo.trim()
     *     when {
     *         t.startsWith("[") -> leggiDescrizioneDaArray(JSONArray(t))
     *         t.startsWith("{") -> {
     *             val o = JSONObject(t)
     *             val graph = o.optJSONArray("@graph")
     *             if (graph != null) leggiDescrizioneDaArray(graph)
     *             else campoTesto(o)
     *         }
     *         else -> null
     *     }
     * } catch (e: Throwable) { null }
     *
     * private fun leggiDescrizioneDaArray(arr: JSONArray): String? {
     *     for (i in 0 until arr.length()) {
     *         val o = arr.optJSONObject(i) ?: continue
     *         campoTesto(o)?.let { return it }
     *     }
     *     return null
     * }
     *
     * private fun campoTesto(o: JSONObject): String? {
     *     val v = o.optString("description").trim()
     *     return if (v.isNotEmpty() && v != "null") v else null
     * }
     * --- fine versione precedente ---
     *
     * --- versione precedente (fino alla v1.42.0, lettura da risposta JSON
     *     dell'API "/api/v2/items/<id>", mai risultata una rotta vera) ---
     * private val CAMPI_TESTO = listOf(
     *     "description", "body", "item_description", "description_text", "text"
     * )
     *
     * private fun leggiDescrizione(corpo: String): String? = try {
     *     val root = JSONObject(corpo)
     *     val o = root.optJSONObject("item") ?: root
     *     var trovato: String? = null
     *     for (k in CAMPI_TESTO) {
     *         val v = o.optString(k).trim()
     *         if (v.isNotEmpty() && v != "null") { trovato = v; break }
     *     }
     *     trovato?.let { pulisci(it) }
     * } catch (t: Throwable) { null }
     * --- fine versione precedente ---
     */

    /**
     * Il testo com'e' scritto dal venditore (o gia' tradotto, quando Vinted
     * traduce), solo accorciato e senza le righe vuote di troppo: su Vinted
     * si va spesso a capo per elencare misure e difetti, e sei righe di
     * elenco si riempirebbero di spazi invece che di parole.
     */
    private fun pulisci(s: String): String {
        val compatto = s.replace(Regex("\n{2,}"), "\n").trim()
        return if (compatto.length <= MAX_TESTO) compatto
        else compatto.take(MAX_TESTO).trimEnd() + "…"
    }

    /*
     * La prova da mandare, se non si e' trovato testo. Non si scrive l'intero
     * corpo (puo' essere lungo): stato e un pezzo, che bastano a capire se la
     * risposta e' arrivata per davvero (JSON vero) o se la sessione ha
     * ricevuto qualcos'altro (per esempio un blocco anti-bot).
     */
    /*
     * v1.49.0 — CORREZIONE: si chiama sempre, non solo sui fallimenti (vedi
     * il commento in cima al file, "IL BUCO DIAGNOSTICO..."). Prima si
     * sapeva SE la chiamata falliva, mai COSA rispondeva quando "riusciva"
     * ma con lingua sbagliata — il caso rimasto proprio quando serviva
     * vederlo. Ora la firma porta anche "testo" (il risultato di
     * leggiDescrizionePlugin, null se non trovato) e lo si scrive in
     * chiaro: cosi' la riga dice sia cosa e' arrivato sia cosa se ne e'
     * ricavato, senza dover rileggere a mano il corpo JSON ogni volta.
     *
     * --- versione precedente (v1.47.0-v1.48.0, solo sui fallimenti) ---
     * @Synchronized
     * private fun segnala(motore: MotoreRicerca, id: String, stato: Int, corpo: String) {
     *     if (diagnosticaScritta) return
     *     diagnosticaScritta = true
     *     motore.diagnostica.append(
     *         "[vinted] descrizione articolo $id (translatable) -> stato $stato\n" +
     *                 "  cercato: \"plugins\" con un elemento name=\"description\" e " +
     *                 "data.description\n" +
     *                 "  corpo (primi 1200): ${corpo.take(1200)}\n"
     *     )
     * }
     * --- fine versione precedente ---
     *
     * --- versione precedente (v1.43.0-v1.46.0) ---
     * // stessa forma, ma cercava un <script> ld+json invece di "plugins"
     * // (vedi la versione precedente ancora piu' sotto in leggiDaBloccoJson)
     * --- fine versione precedente ---
     *
     * --- versione precedente (fino alla v1.42.0) ---
     * // stessa forma, ma cercava i campi di CAMPI_TESTO dentro "item"
     * // invece di "plugins" (endpoint /api/v2/items/<id>, mai risultato
     * // una rotta vera)
     * --- fine versione precedente ---
     */
    @Synchronized
    private fun segnala(motore: MotoreRicerca, id: String, stato: Int, corpo: String, testo: String?) {
        if (diagnosticaScritta) return
        diagnosticaScritta = true
        motore.diagnostica.append(
            "[vinted] descrizione articolo $id (translatable) -> stato $stato\n" +
                    "  testo estratto: " +
                    (testo?.let { "\"" + it.take(200).replace("\n", " ") + "\"" }
                        ?: "(nessuno — vedi il corpo qui sotto)") + "\n" +
                    "  corpo (primi 1200): ${corpo.take(1200)}\n"
        )
    }

    // ------------------------------------------------------------------
    private fun salvaFraPoco(ctx: Context) {
        if (!daSalvare) return
        // Si scrive una volta sola a fine raffica, non a ogni risposta.
        ui.removeCallbacks(salvataggio)
        contesto = ctx.applicationContext
        ui.postDelayed(salvataggio, 1500)
    }

    private var contesto: Context? = null
    private val salvataggio = Runnable { salva() }

    @Synchronized
    /*
     * v1.48.0 — scrive CACHE_VERSIONE (la costante confrontata da carica(),
     * sopra), non piu' una stringa fissa scritta a mano: cosi' non si
     * dimentica di allinearle di nuovo alla prossima versione che cambia
     * ancora una volta il meccanismo.
     *
     * --- versione precedente (fino alla v1.47.0) ---
     * File(ctx.filesDir, FILE).writeText(
     *     JSONObject().put("versione", "1.47.0").put("descrizioni", o).toString()
     * )
     * --- fine versione precedente ---
     */
    private fun salva() {
        val ctx = contesto ?: return
        daSalvare = false
        try {
            val o = JSONObject()
            noti.forEach { (k, v) -> o.put(k, v) }
            File(ctx.filesDir, FILE).writeText(
                JSONObject().put("versione", CACHE_VERSIONE).put("descrizioni", o).toString()
            )
        } catch (t: Throwable) { /* la cache e' un lusso, non un dato */ }
    }

    @Synchronized
    fun svuota(ctx: Context) {
        // v1.50.0 — "urlPerId" nel reset insieme a coda: e' lo stesso tipo
        // di stato (un in-sospeso per id), e "coda" gia' c'era.
        noti.clear(); coda.clear(); urlPerId.clear()
        try { File(ctx.filesDir, FILE).delete() } catch (t: Throwable) {}
    }
}
