package it.monkey.app

/*
 * Monkey — data "Caricato" di un annuncio Vinted
 * v1.0.0 (2026-09-24) — nuovo, consegnato con l'app v1.59.0
 *
 * L'utente ha mostrato (screenshot della scheda Vinted di un annuncio) che
 * la data c'e': nella scheda compare il campo "Caricato  un'ora fa". Non
 * sta nella card dell'ELENCO (da cui l'app legge i risultati dalla v1.56.0,
 * vedi FonteVinted), ma nel DETTAGLIO dell'annuncio — lo stesso che l'app
 * gia' scarica per la descrizione (DescrizioniVinted, endpoint
 * "item-details/plugins/<id>/translatable"). Qui si legge quel campo dalla
 * stessa risposta: nessuna chiamata in piu'.
 *
 * FORMA NON ANCORA VISTA: la diagnostica di quell'endpoint si fermava ai
 * primi 1200 caratteri, dove c'era solo il plugin "summary". Non si
 * conosce quindi il punto esatto del JSON in cui sta "Caricato". Invece di
 * indovinare un percorso, si cerca nel JSON intero:
 *   1. il piu' PICCOLO oggetto che contiene la parola "Caricato" (o
 *      "Uploaded", se il testo arriva in inglese con localize=false) e,
 *      dopo di essa, un testo tipo "un'ora fa" / "3 giorni fa" / "2 hours
 *      ago": si prende quello;
 *   2. in mancanza, una chiave il cui nome contiene "upload" con dentro un
 *      numero (secondi/millisecondi) o una data ISO.
 * Quello che si trova (o il fatto che non si trova, con un pezzo del corpo
 * attorno alle parole cercate) va nella diagnostica esportata: se il
 * percorso vero e' diverso, la prossima versione lo legge per nome.
 *
 * PRECISIONE: "Caricato" e' un testo relativo, arrotondato da Vinted
 * (minuti, ore, giorni, settimane...). "precisioneMs" dice di quanto: la
 * stima dall'id (StimaDataVinted) usa come nuova ancora SOLO le letture
 * al minuto, le uniche piu' precise di lei; le altre servono solo a
 * mostrare la data vera sulla riga.
 */

import org.json.JSONArray
import org.json.JSONObject

object DataCaricamentoVinted {

    const val VERSIONE = "1.0.0"

    data class Esito(
        /** istante stimato di caricamento (ms) */
        val ms: Long,
        /** il testo trovato, cosi' com'e' ("un'ora fa"), o il nome del campo */
        val testo: String,
        /** larghezza dell'arrotondamento (ms): 60 000 per "5 minuti fa", ecc. */
        val precisioneMs: Long
    )

    private const val MIN = 60_000L
    private const val ORA = 60 * MIN
    private const val GIORNO = 24 * ORA

    private val ETICHETTE = setOf("caricato", "caricato il", "uploaded", "upload date", "pubblicato")

    /*
     * Testo relativo. "un'ora" non ha spazio fra articolo e parola, quindi
     * l'apostrofo (dritto o tipografico) chiude il numero da solo.
     */
    private val RE_IT = Regex(
        "(\\d+|un['’]|una|uno|un)\\s*(second[oi]|minut[oi]|or[ae]|giorn[oi]|settiman[ae]|mes[ei]|ann[oi])\\s+fa",
        RegexOption.IGNORE_CASE
    )
    private val RE_EN = Regex(
        "(\\d+|an|a)\\s+(seconds?|minutes?|hours?|days?|weeks?|months?|years?)\\s+ago",
        RegexOption.IGNORE_CASE
    )
    private val RE_ORA_IT = Regex("^(adesso|ora|proprio ora|pochi secondi fa|qualche secondo fa)$", RegexOption.IGNORE_CASE)
    private val RE_ORA_EN = Regex("^(just now|now|a few seconds ago)$", RegexOption.IGNORE_CASE)
    private val RE_DATA_ASSOLUTA = Regex("(\\d{1,2})[/.](\\d{1,2})[/.](\\d{4})")

    private fun unita(parola: String): Long = when {
        parola.startsWith("second") -> 1000L
        parola.startsWith("minut") -> MIN
        parola.startsWith("or") || parola.startsWith("hour") -> ORA
        parola.startsWith("giorn") || parola.startsWith("day") -> GIORNO
        parola.startsWith("settiman") || parola.startsWith("week") -> 7 * GIORNO
        parola.startsWith("mes") || parola.startsWith("month") -> 30 * GIORNO
        parola.startsWith("ann") || parola.startsWith("year") -> 365 * GIORNO
        else -> 0L
    }

    private fun quanti(parola: String): Long =
        parola.toLongOrNull() ?: 1L   // un, una, uno, un', a, an

    /** "un'ora fa" -> Esito(ora - 1 h, ...), null se il testo non e' una data. */
    fun interpreta(testo: String, ora: Long = System.currentTimeMillis()): Esito? {
        val t = testo.trim()
        if (t.isEmpty() || t.length > 60) return null
        if (RE_ORA_IT.matches(t) || RE_ORA_EN.matches(t)) return Esito(ora, t, MIN)
        if (t.equals("ieri", true) || t.equals("yesterday", true)) return Esito(ora - GIORNO, t, GIORNO)
        (RE_IT.find(t) ?: RE_EN.find(t))?.let { m ->
            val u = unita(m.groupValues[2].lowercase())
            if (u == 0L) return null
            val n = quanti(m.groupValues[1].lowercase().trimEnd('\'', '’'))
            return Esito(ora - n * u, t, u)
        }
        RE_DATA_ASSOLUTA.find(t)?.let { m ->
            val c = java.util.Calendar.getInstance()
            c.clear()
            c.set(m.groupValues[3].toInt(), m.groupValues[2].toInt() - 1, m.groupValues[1].toInt(), 12, 0)
            return Esito(c.timeInMillis, t, GIORNO)
        }
        return null
    }

    /** Tutte le stringhe dentro un nodo, in ordine, fino a una certa profondita'. */
    private fun stringhe(v: Any?, prof: Int, out: MutableList<String>) {
        if (prof < 0 || out.size > 60) return
        when (v) {
            is String -> out.add(v)
            is JSONObject -> v.keys().forEach { k -> stringhe(v.opt(k), prof - 1, out) }
            is JSONArray -> for (i in 0 until v.length()) stringhe(v.opt(i), prof - 1, out)
        }
    }

    /** Il piu' piccolo nodo con l'etichetta e un testo-data dopo di essa. */
    private fun cercaEtichetta(v: Any?, ora: Long): Esito? {
        // prima i figli: cosi' vince il contenitore piu' piccolo
        when (v) {
            is JSONObject -> v.keys().forEach { k -> cercaEtichetta(v.opt(k), ora)?.let { return it } }
            is JSONArray -> for (i in 0 until v.length()) cercaEtichetta(v.opt(i), ora)?.let { return it }
            else -> return null
        }
        val s = ArrayList<String>()
        stringhe(v, 4, s)
        val iEtichetta = s.indexOfFirst { it.trim().trimEnd(':').lowercase() in ETICHETTE }
        if (iEtichetta < 0) return null
        for (j in iEtichetta + 1 until s.size) interpreta(s[j], ora)?.let { return it }
        return null
    }

    /** Ripiego: una chiave con "upload" nel nome e un valore-data. */
    private fun cercaCampo(v: Any?): Esito? {
        when (v) {
            is JSONObject -> for (k in v.keys()) {
                val x = v.opt(k)
                if (k.lowercase().contains("upload")) {
                    val ms = when (x) {
                        is Number -> x.toLong().let { if (it > 1_000_000_000_000L) it else it * 1000L }
                        is String -> x.toLongOrNull()?.let { if (it > 1_000_000_000_000L) it else it * 1000L }
                            ?: iso(x)
                        else -> 0L
                    }
                    if (ms > 1_000_000_000_000L) return Esito(ms, k, 1000L)
                }
                cercaCampo(x)?.let { return it }
            }
            is JSONArray -> for (i in 0 until v.length()) cercaCampo(v.opt(i))?.let { return it }
        }
        return null
    }

    /** Legge la data di caricamento dalla risposta del dettaglio; null se non c'e'. */
    fun leggi(corpo: String, ora: Long = System.currentTimeMillis()): Esito? = try {
        val root = JSONObject(corpo)
        cercaEtichetta(root, ora) ?: cercaCampo(root)
    } catch (t: Throwable) { null }

    /** Per la diagnostica, quando non si trova: nomi dei plugin e il pezzo attorno alle parole cercate. */
    fun indizi(corpo: String): String {
        val nomi = try {
            val p = JSONObject(corpo).optJSONArray("plugins")
            if (p == null) "(nessun \"plugins\")"
            else (0 until p.length()).joinToString(",") { p.optJSONObject(it)?.optString("name").orEmpty() }
        } catch (t: Throwable) { "(corpo non JSON)" }
        val i = listOf("aricat", "ploaded", "upload").map { corpo.indexOf(it, ignoreCase = true) }.filter { it >= 0 }.minOrNull()
        val pezzo = if (i == null) "(nessuna parola \"caricato\"/\"upload\" nel corpo)"
                    else corpo.substring(maxOf(0, i - 150), minOf(corpo.length, i + 350))
        return "plugin: $nomi · attorno: $pezzo"
    }
}
