package it.monkey.app

/*
 * Monkey — sonda: dove sta l'elenco degli annunci, ora che Vinted ha
 * cambiato pagina
 * v1.52.0 (2026-09-15) — nuovo
 *
 * IL PROBLEMA
 * "/api/v2/catalog/items" (usato dalla v0.4.0) ha smesso di funzionare:
 * l'utente ha segnalato errore 404, e una diagnostica ("ricerca-diagnostica.txt")
 * ha confermato che non e' un 404 JSON dell'API — e' la pagina generica
 * "non trovato" dell'app (stessa firma SVG gia' vista in passato per una
 * rotta inesistente, vedi DescrizioniVinted.kt). La rotta e' sparita.
 *
 * Una sonda sulla pagina di ricerca VERA di Vinted (Modalita' sonda, tab
 * "Sito", una ricerca fatta li' dentro) non ha mai mostrato nessuna
 * chiamata fetch/XHR che porti l'elenco degli annunci — solo suggerimenti
 * di ricerca, ricerche recenti, "promoted_closets" (gli annunci in
 * evidenza), banner. Ipotesi, sulla scorta di cosa e' gia' successo per la
 * descrizione dell'annuncio (v1.43.0, JSON-LD nell'HTML invece di una
 * chiamata a parte): l'elenco vero e proprio ora arriva DENTRO la pagina
 * quando la pagina stessa viene renderizzata (lato server), non con una
 * fetch separata che la sonda fetch/XHR possa vedere.
 *
 * v1.53.0 (2026-09-15) — CORREZIONE, con la prima risposta in mano: la
 * v1.52.0 ha confermato due cose. Primo, "__NEXT_DATA__" (il contenitore
 * classico del vecchio Next.js "Pages Router") e' assente — Vinted usa
 * l'"App Router" piu' recente, che non lo scrive piu'. Secondo, il
 * marcatore "favourite_count" ha dato un FALSO POSITIVO: ha trovato uno
 * script col dizionario delle traduzioni dell'interfaccia, dove compare
 * dentro chiavi come "item.favourite_count.few" — un testo per l'etichetta
 * "3 preferiti", non un campo di un annuncio vero. La sonda si e' fermata
 * li' (primo trovato, si interrompe) senza controllare il resto.
 *
 * Due correzioni. Primo, i marcatori diventano piu' precisi: si cerca
 * 'favourite_count":' (virgolette e due punti INCLUSI) invece del solo
 * nome — cosi' "item.favourite_count.few":"..." non combacia piu' (dopo
 * "favourite_count" li' c'e' ".few", non le virgolette e i due punti),
 * mentre un campo vero come "favourite_count":0 si' — e si aggiungono
 * "item_box":" e "search_tracking_params":", due campi altrettanto noti
 * dal vecchio elenco JSON (vedi FonteVinted.leggi) e piu' rari di
 * "favourite_count" in un dizionario di traduzioni. Secondo: MotoreRicerca
 * (vedi il commento su "csrfJs", righe cerca CSRF_TOKEN) ha gia' dovuto
 * risolvere lo stesso problema per il token anti-CSRF, e la soluzione li'
 * e' stata guardare "window.__next_f" — il buffer con cui l'App Router di
 * Next.js trasmette i dati della pagina in piu' pezzi, invece del singolo
 * blocco __NEXT_DATA__ di prima. Questa sonda ora guarda anche li', PRIMA
 * di scorrere gli altri <script> uno per uno: e' il posto piu' verosimile
 * per trovare l'elenco vero, dato che il resto della pagina lo conferma
 * gia' funzionante per il token.
 *
 * v1.54.0 (2026-09-16) — SVOLTA: la risposta della v1.53.0 ha chiuso la
 * pista JSON del tutto. "window.__next_f" e' risultato lungo ZERO
 * caratteri (non solo senza marcatori dentro: proprio vuoto/assente), e
 * nessuno dei 64 <script> della pagina conteneva uno dei quattro
 * marcatori — in nessuna forma. Anche le 22 chiamate fetch/XHR
 * campionate nella stessa sessione (stesso "Esporta diagnostica") erano
 * tutte cookie/consenso, notifiche, tracker: nessuna traccia dell'elenco.
 *
 * A quel punto e' arrivata anche una sonda diversa, DomProbe (quella
 * generica che a suo tempo ha trovato le card di Subito guardando il
 * DOM invece del traffico di rete — vedi DomProbe.kt): sulla stessa
 * pagina di ricerca Vinted ha trovato SOLO 4 link a pagine di annuncio
 * reali (pattern "/items/<id>-...", lo stesso che Fonti.kt/
 * DescrizioniVinted usano gia' da tempo per aprire un articolo), cioe'
 * 2 annunci distinti con 2 link ciascuno (tipicamente uno sull'immagine,
 * uno sul titolo) — pero' "cardCandidate: 0": il suo test (un <a> che
 * contenga DENTRO DI SE' sia un'immagine sia un testo con "€") non ha
 * trovato nessuna corrispondenza. Conclusione, non piu' un'ipotesi:
 * Vinted ORA RENDE DAVVERO L'ELENCO COME HTML VERO — niente JSON da
 * nessuna parte da leggere — ma la card di un annuncio non e' un unico
 * <a> che avvolge tutto (immagine + prezzo insieme): probabilmente e' un
 * contenitore (<div>/<article>) con DENTRO due <a> separati (immagine,
 * titolo) e il prezzo scritto altrove nello stesso contenitore, non
 * dentro nessuno dei due link. Il test generico di DomProbe non lo vede
 * per questo, non perche' il prezzo non ci sia.
 *
 * Cambio di strategia per questa sonda: non si cerca piu' JSON, si va
 * a caccia della struttura DOM vera intorno ai link /items/ gia' noti
 * buoni. Per ciascuno dei primi annunci trovati sulla pagina: si parte
 * dal link, si sale di genitore in genitore (fino a 9 livelli) e a ogni
 * livello si segna se quel nodo contiene un'immagine e un testo con "€"
 * — il primo livello che ha ENTRAMBI e' probabilmente la card intera, e
 * se ne riporta l'HTML vero (fino a 2500 caratteri) cosi' si vede a
 * occhio come e' fatta davvero. Si riportano anche gli attributi "data-"
 * di ogni livello (un data-testid tipo "item-box" sarebbe la versione
 * DOM dello stesso concetto del vecchio campo JSON "item_box" cercato
 * dalla v1.53.0 — vale la pena guardarci).
 *
 * Le fasi 1-3 (window.__next_f, __NEXT_DATA__, script) restano: costano
 * poco e chiudono la domanda "non e' tornato tutto d'un tratto JSON?"
 * per le prossime volte, senza doverlo dare per scontato in eterno.
 *
 * COSA FA QUESTA SONDA
 * Attiva SOLO in "Modalita' sonda" e SOLO sulla pagina di ricerca/catalogo
 * di Vinted (l'indirizzo contiene "search_text=" o il percorso contiene
 * "/catalog"). In ordine:
 *   1. "window.__next_f" (il buffer di streaming dell'App Router): se un
 *      marcatore compare li' dentro, si riporta un pezzo intorno al primo
 *      trovato.
 *   2. "__NEXT_DATA__", per completezza (confermato assente due volte, ma
 *      il controllo costa nulla).
 *   3. Tutti gli altri <script> della pagina, uno per uno, senza fermarsi
 *      al primo.
 *   4. NUOVO (v1.54.0): scansione del DOM vero. Trova tutti i link
 *      "/items/<id>", per i primi 3 id distinti risale i genitori cercando
 *      il primo livello con immagine + testo "€" insieme, e riporta la
 *      struttura (tag e attributi data-/id/class a ogni livello) piu'
 *      l'HTML vero di quel livello.
 *
 * Il risultato va nello stesso canale delle chiamate campionate (reportApi
 * -> ApiLog -> "api.json" in "Esporta diagnostica"), sotto il metodo
 * "SONDA-CATALOGO": compare insieme al resto, non serve un file a parte.
 *
 * QUESTA VERSIONE NON CAMBIA NULLA DI VISIBILE: e' solo la sonda. Una volta
 * letta la sua risposta si sapra' come cambiare FonteVinted.leggi() per
 * leggere l'elenco dal DOM invece che da una risposta JSON.
 *
 * Nota sintassi: niente template literal e niente simbolo dollaro nel JS,
 * come nel resto delle sonde di questo progetto (vedi DomProbe.kt e
 * DescrizioniVinted.scriptSonda).
 */
object SondaCatalogoVinted {

    /*
     * --- versione precedente (v1.53.0, fasi 1-3: window.__next_f risultato
     *     lungo zero, __NEXT_DATA__ assente, nessun marcatore in 64 script —
     *     pista JSON chiusa, nessuna scansione del DOM) ---
     * fun script(ponte: String): String = """
     * (function () {
     *   try {
     *     var href = String(location.href || '');
     *     var percorso = String(location.pathname || '');
     *     var isCatalogo = href.indexOf('search_text=') >= 0 || percorso.indexOf('/catalog') >= 0;
     *     if (!isCatalogo) return;
     *
     *     var pezzi = [];
     *     var MARCATORI = ['catalog_items', 'favourite_count":', 'item_box":', 'search_tracking_params":'];
     *
     *     function trovaTutti(testo) {
     *       var out = [];
     *       for (var m = 0; m < MARCATORI.length; m++) {
     *         var idx = testo.indexOf(MARCATORI[m]);
     *         if (idx >= 0) out.push({ marcatore: MARCATORI[m], idx: idx });
     *       }
     *       return out;
     *     }
     *
     *     function riporta(dove, testo) {
     *       var trov = trovaTutti(testo);
     *       if (trov.length === 0) return false;
     *       for (var k = 0; k < trov.length; k++) {
     *         var t = trov[k];
     *         pezzi.push('[' + dove + ', marcatore "' + t.marcatore + '" a ' + t.idx + '] ' +
     *           testo.slice(Math.max(0, t.idx - 80), t.idx + 1200));
     *       }
     *       return true;
     *     }
     *
     *     var trovatoFlight = false;
     *     try {
     *       var buf = (window.__next_f || []).map(function (x) { return (x && x[1]) || ''; }).join('');
     *       pezzi.push('[window.__next_f] lunghezza=' + buf.length);
     *       trovatoFlight = riporta('window.__next_f', buf);
     *     } catch (e) { pezzi.push('[window.__next_f] errore: ' + String(e)); }
     *
     *     var nd = document.getElementById('__NEXT_DATA__');
     *     if (nd) {
     *       var t = nd.textContent || '';
     *       pezzi.push('[__NEXT_DATA__] lunghezza=' + t.length + ' inizio=' + t.slice(0, 300));
     *       riporta('__NEXT_DATA__', t);
     *     } else {
     *       pezzi.push('[__NEXT_DATA__] assente');
     *     }
     *
     *     var scripts = document.querySelectorAll('script');
     *     var trovatoAltrove = false;
     *     for (var i = 0; i < scripts.length; i++) {
     *       var s = scripts[i];
     *       if (s.id === '__NEXT_DATA__') continue;
     *       var c = s.textContent || '';
     *       if (riporta('script #' + i, c)) trovatoAltrove = true;
     *     }
     *     if (!trovatoFlight && !trovatoAltrove) {
     *       pezzi.push('[nessun marcatore trovato da nessuna parte] script totali: ' + scripts.length);
     *     }
     *
     *     window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', 200, pezzi.join('\n---\n'));
     *   } catch (e) {
     *     try { window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', -1, String(e)); } catch (e2) {}
     *   }
     * })();
     * """.trimIndent()
     * --- fine versione precedente ---
     */
    fun script(ponte: String): String = """
    (function () {
      try {
        var href = String(location.href || '');
        var percorso = String(location.pathname || '');
        var isCatalogo = href.indexOf('search_text=') >= 0 || percorso.indexOf('/catalog') >= 0;
        if (!isCatalogo) return;

        var pezzi = [];
        // v1.53.0 — con virgolette e due punti: un campo vero, non una
        // chiave di traduzione tipo "item.favourite_count.few".
        var MARCATORI = ['catalog_items', 'favourite_count":', 'item_box":', 'search_tracking_params":'];

        function trovaTutti(testo) {
          var out = [];
          for (var m = 0; m < MARCATORI.length; m++) {
            var idx = testo.indexOf(MARCATORI[m]);
            if (idx >= 0) out.push({ marcatore: MARCATORI[m], idx: idx });
          }
          return out;
        }

        function riporta(dove, testo) {
          var trov = trovaTutti(testo);
          if (trov.length === 0) return false;
          for (var k = 0; k < trov.length; k++) {
            var t = trov[k];
            pezzi.push('[' + dove + ', marcatore "' + t.marcatore + '" a ' + t.idx + '] ' +
              testo.slice(Math.max(0, t.idx - 80), t.idx + 1200));
          }
          return true;
        }

        // 1. window.__next_f — buffer di streaming dell'App Router di
        // Next.js: confermato lungo zero l'ultima volta, si controlla di
        // nuovo (costa pochissimo) invece di darlo per scontato per sempre.
        var trovatoFlight = false;
        try {
          var buf = (window.__next_f || []).map(function (x) { return (x && x[1]) || ''; }).join('');
          pezzi.push('[window.__next_f] lunghezza=' + buf.length);
          trovatoFlight = riporta('window.__next_f', buf);
        } catch (e) { pezzi.push('[window.__next_f] errore: ' + String(e)); }

        // 2. __NEXT_DATA__, per completezza (confermato assente due volte).
        var nd = document.getElementById('__NEXT_DATA__');
        if (nd) {
          var t = nd.textContent || '';
          pezzi.push('[__NEXT_DATA__] lunghezza=' + t.length + ' inizio=' + t.slice(0, 300));
          riporta('__NEXT_DATA__', t);
        } else {
          pezzi.push('[__NEXT_DATA__] assente');
        }

        // 3. tutti gli altri <script>, uno per uno, senza fermarsi al primo.
        var scripts = document.querySelectorAll('script');
        var trovatoAltrove = false;
        for (var i = 0; i < scripts.length; i++) {
          var s = scripts[i];
          if (s.id === '__NEXT_DATA__') continue;
          var c = s.textContent || '';
          if (riporta('script #' + i, c)) trovatoAltrove = true;
        }
        if (!trovatoFlight && !trovatoAltrove) {
          pezzi.push('[nessun marcatore trovato da nessuna parte] script totali: ' + scripts.length);
        }

        // 4. (v1.54.0) scansione del DOM vero: JSON e script confermati un
        // vicolo cieco per questa pagina, l'elenco e' HTML gia' pronto.
        // Si parte dai link /items/<id>, gia' noti buoni (li usa Fonti.kt
        // per aprire un annuncio da tempo), e si risale ai genitori finche'
        // non si trova un contenitore con immagine + prezzo insieme.
        try {
          var an = document.querySelectorAll('a[href]');
          var trovatiId = {};
          var ordineId = [];
          for (var ai = 0; ai < an.length; ai++) {
            var h2 = an[ai].getAttribute('href') || '';
            var path2;
            try { path2 = new URL(h2, location.href).pathname; } catch (e) { continue; }
            var m2 = path2.match(/^\/items\/(\d+)/);
            if (!m2) continue;
            var id2 = m2[1];
            if (!trovatiId[id2]) { trovatiId[id2] = an[ai]; ordineId.push(id2); }
          }
          pezzi.push('[DOM link /items/] id distinti trovati: ' + ordineId.length +
            (ordineId.length ? (' (' + ordineId.slice(0, 10).join(', ') + ')') : ''));

          function testoBreve(el) {
            try { return (el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 150); }
            catch (e) { return ''; }
          }
          function attrsBrevi(el) {
            var out = {};
            try {
              for (var k2 = 0; k2 < el.attributes.length; k2++) {
                var a2 = el.attributes[k2];
                if (a2.name.indexOf('data-') === 0 || a2.name === 'id' || a2.name === 'class')
                  out[a2.name] = String(a2.value).slice(0, 140);
              }
            } catch (e) {}
            return out;
          }
          function haPrezzo(el) { try { return /€|\beuro\b/i.test(el.textContent || ''); } catch (e) { return false; } }
          function haImg(el) { try { return el.querySelector('img') !== null; } catch (e) { return false; } }

          var campioniDom = [];
          for (var ci = 0; ci < Math.min(ordineId.length, 3); ci++) {
            var idc = ordineId[ci];
            var el = trovatiId[idc];
            var salita = [];
            var cur = el, liv = 0, livelloBuono = -1;
            while (cur && liv < 9) {
              var info = { liv: liv, tag: cur.tagName, attrs: attrsBrevi(cur), prezzo: haPrezzo(cur), img: haImg(cur) };
              salita.push(info);
              if (livelloBuono < 0 && info.prezzo && info.img) livelloBuono = liv;
              cur = cur.parentElement;
              liv++;
            }
            var htmlCampione = '';
            if (livelloBuono >= 0) {
              var nodo = el;
              for (var s2 = 0; s2 < livelloBuono; s2++) nodo = nodo.parentElement;
              htmlCampione = (nodo.outerHTML || '').slice(0, 2500);
            }
            campioniDom.push({
              id: idc, anchorAttrs: attrsBrevi(el), anchorTesto: testoBreve(el),
              salita: salita, livelloConPrezzoEImg: livelloBuono, html: htmlCampione
            });
          }
          pezzi.push('[DOM campioni] ' + JSON.stringify(campioniDom).slice(0, 7000));
        } catch (e) { pezzi.push('[DOM] errore: ' + String(e)); }

        window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', 200, pezzi.join('\n---\n'));
      } catch (e) {
        try { window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', -1, String(e)); } catch (e2) {}
      }
    })();
    """.trimIndent()
}
