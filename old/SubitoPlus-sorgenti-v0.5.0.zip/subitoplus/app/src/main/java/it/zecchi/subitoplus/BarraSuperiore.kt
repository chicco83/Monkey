package it.zecchi.subitoplus

/*
 * Subito+ — barra dei comandi
 * v0.5.0 (2026-08-30) — Fase 4, punto 1
 *
 * Sostituisce la fila di otto pulsanti che occupava la parte alta dello schermo.
 * In vista restano il nome, l'interruttore fra ricerca e navigazione, e il menu:
 * tutto il resto sono comandi che si usano di rado o mai, e stavano li' solo
 * perche' costruire un menu a mano sarebbe costato piu' di una fila di pulsanti.
 *
 * Primo pezzo di interfaccia in Compose. Convive con le viste tradizionali del
 * resto della schermata: e' cosi' che il rifacimento procede un pezzo per volta.
 */

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Tutto lo stato che la barra mostra, in un solo oggetto. */
data class StatoBarra(
    val modoRicerca: Boolean,
    val bloccoAttivo: Boolean,
    val vistaCompatta: Boolean,
    val modoSonda: Boolean,
    val fonteVinted: Boolean,
    val nascosti: Int,
    val riga: String,
    /** null = nessun caricamento; -1 = attesa senza percentuale; 0..100 = avanzamento */
    val avanzamento: Int?
)

/** Le azioni che la barra puo' scatenare. */
class AzioniBarra(
    val cambiaModo: () -> Unit,
    val cambiaBlocco: () -> Unit,
    val cambiaVista: () -> Unit,
    val cambiaSonda: () -> Unit,
    val cambiaFonte: () -> Unit,
    val apriNascosti: () -> Unit,
    val caricaRegole: () -> Unit,
    val analizza: () -> Unit,
    val esporta: () -> Unit,
    val azzera: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarraSuperiore(stato: StatoBarra, azioni: AzioniBarra) {
    Surface(color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth()) {

            TopAppBar(
                title = {
                    Text(
                        if (stato.modoRicerca) "Subito+" else "Navigazione",
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                actions = {
                    IconButton(onClick = azioni.cambiaModo) {
                        Icon(
                            Icons.Filled.Search,
                            contentDescription = if (stato.modoRicerca) "Vai alla navigazione" else "Torna alla ricerca",
                            tint = if (stato.modoRicerca) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Menu(stato, azioni)
                }
            )

            // Avanzamento: sottile, subito sotto la barra, con lo stesso accento del tema.
            when {
                stato.avanzamento == null -> {}
                stato.avanzamento < 0 -> LinearProgressIndicator(Modifier.fillMaxWidth())
                else -> LinearProgressIndicator(
                    progress = { stato.avanzamento / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (stato.riga.isNotBlank()) {
                Text(
                    stato.riga,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 6.dp)
                )
            }

            HorizontalDivider(color = DividerDefaults.color.copy(alpha = 0.4f))
        }
    }
}

@Composable
private fun Menu(stato: StatoBarra, azioni: AzioniBarra) {
    var aperto by remember { mutableStateOf(false) }

    IconButton(onClick = { aperto = true }) {
        Icon(Icons.Filled.MoreVert, contentDescription = "Altri comandi")
    }

    DropdownMenu(expanded = aperto, onDismissRequest = { aperto = false }) {

        voce("Annunci nascosti (${stato.nascosti})", null) { aperto = false; azioni.apriNascosti() }
        voce("Vista compatta", stato.vistaCompatta) { aperto = false; azioni.cambiaVista() }

        HorizontalDivider()

        voce("Blocco pubblicità", stato.bloccoAttivo) { aperto = false; azioni.cambiaBlocco() }
        voce(if (stato.fonteVinted) "Sito: Vinted" else "Sito: Subito", null) { aperto = false; azioni.cambiaFonte() }

        HorizontalDivider()

        voce("Modalità sonda", stato.modoSonda) { aperto = false; azioni.cambiaSonda() }
        voce("Carica regole…", null) { aperto = false; azioni.caricaRegole() }
        voce("Analizza pagina", null) { aperto = false; azioni.analizza() }
        voce("Esporta diagnostica", null) { aperto = false; azioni.esporta() }
        voce("Azzera contatori", null) { aperto = false; azioni.azzera() }
    }
}

/** @param acceso null per un comando semplice, true/false per un interruttore. */
@Composable
private fun voce(testo: String, acceso: Boolean?, azione: () -> Unit) {
    DropdownMenuItem(
        text = { Text(testo) },
        trailingIcon = {
            if (acceso != null) Text(
                if (acceso) "ON" else "OFF",
                style = MaterialTheme.typography.labelSmall,
                color = if (acceso) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        onClick = azione
    )
}
