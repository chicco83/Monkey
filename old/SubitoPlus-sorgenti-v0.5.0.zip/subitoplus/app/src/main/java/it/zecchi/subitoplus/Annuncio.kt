package it.zecchi.subitoplus

/*
 * Subito+ — modello comune degli annunci
 * v0.4.0 (2026-08-30) — nuovo, Fase 3 "Ricerca unificata"
 *
 * Ogni fonte restituisce cose diverse; qui tutto diventa la stessa cosa.
 * L'identificatore porta con se' la fonte ("subito" / "vinted") perche'
 * due piattaforme possono usare lo stesso numero per annunci diversi.
 */

data class Annuncio(
    val fonte: String,          // "subito" | "vinted"
    val id: String,             // identificatore nativo della fonte
    val titolo: String,
    val prezzo: Double?,        // null quando la fonte non lo espone
    val prezzoTesto: String,
    val luogo: String,
    val dataMillis: Long,       // 0 se sconosciuta: finisce in fondo negli ordinamenti per data
    val immagine: String?,
    val url: String
) {
    /** Chiave usata nell'archivio degli scartati. Gli annunci Subito restano
     *  con l'ID nudo per compatibilita' con quanto gia' nascosto dalla v0.3.0. */
    val chiave: String get() = if (fonte == "subito") id else "v:$id"
}
