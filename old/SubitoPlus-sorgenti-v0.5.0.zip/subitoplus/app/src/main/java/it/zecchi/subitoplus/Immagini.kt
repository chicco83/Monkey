package it.zecchi.subitoplus

/*
 * Subito+ — caricatore di miniature
 * v0.4.6 (2026-08-30)
 *
 * PERCHE' LE FOTO ARRIVAVANO CON DECINE DI SECONDI DI RITARDO
 * Due cause distinte, entrambe corrette:
 *
 * 1. La coda era FIFO. Scorrendo la lista, ogni riga che compariva accodava
 *    la sua richiesta IN FONDO: le foto che stavi guardando aspettavano che
 *    finissero tutte quelle delle righe che avevi gia' superato. Ora la coda
 *    e' a pila — l'ultima richiesta e' la prima servita — e le richieste di
 *    righe nel frattempo riciclate vengono scartate senza nemmeno partire.
 *
 * 2. Le foto erano quelle a piena risoluzione (vedi Fonti): diversi mega
 *    l'una per riempire un riquadro di un centimetro.
 *
 * In piu': cache su disco per le sessioni successive, e riduzione decisa in
 * fase di decodifica in base alla dimensione reale del riquadro.
 *
 * --- versione precedente (v0.4.0, 2026-08-30) ---
 * private val pool = Executors.newFixedThreadPool(3)
 * ...carica(): pool.execute { val bmp = scarica(url) ... }
 * --- fine versione precedente ---
 */

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

object Immagini {

    private const val LATO_MAX = 320          // il riquadro in lista e' ~104dp: oltre e' sprecato
    private const val CODA_MAX = 48

    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    /** Coda a pila: l'ultima richiesta accodata e' la prima a partire. */
    private class Pila : LinkedBlockingDeque<Runnable>() {
        override fun offer(e: Runnable): Boolean = super.offerFirst(e)
        override fun offer(e: Runnable, timeout: Long, unit: TimeUnit): Boolean = super.offerFirst(e)
        override fun add(e: Runnable): Boolean { super.addFirst(e); return true }
    }

    private val coda = Pila()
    private val pool = ThreadPoolExecutor(4, 4, 30, TimeUnit.SECONDS, coda).apply {
        allowCoreThreadTimeOut(true)
    }
    private val ui = Handler(Looper.getMainLooper())
    var userAgent: String = ""

    /** Da chiamare una volta all'avvio: abilita la cache su disco di HttpURLConnection. */
    fun preparaCache(ctx: Context) {
        try {
            if (android.net.http.HttpResponseCache.getInstalled() == null)
                android.net.http.HttpResponseCache.install(
                    java.io.File(ctx.cacheDir, "immagini"), 24L * 1024 * 1024
                )
        } catch (t: Throwable) { /* senza cache si continua lo stesso */ }
    }

    fun carica(url: String?, iv: ImageView) {
        iv.tag = url
        if (url.isNullOrBlank()) { iv.setImageBitmap(null); return }
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        iv.setImageBitmap(null)

        // Non lasciare crescere la coda all'infinito: le piu' vecchie non servono piu'.
        while (coda.size > CODA_MAX) coda.pollLast()

        pool.execute {
            // La riga puo' essere stata riciclata mentre la richiesta era in coda.
            if (iv.tag != url) return@execute
            val bmp = scarica(url)
            if (bmp != null) cache.put(url, bmp)
            ui.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
        }
    }

    private fun scarica(url: String): Bitmap? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.useCaches = true
        if (userAgent.isNotBlank()) c.setRequestProperty("User-Agent", userAgent)
        c.setRequestProperty("Accept", "image/webp,image/avif,image/*,*/*;q=0.8")
        val dati = c.inputStream.use { it.readBytes() }

        // Prima si misura, poi si decodifica alla dimensione che serve davvero.
        val misura = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(dati, 0, dati.size, misura)
        var campione = 1
        var lato = maxOf(misura.outWidth, misura.outHeight)
        while (lato / 2 >= LATO_MAX) { campione *= 2; lato /= 2 }

        BitmapFactory.decodeByteArray(dati, 0, dati.size,
            BitmapFactory.Options().apply { inSampleSize = campione })
    } catch (t: Throwable) { null }
}
