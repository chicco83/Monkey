package it.monkey.app

/*
 * Monkey — sonda: dove sta l'elenco degli annunci, ora che Vinted ha
 * cambiato pagina
 * v1.52.0 (2026-09-15) — nuovo
 *
 * IL PROBLEMA
 * "/api/v2/catalog/items" (usato dalla v0.4.0) ha smesso di funzionare:
 * l'utente ha segnalato errore 404, e una diagnostica ("ricerca-diagnostica.txt")
 * ha confermato che non e' un 404 JSON dell'API — e' la pagina generica
 * "non trovato" dell'app (stessa firma SVG gia' vista in passato per una
 * rotta inesistente, vedi DescrizioniVinted.kt). La rotta e' sparita.
 *
 * Una sonda sulla pagina di ricerca VERA di Vinted (Modalita' sonda, tab
 * "Sito", una ricerca fatta li' dentro) non ha mai mostrato nessuna
 * chiamata fetch/XHR che porti l'elenco degli annunci — solo suggerimenti
 * di ricerca, ricerche recenti, "promoted_closets" (gli annunci in
 * evidenza), banner. Ipotesi, sulla scorta di cosa e' gia' successo per la
 * descrizione dell'annuncio (v1.43.0, JSON-LD nell'HTML invece di una
 * chiamata a parte): l'elenco vero e proprio ora arriva DENTRO la pagina
 * quando la pagina stessa viene renderizzata (lato server), non con una
 * fetch separata che la sonda fetch/XHR possa vedere.
 *
 * v1.53.0 (2026-09-15) — CORREZIONE, con la prima risposta in mano: la
 * v1.52.0 ha confermato due cose. Primo, "__NEXT_DATA__" (il contenitore
 * classico del vecchio Next.js "Pages Router") e' assente — Vinted usa
 * l'"App Router" piu' recente, che non lo scrive piu'. Secondo, il
 * marcatore "favourite_count" ha dato un FALSO POSITIVO: ha trovato uno
 * script col dizionario delle traduzioni dell'interfaccia, dove compare
 * dentro chiavi come "item.favourite_count.few" — un testo per l'etichetta
 * "3 preferiti", non un campo di un annuncio vero. La sonda si e' fermata
 * li' (primo trovato, si interrompe) senza controllare il resto.
 *
 * Due correzioni. Primo, i marcatori diventano piu' precisi: si cerca
 * 'favourite_count":' (virgolette e due punti INCLUSI) invece del solo
 * nome — cosi' "item.favourite_count.few":"..." non combacia piu' (dopo
 * "favourite_count" li' c'e' ".few", non le virgolette e i due punti),
 * mentre un campo vero come "favourite_count":0 si' — e si aggiungono
 * "item_box":" e "search_tracking_params":", due campi altrettanto noti
 * dal vecchio elenco JSON (vedi FonteVinted.leggi) e piu' rari di
 * "favourite_count" in un dizionario di traduzioni. Secondo: MotoreRicerca
 * (vedi il commento su "csrfJs", righe cerca CSRF_TOKEN) ha gia' dovuto
 * risolvere lo stesso problema per il token anti-CSRF, e la soluzione li'
 * e' stata guardare "window.__next_f" — il buffer con cui l'App Router di
 * Next.js trasmette i dati della pagina in piu' pezzi, invece del singolo
 * blocco __NEXT_DATA__ di prima. Questa sonda ora guarda anche li', PRIMA
 * di scorrere gli altri <script> uno per uno: e' il posto piu' verosimile
 * per trovare l'elenco vero, dato che il resto della pagina lo conferma
 * gia' funzionante per il token.
 *
 * COSA FA QUESTA SONDA
 * Attiva SOLO in "Modalita' sonda" e SOLO sulla pagina di ricerca/catalogo
 * di Vinted (l'indirizzo contiene "search_text=" o il percorso contiene
 * "/catalog"). In ordine:
 *   1. "window.__next_f" (il buffer di streaming dell'App Router, vedi
 *      sopra): se un marcatore compare li' dentro, si riporta un pezzo
 *      intorno al primo trovato.
 *   2. "__NEXT_DATA__", per completezza (confermato assente, ma se Vinted
 *      dovesse mai tornare al Pages Router non costa nulla controllarlo).
 *   3. Tutti gli altri <script> della pagina, uno per uno — senza
 *      fermarsi al primo: si scorre l'intera lista e si riporta ogni
 *      script in cui compare un marcatore, non solo il primo (era proprio
 *      il fermarsi al primo ad aver nascosto il falso positivo la volta
 *      scorsa).
 *
 * Il risultato va nello stesso canale delle chiamate campionate (reportApi
 * -> ApiLog -> "api.json" in "Esporta diagnostica"), sotto il metodo
 * "SONDA-CATALOGO": compare insieme al resto, non serve un file a parte.
 *
 * QUESTA VERSIONE NON CAMBIA NULLA DI VISIBILE: e' solo la sonda. Una volta
 * letta la sua risposta si sapra' se e come cambiare FonteVinted.leggi()
 * per leggere l'elenco da dove sta davvero ora.
 *
 * Nota sintassi: niente template literal e niente simbolo dollaro nel JS,
 * come nel resto delle sonde di questo progetto (vedi DomProbe.kt e
 * DescrizioniVinted.scriptSonda).
 */
object SondaCatalogoVinted {

    /*
     * --- versione precedente (v1.52.0, un solo marcatore trovato — falso
     *     positivo dentro un dizionario di traduzioni, e la ricerca si
     *     fermava li' senza controllare window.__next_f ne' il resto degli
     *     script) ---
     * fun script(ponte: String): String = """
     * (function () {
     *   try {
     *     var href = String(location.href || '');
     *     var percorso = String(location.pathname || '');
     *     var isCatalogo = href.indexOf('search_text=') >= 0 || percorso.indexOf('/catalog') >= 0;
     *     if (!isCatalogo) return;
     *
     *     var pezzi = [];
     *     var MARCATORI = ['catalog_items', 'favourite_count'];
     *
     *     function cercaMarcatore(testo) {
     *       for (var m = 0; m < MARCATORI.length; m++) {
     *         var idx = testo.indexOf(MARCATORI[m]);
     *         if (idx >= 0) return { marcatore: MARCATORI[m], idx: idx };
     *       }
     *       return null;
     *     }
     *
     *     var nd = document.getElementById('__NEXT_DATA__');
     *     if (nd) {
     *       var t = nd.textContent || '';
     *       pezzi.push('[__NEXT_DATA__] lunghezza=' + t.length + ' inizio=' + t.slice(0, 500));
     *       var trovNd = cercaMarcatore(t);
     *       if (trovNd) {
     *         pezzi.push('[__NEXT_DATA__ marcatore "' + trovNd.marcatore + '" a ' + trovNd.idx + '] ' +
     *           t.slice(Math.max(0, trovNd.idx - 80), trovNd.idx + 1200));
     *       } else {
     *         pezzi.push('[__NEXT_DATA__] nessun marcatore dentro');
     *       }
     *     } else {
     *       pezzi.push('[__NEXT_DATA__] assente');
     *     }
     *
     *     var scripts = document.querySelectorAll('script');
     *     var trovatoAltrove = false;
     *     for (var i = 0; i < scripts.length; i++) {
     *       var s = scripts[i];
     *       if (s.id === '__NEXT_DATA__') continue;
     *       var c = s.textContent || '';
     *       var trov = cercaMarcatore(c);
     *       if (trov) {
     *         pezzi.push('[altro script #' + i + ', marcatore "' + trov.marcatore + '"] ' +
     *           c.slice(Math.max(0, trov.idx - 80), trov.idx + 1200));
     *         trovatoAltrove = true;
     *         break;
     *       }
     *     }
     *     if (!trovatoAltrove) pezzi.push('[altri script] nessun marcatore trovato (script totali: ' + scripts.length + ')');
     *
     *     window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', 200, pezzi.join('\n---\n'));
     *   } catch (e) {
     *     try { window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', -1, String(e)); } catch (e2) {}
     *   }
     * })();
     * """.trimIndent()
     * --- fine versione precedente ---
     */
    fun script(ponte: String): String = """
    (function () {
      try {
        var href = String(location.href || '');
        var percorso = String(location.pathname || '');
        var isCatalogo = href.indexOf('search_text=') >= 0 || percorso.indexOf('/catalog') >= 0;
        if (!isCatalogo) return;

        var pezzi = [];
        // v1.53.0 — con virgolette e due punti: un campo vero, non una
        // chiave di traduzione tipo "item.favourite_count.few".
        var MARCATORI = ['catalog_items', 'favourite_count":', 'item_box":', 'search_tracking_params":'];

        function trovaTutti(testo) {
          var out = [];
          for (var m = 0; m < MARCATORI.length; m++) {
            var idx = testo.indexOf(MARCATORI[m]);
            if (idx >= 0) out.push({ marcatore: MARCATORI[m], idx: idx });
          }
          return out;
        }

        function riporta(dove, testo) {
          var trov = trovaTutti(testo);
          if (trov.length === 0) return false;
          for (var k = 0; k < trov.length; k++) {
            var t = trov[k];
            pezzi.push('[' + dove + ', marcatore "' + t.marcatore + '" a ' + t.idx + '] ' +
              testo.slice(Math.max(0, t.idx - 80), t.idx + 1200));
          }
          return true;
        }

        // 1. window.__next_f — il buffer di streaming dell'App Router di
        // Next.js (vedi il commento in cima al file): stesso posto gia'
        // usato con successo da MotoreRicerca per il token CSRF.
        var trovatoFlight = false;
        try {
          var buf = (window.__next_f || []).map(function (x) { return (x && x[1]) || ''; }).join('');
          pezzi.push('[window.__next_f] lunghezza=' + buf.length);
          trovatoFlight = riporta('window.__next_f', buf);
        } catch (e) { pezzi.push('[window.__next_f] errore: ' + String(e)); }

        // 2. __NEXT_DATA__, per completezza (confermato assente la volta
        // scorsa, ma il controllo costa nulla).
        var nd = document.getElementById('__NEXT_DATA__');
        if (nd) {
          var t = nd.textContent || '';
          pezzi.push('[__NEXT_DATA__] lunghezza=' + t.length + ' inizio=' + t.slice(0, 300));
          riporta('__NEXT_DATA__', t);
        } else {
          pezzi.push('[__NEXT_DATA__] assente');
        }

        // 3. tutti gli altri <script>, uno per uno, senza fermarsi al primo.
        var scripts = document.querySelectorAll('script');
        var trovatoAltrove = false;
        for (var i = 0; i < scripts.length; i++) {
          var s = scripts[i];
          if (s.id === '__NEXT_DATA__') continue;
          var c = s.textContent || '';
          if (riporta('script #' + i, c)) trovatoAltrove = true;
        }
        if (!trovatoFlight && !trovatoAltrove) {
          pezzi.push('[nessun marcatore trovato da nessuna parte] script totali: ' + scripts.length);
        }

        window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', 200, pezzi.join('\n---\n'));
      } catch (e) {
        try { window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', -1, String(e)); } catch (e2) {}
      }
    })();
    """.trimIndent()
}
