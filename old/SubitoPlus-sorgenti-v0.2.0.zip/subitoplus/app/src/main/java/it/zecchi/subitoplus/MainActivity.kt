package it.zecchi.subitoplus

/*
 * Subito+ — Fase 1 "Zero pubblicità"
 * v0.2.0 (2026-08-30)
 *
 * Novita' rispetto alla v0.1.0 (sonda):
 *  - shouldInterceptRequest adesso BLOCCA davvero, in base a Regole (assets/regole.json)
 *  - i filtri cosmetici vengono iniettati a document-start, quindi senza lampeggio
 *  - le regole si possono sostituire dall'app ("Regole") senza ricompilare
 *  - la sonda resta a bordo, aggiornata alla v0.2.0, per preparare la Fase 2
 *
 * Cosa NON fa ancora: nascondere i singoli annunci, ricerche salvate, notifiche.
 */

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var stato: TextView
    private lateinit var prefs: SharedPreferences
    private lateinit var bottoneBlocco: Button

    @Volatile private var ultimoReportDom: String = "{}"

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val RC_FILE = 1001
    private val RC_REGOLE = 1002

    /** Interruttore generale del blocco: utile per confrontare prima/dopo e per sbloccarsi se qualcosa si rompe. */
    private var bloccoAttivo = true

    private var modoUa = 0

    /** Riferimento allo script iniettato a document-start, da rimuovere quando cambiano le regole. */
    private var scriptCosmetico: androidx.webkit.ScriptHandler? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("subitoplus", MODE_PRIVATE)
        bloccoAttivo = prefs.getBoolean("bloccoAttivo", true)

        Regole.carica(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val barra = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
        }
        bottoneBlocco = bottone(etichettaBlocco()) { cambiaBlocco() }
        barra.addView(bottoneBlocco)
        barra.addView(bottone("Analizza") { analizzaPagina() })
        barra.addView(bottone("Esporta") { esporta() })
        barra.addView(bottone("Regole") { scegliRegole() })
        barra.addView(bottone("UA") { cambiaUa() })
        barra.addView(bottone("Azzera") {
            RequestLog.reset(); Regole.bloccate = 0; ultimoReportDom = "{}"; aggiornaStato()
        })
        root.addView(HorizontalScrollView(this).apply { addView(barra) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        stato = TextView(this).apply { setPadding(16, 0, 16, 8); textSize = 12f }
        root.addView(stato)

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        configuraWebView()
        registraCosmetici()
        web.loadUrl("https://www.subito.it/")
        aggiornaStato()
    }

    private fun bottone(testo: String, azione: () -> Unit) = Button(this).apply {
        text = testo; textSize = 13f; setOnClickListener { azione() }
    }

    private fun etichettaBlocco() = if (bloccoAttivo) "Blocco ON" else "Blocco OFF"

    private fun cambiaBlocco() {
        bloccoAttivo = !bloccoAttivo
        prefs.edit().putBoolean("bloccoAttivo", bloccoAttivo).apply()
        bottoneBlocco.text = etichettaBlocco()
        registraCosmetici()
        web.reload()
    }

    // ------------------------------------------------------------------
    // Configurazione WebView
    // ------------------------------------------------------------------
    private fun configuraWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = true
        if (modoUa == 1) s.userAgentString = WebSettings.getDefaultUserAgent(this).replace("; wv", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        WebView.setWebContentsDebuggingEnabled(true)

        web.addJavascriptInterface(Bridge(), "SondaBridge")

        web.webViewClient = object : WebViewClient() {

            /*
             * Il punto in cui si decide tutto.
             *
             * --- versione precedente (v0.1.0, 2026-08-30): sola osservazione ---
             * request?.url?.toString()?.let { RequestLog.record(it) }
             * return null
             * --- fine versione precedente ---
             */
            override fun shouldInterceptRequest(
                view: WebView?, request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                RequestLog.record(url)                       // il registro resta: serve a verificare
                if (!bloccoAttivo) return null
                if (!Regole.blocca(url)) return null
                Regole.bloccate++
                // Risposta vuota 200: piu' silenziosa di un errore, non fa ritentare gli script.
                return WebResourceResponse(
                    "text/plain", "utf-8",
                    ByteArrayInputStream(ByteArray(0))
                )
            }

            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                if (u.scheme != "http" && u.scheme != "https") {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, u)); true } catch (t: Throwable) { true }
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                // Rete di sicurezza: se il dispositivo non supporta l'iniezione a document-start,
                // il CSS entra comunque qui, con un possibile lampeggio.
                if (bloccoAttivo && !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))
                    view?.evaluateJavascript(Cosmetici.script(Regole.cssNascondi), null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                aggiornaStato()
                view?.postDelayed({ analizzaPagina() }, 1500)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try { startActivityForResult(params!!.createIntent(), RC_FILE); true }
                catch (t: Throwable) { fileCallback = null; false }
            }
            override fun onProgressChanged(view: WebView?, newProgress: Int) = aggiornaStato()
        }
    }

    /**
     * Iniezione dei filtri cosmetici prima di ogni script della pagina.
     * Va rifatta ogni volta che cambiano le regole o l'interruttore del blocco.
     */
    private fun registraCosmetici() {
        scriptCosmetico?.remove()
        scriptCosmetico = null
        if (!bloccoAttivo) return
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        scriptCosmetico = WebViewCompat.addDocumentStartJavaScript(
            web,
            Cosmetici.script(Regole.cssNascondi),
            setOf("https://*.subito.it", "https://subito.it")
        )
    }

    // ------------------------------------------------------------------
    // Ponte JS -> Kotlin
    // ------------------------------------------------------------------
    inner class Bridge {
        @JavascriptInterface
        fun report(json: String) {
            ultimoReportDom = json
            runOnUiThread { aggiornaStato() }
        }
    }

    private fun analizzaPagina() = web.evaluateJavascript(DomProbe.script(Regole.cssNascondi), null)

    private fun cambiaUa() {
        modoUa = if (modoUa == 0) 1 else 0
        web.settings.userAgentString = if (modoUa == 1)
            WebSettings.getDefaultUserAgent(this).replace("; wv", "")
        else WebSettings.getDefaultUserAgent(this)
        toast(if (modoUa == 1) "UA senza marcatore WebView" else "UA di sistema")
        web.reload()
    }

    private fun aggiornaStato() {
        val j = try { org.json.JSONObject(ultimoReportDom) } catch (t: Throwable) { org.json.JSONObject() }
        val card = j.optInt("cardCandidate", -1)
        val residui = j.optJSONArray("slotAdvAncoraVisibili")?.length() ?: -1
        stato.text = "richieste ${RequestLog.totalRequests()} · bloccate ${Regole.bloccate} · " +
                "card ${if (card < 0) "-" else card} · slot adv visibili ${if (residui < 0) "-" else residui} · " +
                "regole ${Regole.versioneRegole} (${Regole.origine})"
    }

    // ------------------------------------------------------------------
    // Import regole e export diagnostica
    // ------------------------------------------------------------------
    private fun scegliRegole() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        try { startActivityForResult(i, RC_REGOLE) } catch (t: Throwable) { toast("Nessun selettore file") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            RC_FILE -> {
                val res = if (resultCode == Activity.RESULT_OK)
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
                fileCallback?.onReceiveValue(res); fileCallback = null
            }
            RC_REGOLE -> {
                if (resultCode == Activity.RESULT_OK) {
                    val uri = data?.data
                    val testo = try {
                        uri?.let { contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() } }
                    } catch (t: Throwable) { null }
                    if (testo != null && Regole.importa(this, testo)) {
                        registraCosmetici(); web.reload()
                        toast("Regole ${Regole.versioneRegole} attive")
                    } else toast("File regole non valido")
                }
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun esporta() {
        val ok = listOf(
            scriviInDownload("requests.json", RequestLog.requestsJson()),
            scriviInDownload("blocklist.json", RequestLog.blocklistJson()),
            scriviInDownload("selectors.json", ultimoReportDom)
        ).all { it }
        toast(if (ok) "Esportati in Download/SubitoPlus" else "Esportazione non riuscita")
    }

    private fun scriviInDownload(nome: String, contenuto: String): Boolean = try {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nome)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/SubitoPlus")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
        uri?.let {
            contentResolver.openOutputStream(it, "wt")?.use { os -> os.write(contenuto.toByteArray(Charsets.UTF_8)) }
            true
        } ?: false
    } catch (t: Throwable) { false }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
