package it.zecchi.subitoplus

/*
 * Subito+ — caricatore di miniature
 * v0.4.0 (2026-08-30) — nuovo, Fase 3
 *
 * Minimo indispensabile per non aggiungere una libreria: cache in memoria
 * limitata, pochi thread, e lo stesso user agent del WebView cosi' le richieste
 * alle CDN non si distinguono da quelle della navigazione normale.
 */

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object Immagini {

    private val cache = object : LruCache<String, Bitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    var userAgent: String = ""

    fun carica(url: String?, iv: ImageView) {
        iv.setTag(url)
        if (url.isNullOrBlank()) { iv.setImageBitmap(null); return }
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        iv.setImageBitmap(null)
        pool.execute {
            val bmp = scarica(url)
            if (bmp != null) cache.put(url, bmp)
            ui.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
        }
    }

    private fun scarica(url: String): Bitmap? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        if (userAgent.isNotBlank()) c.setRequestProperty("User-Agent", userAgent)
        c.inputStream.use { ins ->
            val opz = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeStream(ins, null, opz)
        }
    } catch (t: Throwable) { null }
}
