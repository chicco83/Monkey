package it.zecchi.subitoplus

/*
 * Subito+ — Fase 3 "Ricerca unificata"
 * v0.4.4 (2026-08-30)
 *
 * Novita' rispetto alla v0.2.0:
 *  - ogni card annuncio riceve un pulsante di scarto; l'ID finisce in un archivio locale
 *    e la card non viene piu' disegnata, in questa e in tutte le ricerche successive
 *  - schermata "Nascosti" con ripristino singolo o totale, esportabile e importabile
 *  - la home si apre sulla sezione scelta nelle regole (Market) invece che su Motori
 *  - il pulsante "Cerca" della barra in basso riporta al modulo di ricerca
 *
 * v0.3.1 aggiunge la sonda che campiona le RISPOSTE delle API (ScriptApi/ApiLog)
 * e il cambio fonte Subito / Vinted: sono i dati con cui verra' costruita
 * la ricerca unificata della Fase 3.
 *
 * v0.3.2 — riduzione delle tracce lasciate nella pagina:
 *   - un solo ponte JS, con nome casuale per installazione e non enumerabile (Prologo)
 *   - classi e attributi iniettati con prefisso casuale, non piu' "sp-*"
 *   - la sostituzione di fetch/XHR (la parte piu' riconoscibile) e' spenta di default
 *     e si accende solo quando serve raccogliere campioni
 *
 * v0.4.0 — l'app si apre sulla ricerca unificata Subito + Vinted (VistaRicerca,
 * MotoreRicerca, Fonti). Il WebView resta ed e' dove si compra, si vende e si
 * scrive al venditore: toccando un risultato ci si arriva.
 *
 * v0.4.1 — correzioni sull'apertura degli annunci:
 *   - il WebView non precarica piu' la home all'avvio: la richiesta della scheda
 *     non deve piu' contendersi il posto con un caricamento gia' in corso
 *   - la scheda aperta dalla ricerca azzera la cronologia, cosi' "indietro"
 *     riporta ai risultati e non a una home di passaggio
 *   - gli indirizzi relativi diventano assoluti nell'adattatore (vedi Fonti)
 *
 * v0.4.4 — barra di avanzamento in alto: determinata sul caricamento delle
 * pagine web, indeterminata mentre le fonti rispondono alla ricerca.
 * Anticipa uno dei punti del restyling perche' l'attesa senza segnale era
 * il difetto piu' fastidioso da usare.
 *
 * Cosa NON fa ancora: ricerche salvate e notifiche (Fase 5).
 */

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var stato: TextView
    private lateinit var prefs: SharedPreferences
    private lateinit var bottoneBlocco: Button
    private lateinit var bottoneNascosti: Button
    private lateinit var bottoneVista: Button
    private lateinit var bottoneFonte: Button
    private lateinit var bottoneSonda: Button

    @Volatile private var ultimoReportDom: String = "{}"

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val RC_FILE = 1001
    private val RC_REGOLE = 1002

    /** Interruttore generale del blocco: utile per confrontare prima/dopo e per sbloccarsi se qualcosa si rompe. */
    private var bloccoAttivo = true

    private var modoUa = 0

    /** v0.3.0 — vista compatta: foto piccola a sinistra, testo a destra. Scelta ricordata. */
    private var vistaCompatta = false

    /** v0.3.1 — fonte attualmente aperta nel WebView: 0 = Subito, 1 = Vinted. */
    /*
     * v0.3.2 — nomi generati una volta per installazione e conservati.
     * Un nome fisso e parlante ("SubitoPlus") sarebbe di per se' un'impronta.
     */
    private lateinit var nomePonte: String
    private lateinit var pref: String

    /** Modalita' sonda: sostituisce fetch/XHR per campionare le risposte. Spenta di default. */
    private var modoSonda = false

    /** v0.4.0 — schermata attiva: true = ricerca unificata, false = navigazione web. */
    private var modoRicerca = true
    private lateinit var motore: MotoreRicerca
    private lateinit var vista: VistaRicerca
    private lateinit var contenitore: FrameLayout
    private lateinit var bottoneModo: Button
    /** v0.4.4 — barra sottile sotto la barra dei comandi. */
    private lateinit var avanzamento: ProgressBar

    private var fonte = 0
    private val HOME = arrayOf("https://www.subito.it/", "https://www.vinted.it/")

    /** Riferimento allo script iniettato a document-start, da rimuovere quando cambiano le regole. */
    private var scriptPrologo: androidx.webkit.ScriptHandler? = null
    private var scriptCosmetico: androidx.webkit.ScriptHandler? = null
    private var scriptAnnunci: androidx.webkit.ScriptHandler? = null
    private var scriptApi: androidx.webkit.ScriptHandler? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("subitoplus", MODE_PRIVATE)
        bloccoAttivo = prefs.getBoolean("bloccoAttivo", true)
        vistaCompatta = prefs.getBoolean("vistaCompatta", false)
        modoSonda = prefs.getBoolean("modoSonda", false)
        nomePonte = nomeCasuale("nomePonte", "_")
        pref = nomeCasuale("prefisso", "")

        Regole.carica(this)
        Nascosti.carica(this)   // v0.3.0

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val barra = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
        }
        bottoneModo = bottone(etichettaModo()) { cambiaModo() }                 // v0.4.0
        barra.addView(bottoneModo)
        bottoneBlocco = bottone(etichettaBlocco()) { cambiaBlocco() }
        barra.addView(bottoneBlocco)
        bottoneNascosti = bottone(etichettaNascosti()) { mostraNascosti() }   // v0.3.0
        barra.addView(bottoneNascosti)
        bottoneSonda = bottone(etichettaSonda()) { cambiaSonda() }              // v0.3.2
        barra.addView(bottoneSonda)
        bottoneFonte = bottone(etichettaFonte()) { cambiaFonte() }              // v0.3.1
        barra.addView(bottoneFonte)
        bottoneVista = bottone(etichettaVista()) { cambiaVista() }            // v0.3.0
        barra.addView(bottoneVista)
        barra.addView(bottone("Analizza") { analizzaPagina() })
        barra.addView(bottone("Esporta") { esporta() })
        barra.addView(bottone("Regole") { scegliRegole() })
        barra.addView(bottone("UA") { cambiaUa() })
        barra.addView(bottone("Azzera") {
            RequestLog.reset(); Regole.bloccate = 0; ApiLog.reset(); ultimoReportDom = "{}"; aggiornaStato()
        })
        root.addView(HorizontalScrollView(this).apply { addView(barra) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        stato = TextView(this).apply { setPadding(16, 0, 16, 8); textSize = 12f }
        root.addView(stato)

        // v0.4.4 — barra di avanzamento, sempre in cima a qualsiasi schermata
        val tinta = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#C07A22"))
        avanzamento = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = tinta
            indeterminateTintList = tinta
            progressBackgroundTintList =
                android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#00000000"))
            visibility = android.view.View.GONE
        }
        root.addView(avanzamento, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            (4 * resources.displayMetrics.density).toInt()))

        web = WebView(this)
        contenitore = FrameLayout(this)
        contenitore.addView(web, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(contenitore, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        configuraWebView()
        registraCosmetici()
        /*
         * --- versione precedente (v0.4.0, 2026-08-30) ---
         * web.loadUrl(HOME[fonte])
         * --- fine versione precedente ---
         * Il precaricamento della home entrava in conflitto con la prima
         * apertura di una scheda: la navigazione gia' in corso vinceva, e si
         * finiva sulla home invece che sull'annuncio. Ora si carica su richiesta.
         */

        // v0.4.0 — schermata di ricerca sopra il WebView, che resta vivo sotto
        motore = MotoreRicerca(this, nomePonte, contenitore)
        Immagini.userAgent = WebSettings.getDefaultUserAgent(this)
        vista = VistaRicerca(
            this, motore,
            caricamento = { attivo -> mostraAttesa(attivo) },   // v0.4.4
            apri = { a -> apriAnnuncio(a) },
            nascondi = { a ->
                Nascosti.aggiungi(this, a.chiave, a.titolo)
                vista.rimuovi(a)
                bottoneNascosti.text = etichettaNascosti()
                aggiornaStato()
            }
        )
        contenitore.addView(vista.radice, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        motore.prepara(FONTI)
        applicaModo()
        aggiornaStato()
    }

    private fun bottone(testo: String, azione: () -> Unit) = Button(this).apply {
        text = testo; textSize = 13f; setOnClickListener { azione() }
    }

    private fun etichettaBlocco() = if (bloccoAttivo) "Blocco ON" else "Blocco OFF"

    private fun cambiaBlocco() {
        bloccoAttivo = !bloccoAttivo
        prefs.edit().putBoolean("bloccoAttivo", bloccoAttivo).apply()
        bottoneBlocco.text = etichettaBlocco()
        registraCosmetici()
        web.reload()
    }

    // ------------------------------------------------------------------
    // Configurazione WebView
    // ------------------------------------------------------------------
    private fun configuraWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = true
        if (modoUa == 1) s.userAgentString = WebSettings.getDefaultUserAgent(this).replace("; wv", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        WebView.setWebContentsDebuggingEnabled(true)

        /*
         * --- versione precedente (v0.3.1, 2026-08-30): tre ponti con nomi parlanti ---
         * web.addJavascriptInterface(Bridge(), "SondaBridge")
         * web.addJavascriptInterface(PonteAnnunci(), "SubitoPlus")
         * web.addJavascriptInterface(PonteApi(), "SondaApi")
         * --- fine versione precedente ---
         * v0.3.2: uno solo, con nome casuale, poi reso non enumerabile dal Prologo.
         */
        web.addJavascriptInterface(Ponte(), nomePonte)

        web.webViewClient = object : WebViewClient() {

            /*
             * Il punto in cui si decide tutto.
             *
             * --- versione precedente (v0.1.0, 2026-08-30): sola osservazione ---
             * request?.url?.toString()?.let { RequestLog.record(it) }
             * return null
             * --- fine versione precedente ---
             */
            override fun shouldInterceptRequest(
                view: WebView?, request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                RequestLog.record(url)                       // il registro resta: serve a verificare
                if (!bloccoAttivo) return null
                if (!Regole.blocca(url)) return null
                Regole.bloccate++
                // Risposta vuota 200: piu' silenziosa di un errore, non fa ritentare gli script.
                return WebResourceResponse(
                    "text/plain", "utf-8",
                    ByteArrayInputStream(ByteArray(0))
                )
            }

            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                if (u.scheme != "http" && u.scheme != "https") {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, u)); true } catch (t: Throwable) { true }
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                // Rete di sicurezza: se il dispositivo non supporta l'iniezione a document-start,
                // il CSS entra comunque qui, con un possibile lampeggio.
                if (bloccoAttivo && !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))
                    view?.evaluateJavascript(Cosmetici.script(Regole.cssNascondi, pref), null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (azzeraCronologia) { azzeraCronologia = false; view?.clearHistory() }  // v0.4.1
                aggiornaStato()
                view?.postDelayed({ analizzaPagina() }, 1500)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try { startActivityForResult(params!!.createIntent(), RC_FILE); true }
                catch (t: Throwable) { fileCallback = null; false }
            }
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                // v0.4.4 — avanzamento reale del caricamento pagina
                if (!modoRicerca) {
                    if (newProgress in 1..99) {
                        avanzamento.isIndeterminate = false
                        avanzamento.progress = newProgress
                        avanzamento.visibility = android.view.View.VISIBLE
                    } else {
                        avanzamento.visibility = android.view.View.GONE
                    }
                }
                aggiornaStato()
            }
        }
    }

    /**
     * Iniezione dei filtri cosmetici prima di ogni script della pagina.
     * Va rifatta ogni volta che cambiano le regole o l'interruttore del blocco.
     */
    private fun registraCosmetici() {
        scriptPrologo?.remove(); scriptPrologo = null
        scriptCosmetico?.remove(); scriptCosmetico = null
        scriptAnnunci?.remove(); scriptAnnunci = null
        scriptApi?.remove(); scriptApi = null
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        val origini = setOf("https://*.subito.it", "https://subito.it")
        // v0.3.1 — la sonda API gira anche su Vinted
        val originiTutte = setOf(
            "https://*.subito.it", "https://subito.it",
            "https://*.vinted.it", "https://vinted.it"
        )

        // Il prologo va per primo: nasconde il ponte prima che la pagina possa vederlo.
        scriptPrologo = WebViewCompat.addDocumentStartJavaScript(web, Prologo.script(nomePonte), originiTutte)

        if (bloccoAttivo) scriptCosmetico = WebViewCompat.addDocumentStartJavaScript(
            web, Cosmetici.script(Regole.cssNascondi, pref), origini
        )

        // v0.3.0 — lo script degli annunci e' indipendente dal blocco pubblicita':
        // lo scarto deve funzionare anche con "Blocco OFF".
        scriptAnnunci = WebViewCompat.addDocumentStartJavaScript(
            web,
            ScriptAnnunci.script(Regole.sezioneIniziale, Regole.cercaApreForm, vistaCompatta, nomePonte, pref),
            origini
        )

        /*
         * La sostituzione di fetch e XMLHttpRequest e' la traccia piu' riconoscibile
         * che possiamo lasciare: Function.prototype.toString su fetch non restituisce
         * piu' [native code], e gli script antifrode lo verificano. Quindi si accende
         * solo su richiesta, per il tempo di raccogliere i campioni.
         */
        if (modoSonda)
            scriptApi = WebViewCompat.addDocumentStartJavaScript(web, ScriptApi.script(nomePonte), originiTutte)
    }

    // ------------------------------------------------------------------
    // Ponte JS -> Kotlin
    // ------------------------------------------------------------------


    private fun etichettaNascosti() = "Nascosti ${Nascosti.quanti()}"


    /**
     * Unico ponte JS -> Kotlin. I metodi girano sul thread JS:
     * niente lavoro pesante, niente tocchi alla UI se non via runOnUiThread.
     */
    inner class Ponte {
        @JavascriptInterface
        fun nascondi(id: String, titolo: String) {
            Nascosti.aggiungi(this@MainActivity, id, titolo)
            runOnUiThread { bottoneNascosti.text = etichettaNascosti(); aggiornaStato() }
        }

        @JavascriptInterface
        fun nascostiJson(): String = Nascosti.idJson()

        @JavascriptInterface
        fun reportDom(json: String) {
            ultimoReportDom = json
            runOnUiThread { aggiornaStato() }
        }

        @JavascriptInterface
        fun reportApi(url: String, stato: Int, corpo: String) {
            ApiLog.registra(url, stato, corpo)
            runOnUiThread { aggiornaStato() }
        }
    }

    private fun nomeCasuale(chiave: String, prefisso: String): String {
        prefs.getString(chiave, null)?.let { return it }
        val lettere = "abcdefghijklmnopqrstuvwxyz"
        val alfa = lettere + "0123456789"
        val n = prefisso + lettere.random() + (1..10).map { alfa.random() }.joinToString("")
        prefs.edit().putString(chiave, n).apply()
        return n
    }

    private fun etichettaFonte() = if (fonte == 0) "Fonte Subito" else "Fonte Vinted"

    private fun cambiaFonte() {
        fonte = if (fonte == 0) 1 else 0
        bottoneFonte.text = etichettaFonte()
        modoRicerca = false          // v0.4.1: cambiare fonte significa voler navigare
        applicaModo()
        azzeraCronologia = true
        web.loadUrl(HOME[fonte])
    }

    private fun etichettaModo() = if (modoRicerca) "Ricerca" else "Web"

    private fun cambiaModo() { modoRicerca = !modoRicerca; applicaModo() }

    /** Attesa senza percentuale: le fonti non dicono a che punto sono. */
    private fun mostraAttesa(attivo: Boolean) {
        avanzamento.isIndeterminate = attivo
        avanzamento.visibility = if (attivo) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun applicaModo() {
        bottoneModo.text = etichettaModo()
        vista.radice.visibility = if (modoRicerca) android.view.View.VISIBLE else android.view.View.GONE
        web.visibility = if (modoRicerca) android.view.View.GONE else android.view.View.VISIBLE
        if (modoRicerca) avanzamento.visibility = android.view.View.GONE   // v0.4.4
        // v0.4.1: la home si carica solo quando si entra davvero nella navigazione web
        if (!modoRicerca && web.url.isNullOrBlank()) web.loadUrl(HOME[fonte])
    }

    /** Apre la scheda dell'annuncio nel sito della sua fonte, dove tutto funziona. */
    private fun apriAnnuncio(a: Annuncio) {
        fonte = if (a.fonte == "subito") 0 else 1
        bottoneFonte.text = etichettaFonte()
        modoRicerca = false
        applicaModo()
        web.stopLoading()          // v0.4.1: niente navigazioni in coda che rubino il posto
        azzeraCronologia = true    // v0.4.1: "indietro" dalla scheda torna ai risultati
        web.loadUrl(a.url)
    }

    /** v0.4.1 — vero finche' la prossima pagina caricata non ha ripulito la cronologia. */
    private var azzeraCronologia = false

    private fun etichettaSonda() = if (modoSonda) "Sonda ON" else "Sonda OFF"

    private fun cambiaSonda() {
        modoSonda = !modoSonda
        prefs.edit().putBoolean("modoSonda", modoSonda).apply()
        bottoneSonda.text = etichettaSonda()
        toast(if (modoSonda) "Sonda accesa: lasciala accesa solo il tempo di raccogliere" else "Sonda spenta")
        registraCosmetici(); web.reload()
    }

    private fun etichettaVista() = if (vistaCompatta) "Vista compatta" else "Vista normale"

    private fun cambiaVista() {
        vistaCompatta = !vistaCompatta
        prefs.edit().putBoolean("vistaCompatta", vistaCompatta).apply()
        bottoneVista.text = etichettaVista()
        // Il layout viene applicato con stili in linea: il modo pulito di tornare
        // indietro e' ricaricare la pagina con lo script rigenerato.
        registraCosmetici(); web.reload()
    }

    private fun mostraNascosti() {
        val voci = Nascosti.elenco()
        if (voci.isEmpty()) { toast("Nessun annuncio nascosto"); return }
        val etichette = voci.map { (id, _, titolo) ->
            if (titolo.isBlank()) "annuncio $id" else titolo
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Nascosti (${voci.size}) — tocca per ripristinare")
            .setItems(etichette) { _, i ->
                Nascosti.rimuovi(this, voci[i].first)
                bottoneNascosti.text = etichettaNascosti()
                web.reload()
            }
            .setNeutralButton("Ripristina tutti") { _, _ ->
                Nascosti.svuota(this)
                bottoneNascosti.text = etichettaNascosti()
                web.reload()
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun analizzaPagina() =
        web.evaluateJavascript(DomProbe.script(Regole.cssNascondi, nomePonte), null)

    private fun cambiaUa() {
        modoUa = if (modoUa == 0) 1 else 0
        web.settings.userAgentString = if (modoUa == 1)
            WebSettings.getDefaultUserAgent(this).replace("; wv", "")
        else WebSettings.getDefaultUserAgent(this)
        // Nota v0.3.2: mascherare l'UA peggiora le cose. Se l'UA dice Chrome ma l'ambiente
        // JavaScript dice WebView, l'incoerenza e' piu' vistosa del marcatore originale.
        toast(if (modoUa == 1) "UA mascherata: sconsigliata, incoerente con l'ambiente" else "UA di sistema")
        web.reload()
    }

    private fun aggiornaStato() {
        val j = try { org.json.JSONObject(ultimoReportDom) } catch (t: Throwable) { org.json.JSONObject() }
        val card = j.optInt("cardCandidate", -1)
        val residui = j.optJSONArray("slotAdvAncoraVisibili")?.length() ?: -1
        stato.text = "richieste ${RequestLog.totalRequests()} · bloccate ${Regole.bloccate} · " +
                "card ${if (card < 0) "-" else card} · slot adv visibili ${if (residui < 0) "-" else residui} · " +
                "nascosti ${Nascosti.quanti()} · api ${ApiLog.quanti()} · regole ${Regole.versioneRegole}"
    }

    // ------------------------------------------------------------------
    // Import regole e export diagnostica
    // ------------------------------------------------------------------
    private fun scegliRegole() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        try { startActivityForResult(i, RC_REGOLE) } catch (t: Throwable) { toast("Nessun selettore file") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            RC_FILE -> {
                val res = if (resultCode == Activity.RESULT_OK)
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
                fileCallback?.onReceiveValue(res); fileCallback = null
            }
            RC_REGOLE -> {
                if (resultCode == Activity.RESULT_OK) {
                    val uri = data?.data
                    val testo = try {
                        uri?.let { contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() } }
                    } catch (t: Throwable) { null }
                    /*
                     * v0.3.0 — lo stesso pulsante accetta due tipi di file:
                     * un file regole oppure un archivio di annunci nascosti.
                     * Si distinguono dalla chiave "annunci".
                     *
                     * --- versione precedente (v0.2.0, 2026-08-30) ---
                     * if (testo != null && Regole.importa(this, testo)) { ... } else toast(...)
                     * --- fine versione precedente ---
                     */
                    when {
                        testo == null -> toast("File illeggibile")
                        testo.contains("\"annunci\"") -> {
                            val n = Nascosti.importa(this, testo)
                            bottoneNascosti.text = etichettaNascosti()
                            toast(if (n >= 0) "Importati $n annunci nascosti" else "Archivio non valido")
                            web.reload()
                        }
                        Regole.importa(this, testo) -> {
                            registraCosmetici(); web.reload()
                            toast("Regole ${Regole.versioneRegole} attive")
                        }
                        else -> toast("File non riconosciuto")
                    }
                }
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun esporta() {
        val ok = listOf(
            scriviInDownload("requests.json", RequestLog.requestsJson()),
            scriviInDownload("blocklist.json", RequestLog.blocklistJson()),
            scriviInDownload("selectors.json", ultimoReportDom),
            scriviInDownload("nascosti.json", Nascosti.esportaJson()),   // v0.3.0
            scriviInDownload("api.json", ApiLog.json()),                  // v0.3.1
            scriviInDownload("ricerca-diagnostica.txt", motore.diagnostica.toString())  // v0.4.0
        ).all { it }
        toast(if (ok) "Esportati in Download/SubitoPlus" else "Esportazione non riuscita")
    }

    private fun scriviInDownload(nome: String, contenuto: String): Boolean = try {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nome)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/SubitoPlus")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
        uri?.let {
            contentResolver.openOutputStream(it, "wt")?.use { os -> os.write(contenuto.toByteArray(Charsets.UTF_8)) }
            true
        } ?: false
    } catch (t: Throwable) { false }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            !modoRicerca && web.canGoBack() -> web.goBack()
            !modoRicerca -> { modoRicerca = true; applicaModo() }   // v0.4.0: si rientra nella ricerca
            else -> super.onBackPressed()
        }
    }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
