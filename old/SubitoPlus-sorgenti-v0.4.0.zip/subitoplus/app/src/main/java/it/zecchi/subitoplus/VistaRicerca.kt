package it.zecchi.subitoplus

/*
 * Subito+ — schermata della ricerca unificata
 * v0.4.0 (2026-08-30) — nuovo, Fase 3
 *
 * Interfaccia costruita a mano, senza layout XML e senza librerie:
 * campo di ricerca, scelta delle fonti, ordinamento, lista unica.
 * Ogni riga porta l'etichetta della provenienza e il pulsante di scarto,
 * che usa lo stesso archivio della navigazione web.
 */

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class VistaRicerca(
    private val act: Activity,
    private val motore: MotoreRicerca,
    private val apri: (Annuncio) -> Unit,
    private val nascondi: (Annuncio) -> Unit
) {
    val radice: LinearLayout
    private val campo: EditText
    private val stato: TextView
    private val lista: ListView
    private val altri: Button
    private val cbSubito: CheckBox
    private val cbVinted: CheckBox
    private val ordine: Spinner

    private val risultati = ArrayList<Annuncio>()
    private val adattatore = Adattatore()
    private var ultimaQuery = ""
    private var pagina = 1
    private val conteggi = HashMap<String, Int>()

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    init {
        radice = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), 0)
        }

        val riga1 = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        campo = EditText(act).apply {
            hint = "Cosa cerchi su Subito e Vinted?"
            setSingleLine(true)
            textSize = 16f
        }
        riga1.addView(campo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        riga1.addView(Button(act).apply {
            text = "Cerca"
            setOnClickListener { nuovaRicerca() }
        })
        radice.addView(riga1)

        val riga2 = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        cbSubito = CheckBox(act).apply { text = "Subito"; isChecked = true }
        cbVinted = CheckBox(act).apply { text = "Vinted"; isChecked = true }
        ordine = Spinner(act).apply {
            adapter = ArrayAdapter(
                act, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Più recenti", "Prezzo crescente", "Prezzo decrescente")
            )
        }
        riga2.addView(cbSubito); riga2.addView(cbVinted)
        riga2.addView(ordine, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        radice.addView(riga2)

        stato = TextView(act).apply { textSize = 12f; setPadding(0, 0, 0, dp(4)) }
        radice.addView(stato)

        lista = ListView(act).apply {
            adapter = adattatore
            divider = null
            dividerHeight = dp(8)
        }
        radice.addView(lista, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        altri = Button(act).apply {
            text = "Carica altri"
            visibility = View.GONE
            setOnClickListener { paginaSuccessiva() }
        }
        radice.addView(altri)

        motore.ascoltatore = object : MotoreRicerca.Ascoltatore {
            override fun risultati(fonte: String, annunci: List<Annuncio>, diagnostica: String) {
                conteggi[fonte] = (conteggi[fonte] ?: 0) + annunci.size
                aggiungi(annunci)
            }
            override fun errore(fonte: String, messaggio: String) {
                conteggi[fonte] = conteggi[fonte] ?: 0
                stato.text = descrizione() + " · $fonte: $messaggio"
            }
        }
    }

    private fun fontiScelte(): List<Fonte> {
        val f = ArrayList<Fonte>()
        if (cbSubito.isChecked) f.add(FonteSubito)
        if (cbVinted.isChecked) f.add(FonteVinted)
        return f
    }

    private fun chiaveOrdine() = when (ordine.selectedItemPosition) {
        1 -> "prezzo_cresc"; 2 -> "prezzo_decr"; else -> "recenti"
    }

    private fun nuovaRicerca() {
        val q = campo.text.toString().trim()
        if (q.isEmpty()) return
        val fonti = fontiScelte()
        if (fonti.isEmpty()) { stato.text = "Scegli almeno una fonte"; return }
        ultimaQuery = q; pagina = 1
        risultati.clear(); conteggi.clear(); adattatore.notifyDataSetChanged()
        stato.text = "Cerco…"
        altri.visibility = View.GONE
        motore.cerca(q, 1, chiaveOrdine(), fonti)
    }

    private fun paginaSuccessiva() {
        if (ultimaQuery.isEmpty()) return
        pagina++
        stato.text = descrizione() + " · carico pagina $pagina…"
        motore.cerca(ultimaQuery, pagina, chiaveOrdine(), fontiScelte())
    }

    private fun aggiungi(nuovi: List<Annuncio>) {
        val gia = risultati.map { it.fonte + it.id }.toHashSet()
        nuovi.forEach {
            if (!gia.contains(it.fonte + it.id) && !Nascosti.contiene(it.chiave)) risultati.add(it)
        }
        ordina()
        adattatore.notifyDataSetChanged()
        stato.text = descrizione()
        altri.visibility = if (risultati.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun ordina() {
        when (chiaveOrdine()) {
            "prezzo_cresc" -> risultati.sortBy { it.prezzo ?: Double.MAX_VALUE }
            "prezzo_decr" -> risultati.sortByDescending { it.prezzo ?: -1.0 }
            else -> risultati.sortByDescending { it.dataMillis }
        }
    }

    private fun descrizione(): String {
        val parti = conteggi.entries.sortedBy { it.key }.joinToString(" · ") { "${it.key} ${it.value}" }
        return "${risultati.size} in lista" + if (parti.isBlank()) "" else " ($parti)"
    }

    /** Richiamata quando un annuncio viene nascosto dalla lista. */
    fun rimuovi(a: Annuncio) {
        risultati.removeAll { it.fonte == a.fonte && it.id == a.id }
        adattatore.notifyDataSetChanged()
        stato.text = descrizione()
    }

    private inner class Adattatore : BaseAdapter() {
        override fun getCount() = risultati.size
        override fun getItem(i: Int) = risultati[i]
        override fun getItemId(i: Int) = i.toLong()

        override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
            val a = risultati[i]
            val riga = (convert as? LinearLayout) ?: creaRiga()
            val foto = riga.getChildAt(0) as ImageView
            val testi = riga.getChildAt(1) as LinearLayout
            val x = riga.getChildAt(2) as Button

            Immagini.carica(a.immagine, foto)
            (testi.getChildAt(0) as TextView).text = a.titolo
            (testi.getChildAt(1) as TextView).text = a.prezzoTesto
            (testi.getChildAt(2) as TextView).text =
                listOf(etichetta(a.fonte), a.luogo).filter { it.isNotBlank() }.joinToString(" · ")

            riga.setOnClickListener { apri(a) }
            x.setOnClickListener { nascondi(a) }
            return riga
        }

        private fun etichetta(f: String) = if (f == "subito") "SUBITO" else "VINTED"

        private fun creaRiga(): LinearLayout {
            val riga = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(4), 0, dp(4))
                gravity = Gravity.CENTER_VERTICAL
            }
            riga.addView(ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#E7ECEA"))
            }, LinearLayout.LayoutParams(dp(96), dp(96)))

            val testi = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, dp(6), 0)
            }
            testi.addView(TextView(act).apply {
                textSize = 15f; setTypeface(null, Typeface.BOLD)
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            })
            testi.addView(TextView(act).apply { textSize = 15f })
            testi.addView(TextView(act).apply {
                textSize = 12f; setTextColor(Color.parseColor("#596A66"))
            })
            riga.addView(testi, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            riga.addView(Button(act).apply { text = "✕"; textSize = 13f },
                LinearLayout.LayoutParams(dp(48), dp(48)))
            return riga
        }
    }
}
