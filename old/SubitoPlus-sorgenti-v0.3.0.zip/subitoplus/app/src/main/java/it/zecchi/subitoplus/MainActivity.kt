package it.zecchi.subitoplus

/*
 * Subito+ — Fase 2 "Nascondi annuncio"
 * v0.3.0 (2026-08-30)
 *
 * Novita' rispetto alla v0.2.0:
 *  - ogni card annuncio riceve un pulsante di scarto; l'ID finisce in un archivio locale
 *    e la card non viene piu' disegnata, in questa e in tutte le ricerche successive
 *  - schermata "Nascosti" con ripristino singolo o totale, esportabile e importabile
 *  - la home si apre sulla sezione scelta nelle regole (Market) invece che su Motori
 *  - il pulsante "Cerca" della barra in basso riporta al modulo di ricerca
 *
 * Cosa NON fa ancora: ricerche salvate e notifiche (Fase 3).
 */

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var stato: TextView
    private lateinit var prefs: SharedPreferences
    private lateinit var bottoneBlocco: Button
    private lateinit var bottoneNascosti: Button
    private lateinit var bottoneVista: Button

    @Volatile private var ultimoReportDom: String = "{}"

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val RC_FILE = 1001
    private val RC_REGOLE = 1002

    /** Interruttore generale del blocco: utile per confrontare prima/dopo e per sbloccarsi se qualcosa si rompe. */
    private var bloccoAttivo = true

    private var modoUa = 0

    /** v0.3.0 — vista compatta: foto piccola a sinistra, testo a destra. Scelta ricordata. */
    private var vistaCompatta = false

    /** Riferimento allo script iniettato a document-start, da rimuovere quando cambiano le regole. */
    private var scriptCosmetico: androidx.webkit.ScriptHandler? = null
    private var scriptAnnunci: androidx.webkit.ScriptHandler? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("subitoplus", MODE_PRIVATE)
        bloccoAttivo = prefs.getBoolean("bloccoAttivo", true)
        vistaCompatta = prefs.getBoolean("vistaCompatta", false)

        Regole.carica(this)
        Nascosti.carica(this)   // v0.3.0

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val barra = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
        }
        bottoneBlocco = bottone(etichettaBlocco()) { cambiaBlocco() }
        barra.addView(bottoneBlocco)
        bottoneNascosti = bottone(etichettaNascosti()) { mostraNascosti() }   // v0.3.0
        barra.addView(bottoneNascosti)
        bottoneVista = bottone(etichettaVista()) { cambiaVista() }            // v0.3.0
        barra.addView(bottoneVista)
        barra.addView(bottone("Analizza") { analizzaPagina() })
        barra.addView(bottone("Esporta") { esporta() })
        barra.addView(bottone("Regole") { scegliRegole() })
        barra.addView(bottone("UA") { cambiaUa() })
        barra.addView(bottone("Azzera") {
            RequestLog.reset(); Regole.bloccate = 0; ultimoReportDom = "{}"; aggiornaStato()
        })
        root.addView(HorizontalScrollView(this).apply { addView(barra) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        stato = TextView(this).apply { setPadding(16, 0, 16, 8); textSize = 12f }
        root.addView(stato)

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        configuraWebView()
        registraCosmetici()
        web.loadUrl("https://www.subito.it/")
        aggiornaStato()
    }

    private fun bottone(testo: String, azione: () -> Unit) = Button(this).apply {
        text = testo; textSize = 13f; setOnClickListener { azione() }
    }

    private fun etichettaBlocco() = if (bloccoAttivo) "Blocco ON" else "Blocco OFF"

    private fun cambiaBlocco() {
        bloccoAttivo = !bloccoAttivo
        prefs.edit().putBoolean("bloccoAttivo", bloccoAttivo).apply()
        bottoneBlocco.text = etichettaBlocco()
        registraCosmetici()
        web.reload()
    }

    // ------------------------------------------------------------------
    // Configurazione WebView
    // ------------------------------------------------------------------
    private fun configuraWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = true
        if (modoUa == 1) s.userAgentString = WebSettings.getDefaultUserAgent(this).replace("; wv", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        WebView.setWebContentsDebuggingEnabled(true)

        web.addJavascriptInterface(Bridge(), "SondaBridge")
        web.addJavascriptInterface(PonteAnnunci(), "SubitoPlus")   // v0.3.0

        web.webViewClient = object : WebViewClient() {

            /*
             * Il punto in cui si decide tutto.
             *
             * --- versione precedente (v0.1.0, 2026-08-30): sola osservazione ---
             * request?.url?.toString()?.let { RequestLog.record(it) }
             * return null
             * --- fine versione precedente ---
             */
            override fun shouldInterceptRequest(
                view: WebView?, request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                RequestLog.record(url)                       // il registro resta: serve a verificare
                if (!bloccoAttivo) return null
                if (!Regole.blocca(url)) return null
                Regole.bloccate++
                // Risposta vuota 200: piu' silenziosa di un errore, non fa ritentare gli script.
                return WebResourceResponse(
                    "text/plain", "utf-8",
                    ByteArrayInputStream(ByteArray(0))
                )
            }

            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                if (u.scheme != "http" && u.scheme != "https") {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, u)); true } catch (t: Throwable) { true }
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                // Rete di sicurezza: se il dispositivo non supporta l'iniezione a document-start,
                // il CSS entra comunque qui, con un possibile lampeggio.
                if (bloccoAttivo && !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))
                    view?.evaluateJavascript(Cosmetici.script(Regole.cssNascondi), null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                aggiornaStato()
                view?.postDelayed({ analizzaPagina() }, 1500)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try { startActivityForResult(params!!.createIntent(), RC_FILE); true }
                catch (t: Throwable) { fileCallback = null; false }
            }
            override fun onProgressChanged(view: WebView?, newProgress: Int) = aggiornaStato()
        }
    }

    /**
     * Iniezione dei filtri cosmetici prima di ogni script della pagina.
     * Va rifatta ogni volta che cambiano le regole o l'interruttore del blocco.
     */
    private fun registraCosmetici() {
        scriptCosmetico?.remove(); scriptCosmetico = null
        scriptAnnunci?.remove(); scriptAnnunci = null
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        val origini = setOf("https://*.subito.it", "https://subito.it")

        if (bloccoAttivo) scriptCosmetico = WebViewCompat.addDocumentStartJavaScript(
            web, Cosmetici.script(Regole.cssNascondi), origini
        )

        // v0.3.0 — lo script degli annunci e' indipendente dal blocco pubblicita':
        // lo scarto deve funzionare anche con "Blocco OFF".
        scriptAnnunci = WebViewCompat.addDocumentStartJavaScript(
            web, ScriptAnnunci.script(Regole.sezioneIniziale, Regole.cercaApreForm, vistaCompatta), origini
        )
    }

    // ------------------------------------------------------------------
    // Ponte JS -> Kotlin
    // ------------------------------------------------------------------
    inner class Bridge {
        @JavascriptInterface
        fun report(json: String) {
            ultimoReportDom = json
            runOnUiThread { aggiornaStato() }
        }
    }

    /**
     * Ponte usato dallo script della pagina. I metodi girano sul thread JS:
     * niente lavoro pesante e niente tocchi alla UI se non via runOnUiThread.
     */
    inner class PonteAnnunci {
        @JavascriptInterface
        fun nascondi(id: String, titolo: String) {
            Nascosti.aggiungi(this@MainActivity, id, titolo)
            runOnUiThread { bottoneNascosti.text = etichettaNascosti(); aggiornaStato() }
        }

        @JavascriptInterface
        fun nascostiJson(): String = Nascosti.idJson()
    }

    private fun etichettaNascosti() = "Nascosti ${Nascosti.quanti()}"

    private fun etichettaVista() = if (vistaCompatta) "Vista compatta" else "Vista normale"

    private fun cambiaVista() {
        vistaCompatta = !vistaCompatta
        prefs.edit().putBoolean("vistaCompatta", vistaCompatta).apply()
        bottoneVista.text = etichettaVista()
        // Il layout viene applicato con stili in linea: il modo pulito di tornare
        // indietro e' ricaricare la pagina con lo script rigenerato.
        registraCosmetici(); web.reload()
    }

    private fun mostraNascosti() {
        val voci = Nascosti.elenco()
        if (voci.isEmpty()) { toast("Nessun annuncio nascosto"); return }
        val etichette = voci.map { (id, _, titolo) ->
            if (titolo.isBlank()) "annuncio $id" else titolo
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Nascosti (${voci.size}) — tocca per ripristinare")
            .setItems(etichette) { _, i ->
                Nascosti.rimuovi(this, voci[i].first)
                bottoneNascosti.text = etichettaNascosti()
                web.reload()
            }
            .setNeutralButton("Ripristina tutti") { _, _ ->
                Nascosti.svuota(this)
                bottoneNascosti.text = etichettaNascosti()
                web.reload()
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun analizzaPagina() = web.evaluateJavascript(DomProbe.script(Regole.cssNascondi), null)

    private fun cambiaUa() {
        modoUa = if (modoUa == 0) 1 else 0
        web.settings.userAgentString = if (modoUa == 1)
            WebSettings.getDefaultUserAgent(this).replace("; wv", "")
        else WebSettings.getDefaultUserAgent(this)
        toast(if (modoUa == 1) "UA senza marcatore WebView" else "UA di sistema")
        web.reload()
    }

    private fun aggiornaStato() {
        val j = try { org.json.JSONObject(ultimoReportDom) } catch (t: Throwable) { org.json.JSONObject() }
        val card = j.optInt("cardCandidate", -1)
        val residui = j.optJSONArray("slotAdvAncoraVisibili")?.length() ?: -1
        stato.text = "richieste ${RequestLog.totalRequests()} · bloccate ${Regole.bloccate} · " +
                "card ${if (card < 0) "-" else card} · slot adv visibili ${if (residui < 0) "-" else residui} · " +
                "nascosti ${Nascosti.quanti()} · regole ${Regole.versioneRegole} (${Regole.origine})"
    }

    // ------------------------------------------------------------------
    // Import regole e export diagnostica
    // ------------------------------------------------------------------
    private fun scegliRegole() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        try { startActivityForResult(i, RC_REGOLE) } catch (t: Throwable) { toast("Nessun selettore file") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            RC_FILE -> {
                val res = if (resultCode == Activity.RESULT_OK)
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
                fileCallback?.onReceiveValue(res); fileCallback = null
            }
            RC_REGOLE -> {
                if (resultCode == Activity.RESULT_OK) {
                    val uri = data?.data
                    val testo = try {
                        uri?.let { contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() } }
                    } catch (t: Throwable) { null }
                    /*
                     * v0.3.0 — lo stesso pulsante accetta due tipi di file:
                     * un file regole oppure un archivio di annunci nascosti.
                     * Si distinguono dalla chiave "annunci".
                     *
                     * --- versione precedente (v0.2.0, 2026-08-30) ---
                     * if (testo != null && Regole.importa(this, testo)) { ... } else toast(...)
                     * --- fine versione precedente ---
                     */
                    when {
                        testo == null -> toast("File illeggibile")
                        testo.contains("\"annunci\"") -> {
                            val n = Nascosti.importa(this, testo)
                            bottoneNascosti.text = etichettaNascosti()
                            toast(if (n >= 0) "Importati $n annunci nascosti" else "Archivio non valido")
                            web.reload()
                        }
                        Regole.importa(this, testo) -> {
                            registraCosmetici(); web.reload()
                            toast("Regole ${Regole.versioneRegole} attive")
                        }
                        else -> toast("File non riconosciuto")
                    }
                }
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun esporta() {
        val ok = listOf(
            scriviInDownload("requests.json", RequestLog.requestsJson()),
            scriviInDownload("blocklist.json", RequestLog.blocklistJson()),
            scriviInDownload("selectors.json", ultimoReportDom),
            scriviInDownload("nascosti.json", Nascosti.esportaJson())   // v0.3.0
        ).all { it }
        toast(if (ok) "Esportati in Download/SubitoPlus" else "Esportazione non riuscita")
    }

    private fun scriviInDownload(nome: String, contenuto: String): Boolean = try {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nome)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/SubitoPlus")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
        uri?.let {
            contentResolver.openOutputStream(it, "wt")?.use { os -> os.write(contenuto.toByteArray(Charsets.UTF_8)) }
            true
        } ?: false
    } catch (t: Throwable) { false }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
