package it.monkey.app

/*
 * Monkey — changelog per versione
 * v1.36.0 (2026-09-04) — nuovo.
 *
 * Da qui in avanti ogni versione consegnata aggiunge una voce IN CIMA a
 * "VOCI" (la piu' recente e' quella che conta, vedi Changelog.ultima()): non
 * si tocca una voce gia' consegnata, si aggiunge solo. Le versioni precedenti
 * a questa (fino alla 1.35.0) non hanno una voce qui — il changelog nasce da
 * questa versione in avanti, non e' stato ricostruito a ritroso dalla
 * cronologia dei commenti di ogni file.
 *
 * A cosa serve: DialogoNovita.kt mostra la voce piu' recente in una finestra
 * flottante sopra la schermata di ricerca, una sola volta per versione.
 * MainActivity.onCreate confronta Changelog.ultima().versionCode con l'ultimo
 * gia' mostrato (salvato in prefs, chiave "changelogVisto") e apre il
 * dialogo se sono diversi — vale sia per un aggiornamento sia per
 * un'installazione nuova: in entrambi i casi e' vero che "e' la prima volta
 * che si apre QUESTA versione".
 */

/** Una voce del changelog: cosa e' cambiato in una versione, in breve. */
data class VoceChangelog(
    val versionCode: Int,
    val versionName: String,
    val novita: List<String>
)

object Changelog {

    val VOCI = listOf(
        VoceChangelog(
            versionCode = 60,
            versionName = "1.36.0",
            novita = listOf(
                "La lente nel campo di ricerca ora apre le ricerche salvate: prima non " +
                        "faceva nulla, era solo decorativa.",
                "Tolta la voce \"Ricerche salvate\" dal menu ⋮: era doppia, restano " +
                        "l'icona a campanella in barra e la lente nel campo di ricerca.",
                "Tolta \"Vista compatta\" dal menu ⋮: si cambia con la nuova icona sotto " +
                        "il campo di ricerca, sempre a portata di mano.",
                "Tenendo premuto su una ricerca recente, sotto il campo di ricerca, la " +
                        "si toglie dall'elenco.",
                "Questa finestra: da questa versione, le novità di ogni consegna " +
                        "compaiono una volta sola al primo avvio dopo l'installazione."
            )
        )
    )

    /** La voce piu' recente, quella che conta per il dialogo. Vuoto solo se VOCI lo e'. */
    fun ultima(): VoceChangelog? = VOCI.maxByOrNull { it.versionCode }
}
