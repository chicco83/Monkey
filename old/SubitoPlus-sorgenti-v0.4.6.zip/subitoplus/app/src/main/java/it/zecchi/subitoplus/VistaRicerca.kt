package it.zecchi.subitoplus

/*
 * Subito+ — schermata della ricerca unificata
 * v0.4.4 (2026-08-30)
 *
 * Interfaccia costruita a mano, senza layout XML e senza librerie:
 * campo di ricerca, scelta delle fonti, ordinamento, lista unica.
 * Ogni riga porta l'etichetta della provenienza e il pulsante di scarto,
 * che usa lo stesso archivio della navigazione web.
 *
 * v0.4.2: data di inserimento su ogni riga, filtro per eta' dell'annuncio,
 * e invio da tastiera che avvia la ricerca.
 * v0.4.3: filtro per prezzo minimo e massimo, e i filtri si possono chiudere
 * per lasciare tutto lo schermo ai risultati.
 *
 * NOTA sui filtri: agiscono su cio' che e' gia' stato scaricato, non sulla
 * richiesta alle fonti. Entrambe le piattaforme accettano parametri di prezzo,
 * ma i loro nomi non sono ancora stati osservati sul campo: finche' non lo
 * saranno, mandarli alla cieca rischierebbe di far tornare zero risultati.
 * Con "Carica altri" si allarga l'insieme su cui il filtro lavora.
 */

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.ViewGroup
import android.widget.*

class VistaRicerca(
    private val act: Activity,
    private val motore: MotoreRicerca,
    /** v0.4.4 — acceso finche' almeno una fonte deve ancora rispondere. */
    private val caricamento: (Boolean) -> Unit,
    private val apri: (Annuncio) -> Unit,
    private val nascondi: (Annuncio) -> Unit
) {
    val radice: LinearLayout
    private val campo: EditText
    private val stato: TextView
    private val lista: ListView
    private val altri: Button
    private val cbSubito: CheckBox
    private val cbVinted: CheckBox
    private val ordine: Spinner
    private val eta: Spinner
    private val giorni: EditText
    private val prezzoMin: EditText
    private val prezzoMax: EditText
    private val filtri: LinearLayout

    /*
     * v0.4.2 — due liste: "grezzi" e' tutto quello che le fonti hanno restituito,
     * "risultati" e' cio' che si vede dopo il filtro per eta'. Cosi' cambiare il
     * filtro non costringe a rifare la ricerca.
     */
    private val grezzi = ArrayList<Annuncio>()
    private val risultati = ArrayList<Annuncio>()
    private val adattatore = Adattatore()
    private var ultimaQuery = ""
    private var pagina = 1
    private val conteggi = HashMap<String, Int>()
    /** I listener degli spinner scattano durante la costruzione: prima di questo flag si ignorano. */
    private var pronto = false
    /** Quante fonti devono ancora rispondere alla richiesta in corso. */
    private var attesa = 0

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    private fun campoNumerico(suggerimento: String) = EditText(act).apply {
        hint = suggerimento
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        textSize = 15f
        imeOptions = EditorInfo.IME_ACTION_DONE
        setOnEditorActionListener { _, _, _ -> ricalcola(); true }
    }

    init {
        radice = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), 0)
        }

        val riga1 = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        campo = EditText(act).apply {
            hint = "Cosa cerchi su Subito e Vinted?"
            setSingleLine(true)
            textSize = 16f
            // v0.4.2: il tasto invio della tastiera avvia la ricerca.
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, actionId, ev ->
                val invio = actionId == EditorInfo.IME_ACTION_SEARCH ||
                        actionId == EditorInfo.IME_ACTION_DONE ||
                        actionId == EditorInfo.IME_ACTION_GO ||
                        (ev != null && ev.keyCode == android.view.KeyEvent.KEYCODE_ENTER &&
                                ev.action == android.view.KeyEvent.ACTION_DOWN)
                if (invio) { nuovaRicerca(); true } else false
            }
        }
        riga1.addView(campo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        riga1.addView(Button(act).apply {
            text = "Cerca"
            setOnClickListener { nuovaRicerca() }
        })
        riga1.addView(Button(act).apply {                    // v0.4.3
            text = "Filtri"; textSize = 12f
            setOnClickListener {
                filtri.visibility = if (filtri.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        })
        radice.addView(riga1)

        // Tutte le righe di filtro stanno in un contenitore richiudibile.
        filtri = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        radice.addView(filtri)

        val riga2 = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        cbSubito = CheckBox(act).apply { text = "Subito"; isChecked = true }
        cbVinted = CheckBox(act).apply { text = "Vinted"; isChecked = true }
        ordine = Spinner(act).apply {
            adapter = ArrayAdapter(
                act, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Più recenti", "Prezzo crescente", "Prezzo decrescente")
            )
            // v0.4.2: cambiare ordinamento riordina subito, senza rifare la ricerca
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = ricalcola()
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        riga2.addView(cbSubito); riga2.addView(cbVinted)
        riga2.addView(ordine, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        filtri.addView(riga2)

        // v0.4.2 — filtro per eta' dell'annuncio
        val riga3 = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        eta = Spinner(act).apply {
            adapter = ArrayAdapter(
                act, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Età: qualsiasi", "Più vecchi di", "Più recenti di")
            )
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = ricalcola()
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        giorni = EditText(act).apply {
            hint = "gg"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("30")
            textSize = 15f
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, _, _ -> ricalcola(); true }
        }
        riga3.addView(eta, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        riga3.addView(giorni, LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
        filtri.addView(riga3)

        // v0.4.3 — fascia di prezzo
        val riga4 = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        prezzoMin = campoNumerico("€ min")
        prezzoMax = campoNumerico("€ max")
        riga4.addView(TextView(act).apply { text = "Prezzo"; textSize = 13f })
        riga4.addView(prezzoMin, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        riga4.addView(prezzoMax, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        riga4.addView(Button(act).apply {
            text = "Applica"; textSize = 12f
            setOnClickListener { ricalcola() }
        })
        filtri.addView(riga4)

        stato = TextView(act).apply { textSize = 12f; setPadding(0, 0, 0, dp(4)) }
        radice.addView(stato)

        lista = ListView(act).apply {
            adapter = adattatore
            divider = null
            dividerHeight = dp(8)
        }
        radice.addView(lista, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        altri = Button(act).apply {
            text = "Carica altri"
            visibility = View.GONE
            setOnClickListener { paginaSuccessiva() }
        }
        radice.addView(altri)

        pronto = true

        motore.ascoltatore = object : MotoreRicerca.Ascoltatore {
            override fun risultati(fonte: String, annunci: List<Annuncio>, diagnostica: String) {
                conteggi[fonte] = (conteggi[fonte] ?: 0) + annunci.size
                aggiungi(annunci)
                finitaUna()
            }
            override fun errore(fonte: String, messaggio: String) {
                conteggi[fonte] = conteggi[fonte] ?: 0
                stato.text = descrizione() + " · $fonte: $messaggio"
                finitaUna()
            }
        }
    }

    private fun iniziaAttesa(quante: Int) {
        attesa = quante
        caricamento(attesa > 0)
    }

    private fun finitaUna() {
        if (attesa > 0) attesa--
        caricamento(attesa > 0)
    }

    private fun fontiScelte(): List<Fonte> {
        val f = ArrayList<Fonte>()
        if (cbSubito.isChecked) f.add(FonteSubito)
        if (cbVinted.isChecked) f.add(FonteVinted)
        return f
    }

    private fun chiaveOrdine() = when (ordine.selectedItemPosition) {
        1 -> "prezzo_cresc"; 2 -> "prezzo_decr"; else -> "recenti"
    }

    private fun nuovaRicerca() {
        val q = campo.text.toString().trim()
        if (q.isEmpty()) return
        val fonti = fontiScelte()
        if (fonti.isEmpty()) { stato.text = "Scegli almeno una fonte"; return }
        ultimaQuery = q; pagina = 1
        grezzi.clear(); risultati.clear(); conteggi.clear(); adattatore.notifyDataSetChanged()
        // v0.4.2: chiude la tastiera, altrimenti copre meta' dei risultati
        (act.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(campo.windowToken, 0)
        stato.text = "Cerco…"
        altri.visibility = View.GONE
        iniziaAttesa(fonti.size)
        motore.cerca(q, 1, chiaveOrdine(), fonti)
    }

    private fun paginaSuccessiva() {
        if (ultimaQuery.isEmpty()) return
        pagina++
        stato.text = descrizione() + " · carico pagina $pagina…"
        val fonti = fontiScelte()
        iniziaAttesa(fonti.size)
        motore.cerca(ultimaQuery, pagina, chiaveOrdine(), fonti)
    }

    private fun aggiungi(nuovi: List<Annuncio>) {
        val gia = grezzi.map { it.fonte + it.id }.toHashSet()
        nuovi.forEach {
            if (!gia.contains(it.fonte + it.id) && !Nascosti.contiene(it.chiave)) grezzi.add(it)
        }
        ricalcola()
        altri.visibility = if (grezzi.isEmpty()) View.GONE else View.VISIBLE
    }

    /** Applica filtro per eta' e ordinamento alla lista completa. */
    private fun ricalcola() {
        if (!pronto) return
        val n = giorni.text.toString().toLongOrNull() ?: 0L
        val soglia = System.currentTimeMillis() - n * 24L * 3600_000L
        val modo = eta.selectedItemPosition

        // v0.4.3 — fascia di prezzo; campo vuoto = estremo non impostato
        val pMin = prezzoMin.text.toString().replace(',', '.').toDoubleOrNull()
        val pMax = prezzoMax.text.toString().replace(',', '.').toDoubleOrNull()

        risultati.clear()
        grezzi.forEach { a ->
            val perEta = when {
                modo == 0 || n <= 0 -> true
                // Senza data non si puo' affermare che sia vecchio o recente: si esclude.
                a.dataMillis == 0L -> false
                modo == 1 -> a.dataMillis <= soglia    // piu' vecchi di n giorni
                else -> a.dataMillis >= soglia         // piu' recenti di n giorni
            }
            val perPrezzo = when {
                pMin == null && pMax == null -> true
                // Stesso principio: prezzo assente, non si puo' dire che rientri.
                a.prezzo == null -> false
                pMin != null && a.prezzo < pMin -> false
                pMax != null && a.prezzo > pMax -> false
                else -> true
            }
            if (perEta && perPrezzo) risultati.add(a)
        }
        when (chiaveOrdine()) {
            "prezzo_cresc" -> risultati.sortBy { it.prezzo ?: Double.MAX_VALUE }
            "prezzo_decr" -> risultati.sortByDescending { it.prezzo ?: -1.0 }
            else -> risultati.sortByDescending { it.dataMillis }
        }
        adattatore.notifyDataSetChanged()
        stato.text = descrizione()
    }

    private fun descrizione(): String {
        val parti = conteggi.entries.sortedBy { it.key }.joinToString(" · ") { "${it.key} ${it.value}" }
        val filtrati = grezzi.size - risultati.size
        return "${risultati.size} in lista" +
                (if (parti.isBlank()) "" else " ($parti)") +
                (if (filtrati > 0) " · $filtrati esclusi dal filtro" else "")
    }

    /** Richiamata quando un annuncio viene nascosto dalla lista. */
    fun rimuovi(a: Annuncio) {
        grezzi.removeAll { it.fonte == a.fonte && it.id == a.id }
        ricalcola()
    }

    private inner class Adattatore : BaseAdapter() {
        override fun getCount() = risultati.size
        override fun getItem(i: Int) = risultati[i]
        override fun getItemId(i: Int) = i.toLong()

        override fun getView(i: Int, convert: View?, parent: ViewGroup?): View {
            val a = risultati[i]
            val riga = (convert as? LinearLayout) ?: creaRiga()
            val foto = riga.getChildAt(0) as ImageView
            val testi = riga.getChildAt(1) as LinearLayout
            val x = riga.getChildAt(2) as Button

            Immagini.carica(a.immagine, foto)
            (testi.getChildAt(0) as TextView).text = a.titolo
            (testi.getChildAt(1) as TextView).text = a.prezzoTesto
            (testi.getChildAt(2) as TextView).text =
                listOf(etichetta(a.fonte), a.luogo).filter { it.isNotBlank() }.joinToString(" · ")
            (testi.getChildAt(3) as TextView).text = dataTesto(a.dataMillis)   // v0.4.2

            riga.setOnClickListener { apri(a) }
            x.setOnClickListener { nascondi(a) }
            return riga
        }

        private fun etichetta(f: String) = if (f == "subito") "SUBITO" else "VINTED"

        /** Data assoluta piu' eta' in giorni: la seconda e' quella che si legge davvero. */
        private fun dataTesto(t: Long): String {
            if (t <= 0L) return "data non disponibile"
            val g = ((System.currentTimeMillis() - t) / 86_400_000L).toInt()
            val d = java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.ITALY)
                .format(java.util.Date(t))
            val quando = when {
                g <= 0 -> "oggi"
                g == 1 -> "ieri"
                else -> "$g giorni fa"
            }
            return "$d · $quando"
        }

        private fun creaRiga(): LinearLayout {
            val riga = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(4), 0, dp(4))
                gravity = Gravity.CENTER_VERTICAL
            }
            riga.addView(ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#E7ECEA"))
            }, LinearLayout.LayoutParams(dp(104), dp(104)))

            val testi = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, dp(6), 0)
            }
            testi.addView(TextView(act).apply {
                textSize = 15f; setTypeface(null, Typeface.BOLD)
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            })
            testi.addView(TextView(act).apply { textSize = 15f })
            testi.addView(TextView(act).apply {
                textSize = 12f; setTextColor(Color.parseColor("#596A66"))
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            })
            // v0.4.2 — data di inserimento
            testi.addView(TextView(act).apply {
                textSize = 12f; setTextColor(Color.parseColor("#7C4D14"))
                maxLines = 1
            })
            riga.addView(testi, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            riga.addView(Button(act).apply { text = "✕"; textSize = 13f },
                LinearLayout.LayoutParams(dp(48), dp(48)))
            return riga
        }
    }
}
