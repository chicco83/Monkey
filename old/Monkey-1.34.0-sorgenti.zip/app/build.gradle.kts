// Subito+ — modulo app
// v0.1.0 (2026-08-30) — Fase 0 "Sonda": nessuna dipendenza esterna, solo framework Android.
//   Scelta voluta: la sonda deve compilare e installarsi ovunque, senza librerie che
//   possano introdurre variabili nel comportamento del WebView che stiamo misurando.
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

    /*
     * v1.14.0 (2026-08-31) — CORREZIONE: applicationId/namespace non devono
     * contenere alcun dato personale del proprietario. Quello di partenza
     * lo faceva fin dalla v0.1.0; ora e' "it.monkey.app", legato al nome
     * dell'app (Monkey) e non a chi l'ha commissionata.
     *
     * ATTENZIONE — applicationId diverso vuol dire APP DIVERSA per Android:
     * questa versione NON aggiorna quella gia' installata, si affianca come
     * seconda app. La vecchia resta installata con dentro login, preferiti
     * live e le sue impostazioni; nella nuova si rifa' il login su Subito e
     * Vinted (i cookie non si spostano fra due app diverse) e si puo'
     * recuperare annunci nascosti + ricerche salvate + regole con "Salva
     * backup" nella vecchia app e "Importa file..." in questa. Fatto quello,
     * la vecchia si puo' disinstallare.
     *
     * (la versione precedente di namespace/applicationId non e' riportata
     * qui per lo stesso motivo della correzione: conteneva un dato personale)
     */
android {
    namespace = "it.monkey.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "it.monkey.app"
        minSdk = 29            // Android 10: richiesto da MediaStore.Downloads usato per l'export
        targetSdk = 34         // dispositivo di riferimento: Android 13 (API 33)
        /*
         * v1.17.0 (2026-08-31) — due cose:
         *  1. le offerte fatte su Vinted ora si vedono anche in app (prima solo
         *     quelle Subito: vedi il commento in cima a Offerte.kt);
         *  2. se l'app riparte da zero (il sistema ha chiuso il processo in
         *     secondo piano, o l'hai chiusa tu) l'ultima ricerca si ripete da
         *     sola invece di lasciare la casella vuota (vedi il commento su
         *     StatoRicerca.ripristinaUltimaRicerca()).
         *
         * NOTA sul 403 dei preferiti Vinted: il ricaricamento della v1.16.0
         * (ancora attivo, sotto) NON ha risolto la rimozione — il messaggio
         * torna con "[ricaricato]" e lo stesso errore, quindi non era un
         * token invecchiato. Resta un problema aperto, non toccato in questa
         * versione: vedi la spiegazione data in chat, serve piu' tempo prima
         * di un altro tentativo alla cieca.
         *
         * --- versione precedente ---
         * versionCode = 40
         * versionName = "1.16.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.18.0 (2026-08-31) — "indietro" da una ricerca torna alla home
         * (le ultime proposte) invece di uscire dall'app — vedi il commento
         * sul gestore di "indietro" in MainActivity.kt. Aggiunta anche
         * un'icona "home" in barra per andarci con un tocco da qualunque
         * punto (utile soprattutto da dentro "Sito", dove "indietro" scorre
         * prima la cronologia della pagina).
         *
         * --- versione precedente ---
         * versionCode = 41
         * versionName = "1.17.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.19.0 (2026-08-31) — NON e' una correzione del 403 sui preferiti
         * Vinted: e' lo strumento per smettere di indovinare.
         *
         * La nuova sonda mandata in chat (api.json) ha mostrato che vinted.it
         * carica un secondo sistema anti-bot oltre a Datadome — chiamate
         * cifrate verso un percorso offuscato (".../j3r4zw/v1/consume", con
         * un bootstrap ".../j3r4zw/v1/config") — dello stesso tipo di SDK che
         * altri siti usano per punteggiare quanto "umano" sembra chi scrive.
         * Ma quella sonda ha guardato una scheda di browser normale, MAI la
         * sessione nascosta 1x1 dell'app che e' quella che davvero fallisce:
         * non e' una prova, e' un indizio.
         *
         * Questa versione aggiunge SOLO diagnostica, zero comportamento
         * nuovo: quando il preferito su Vinted torna 403, l'app ora registra
         * (nel log che la sonda gia' esporta) le intestazioni vere della
         * risposta e quante volte, nella sessione VERA che e' appena fallita,
         * sono partite chiamate verso quel percorso. Vedi i commenti in
         * Prologo.kt e MotoreRicerca.kt. Prossimo passo: riprovare a togliere
         * un preferito, mandare la nuova diagnostica, e SOLO allora decidere
         * se la pista anti-bot regge o va scartata.
         *
         * --- versione precedente ---
         * versionCode = 42
         * versionName = "1.18.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.20.0 (2026-08-31) — CORREZIONE: un'offerta appena fatta compariva
         * in lista solo chiudendo l'app dal task manager e riaprendola.
         *
         * Causa trovata (non un'ipotesi): Offerte.aggiorna() non rilegge piu'
         * di una volta ogni cinque minuti, e quel limite vive per tutta la
         * vita del PROCESSO (Offerte e' un "object" Kotlin, un solo esemplare
         * finche' il processo resta vivo). Tornare nell'app con "indietro" o
         * col tasto home non uccide il processo, quindi il limite non si
         * azzera mai da solo: solo la chiusura forzata lo fa. Rimedio: a ogni
         * vero ritorno in foreground (onResume) si rilegge subito, ignorando
         * il limite — vedi StatoRicerca.aggiornaOfferteAlRitorno() e
         * MainActivity.onResume().
         *
         * Le offerte Vinted restano un problema aperto e diverso: non
         * comparivano nemmeno con l'app riavviata da zero. aggiornaVinted()
         * non scriveva mai nel log in caso di problema — ora sì (vedi
         * Offerte.kt): la prossima sonda dira' dove si ferma davvero, invece
         * di lasciarlo indovinare.
         *
         * --- versione precedente ---
         * versionCode = 43
         * versionName = "1.19.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.21.0 (2026-08-31) — CORREZIONE: le offerte Vinted non sono mai
         * comparse. Causa trovata con la sonda mandata in chat (una vera
         * offerta fatta dal sito vero, catturata per intero): Offerte.kt
         * chiamava "/inbox" e "/conversations/<id>" SENZA il prefisso
         * "/api/v2/" che porta ogni altra chiamata Vinted di questo progetto
         * — Vinted rispondeva con la pagina "non esiste" (404), scartata in
         * silenzio a ogni giro. Corretto. La stessa sonda ha anche mostrato
         * che "transaction.offer_price" e' il prezzo di LISTINO, non
         * l'offerta: l'importo vero sta nel messaggio piu' recente della
         * conversazione (vedi leggiConversazioneVinted in Offerte.kt).
         *
         * Aggiunta anche diagnostica (nessun cambiamento nel risultato) per
         * il sospetto separato "su Vinted vedo solo gli annunci di oggi":
         * vedi il commento su FonteVinted.chiavi() in Fonti.kt.
         *
         * --- versione precedente ---
         * versionCode = 44
         * versionName = "1.20.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.22.0 (2026-08-31) — due correzioni segnalate appena le offerte
         * Vinted hanno iniziato a comparire (v1.21.0):
         *
         * 1. L'etichetta della fonte, nella riga di ogni offerta, diceva
         *    sempre "SUBITO" — scritta fissa da quando le offerte erano solo
         *    di Subito (v1.4.0), mai resa dinamica quando la v1.10.0 ha
         *    aggiunto Vinted. Ora usa o.fonte (vedi SchermataRicerca.kt).
         *
         * 2. Le offerte VERE di Subito sparivano proprio mentre comparivano
         *    quelle Vinted: la rilettura forzata a ogni ritorno in app
         *    (v1.21.0) puo' far partire due "aggiorna()" quasi insieme, e una
         *    guardia di rientro rotta (segnava "finito" subito dopo aver
         *    AVVIATO le chiamate, non dopo la risposta) lasciava che una
         *    risposta arrivata per seconda scrivesse sopra la prima, buona,
         *    con l'accoglienza dell'esito incompleto. Vedi il commento su
         *    Offerte.aggiorna().
         *
         * --- versione precedente ---
         * versionCode = 45
         * versionName = "1.21.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.23.0 (2026-08-31) — CORREZIONE: il chip "Senza Subito" (o "Senza
         * Vinted") si mostrava attivo ma in mezzo agli annunci restavano
         * comunque annunci dell'altra fonte, anche scorrendo in basso.
         *
         * Causa trovata (non un'ipotesi, letta nel codice): usaSubito/
         * usaVinted venivano guardati SOLO da fonti() — quali fonti
         * interrogare per le pagine ancora da caricare. La lista mostrata
         * a schermo ("risultati", in StatoRicerca.kt) filtrava per eta',
         * prezzo, novita' e venduto, ma MAI per fonte: gli annunci gia'
         * scaricati prima di spuntare il filtro restavano visibili per
         * sempre. Non era quindi un problema di attesa/caricamento a 30
         * alla volta come ipotizzato in chat — nessuna icona di
         * caricamento avrebbe risolto nulla. Vedi il commento su
         * StatoRicerca.risultati.
         *
         * --- versione precedente ---
         * versionCode = 46
         * versionName = "1.22.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.24.0 (2026-08-31) — tre cose dallo stesso messaggio:
         *
         * 1. NUOVO: pannello "Opzioni" (⋮ -> Opzioni…), pensato per crescere.
         *    Prima voce: cosa fare all'avvio, riprendere l'ultima ricerca
         *    (comportamento di sempre, v1.17.0) o andare alla home. Vedi
         *    DialogoOpzioni.kt e il commento su MainActivity.onCreate().
         *
         * 2. DIAGNOSTICA (non una correzione): le offerte Subito vere
         *    restano assenti dalla lista anche con la v1.22.0 installata.
         *    La chiamata che le legge non lasciava MAI una riga di log in
         *    caso di problema, a differenza di quella Vinted (che da tempo
         *    lo fa) — ora si', cosi' la prossima diagnostica esportata dira'
         *    dove si ferma davvero. Vedi il commento su Offerte.aggiorna().
         *
         * 3. CORREZIONE (indiziaria, non ancora confermata da una sonda su
         *    un caso vero): un acquisto Vinted gia' concluso restava fra le
         *    offerte attive. Aggiunta la parola "venduto" fra quelle che
         *    Offerte.terminata() riconosce come stato chiuso — vista scritta
         *    da Vinted su una scheda articolo gia' comprato, in una delle
         *    immagini mandate in chat. Vedi il commento su terminata().
         *
         * --- versione precedente ---
         * versionCode = 47
         * versionName = "1.23.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.25.0 (2026-08-31) — CORREZIONE, con la prova in mano stavolta
         * (la sonda di un'offerta vera, 3bd66d96-api.json, la stessa del
         * contratto v1.21.0): trovata la causa reale per cui "le offerte
         * Subito si vedevano fino alla 1.20" — non e' mai stata una lettura
         * che fallisce, e' un ordinamento sbagliato. Ogni offerta Vinted
         * veniva datata "adesso" a OGNI rilettura (mai con la sua vera data),
         * quindi vinceva sempre il confronto con le date vere di Subito nella
         * top-6 della home: prima della v1.21.0 non si vedeva perche' Vinted
         * non arrivava affatto (endpoint rotto), da quando arriva ha
         * affollato tutte le posizioni. Ora si usa la vera data del
         * messaggio (created_at_ts, trovato nella sonda). Vedi il commento
         * su Offerte.leggiConversazioneVinted().
         *
         * Corretto anche l'annuncio "fantasma" (un'offerta Vinted "Accettata"
         * rimasta in lista con l'annuncio ormai introvabile sul sito): la
         * stessa transazione porta due booleani veri, is_completed e
         * item_is_closed, che ora contano quanto il testo dello stato. E il
         * giudice di "e' conclusa?" e' diventato uno solo — "attiva" — invece
         * di due che potevano disallinearsi (vedi Offerte.conclusa()).
         *
         * --- versione precedente ---
         * versionCode = 48
         * versionName = "1.24.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.26.0 (2026-09-01) — tre cose dallo stesso messaggio:
         *
         * 1. TENTATIVO NUOVO per il 403 dei preferiti Vinted (mai risolto
         *    da v1.6.0 a v1.19.0): l'utente ha catturato con la sonda un
         *    preferito aggiunto E tolto con successo dentro una vera pagina
         *    di un articolo Vinted. Indirizzo, corpo e intestazioni erano
         *    gia' identici a quelli che l'app manda — quello che mancava era
         *    la pagina: la sessione nascosta restava sulla home caricata una
         *    volta all'avvio, mai su una pagina vera di articolo. Ora la
         *    sessione ci naviga davvero, appena prima del preferito. Vedi
         *    Fonti.kt (toggle) e MotoreRicerca.kt (azione, paginaPrima).
         *
         * 2. Il menu dai tre pallini aveva quattordici voci: le sette di uso
         *    raro (backup, import, sonda, diagnostica) si spostano nel
         *    pannello Opzioni, restano solo le prime sei. Vedi
         *    BarraSuperiore.kt e DialogoOpzioni.kt.
         *
         * 3. La home mostrava solo le ultime 6 offerte, un tetto rimasto da
         *    prima che la lista scorresse da sola (v1.9.0): ora le mostra
         *    tutte. Vedi Offerte.recenti() e StatoRicerca.offerteRecenti().
         *
         * --- versione precedente ---
         * versionCode = 49
         * versionName = "1.25.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.27.0 (2026-09-01) — CORREZIONE: "ho attivato le notifiche per
         * le ricerche programmate ma non e' arrivata nessuna notifica".
         *
         * Bug vero, trovato leggendo Controllore.doWork(): le notifiche di
         * TUTTE le ricerche salvate partivano solo alla fine, dopo aver
         * controllato TUTTE quante. Un lavoro periodico ha un tempo massimo
         * di esecuzione, e con piu' ricerche, piu' fonti, e le pause volute
         * apposta per non sembrare un programma, un giro completo puo'
         * avvicinarsi o superarlo — se il sistema lo interrompe a meta', le
         * notifiche gia' pronte sparivano insieme al resto, e gli annunci
         * trovati restavano comunque segnati come "gia' visti" (non
         * sarebbero MAI piu' stati notificati). Ora ogni ricerca notifica
         * appena finite le sue fonti, non aspetta piu' le altre.
         *
         * Aggiunto anche un log che resta (controllo-log.txt, in "Esporta
         * diagnostica"): finora un giro in background non lasciava traccia
         * da nessuna parte leggibile. Se le notifiche continuano a non
         * arrivare, quel file dira' perche' invece di doverlo indovinare.
         *
         * --- versione precedente ---
         * versionCode = 50
         * versionName = "1.26.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.28.0 (2026-09-01) — NUOVO: "e' possibile visualizzare
         * nell'elenco annunci una icona se ho mandato un messaggio al
         * venditore?".
         *
         * La risposta era gia' quasi tutta nei dati che l'app tiene: ogni
         * proposta inviata (Subito: transazione P2P; Vinted: conversazione
         * con un offer_request_message) diventa un Offerte.Offerta, tenuto
         * per chiave annuncio (Offerte.perAnnuncio). L'elenco di ricerca
         * gia' legge questa mappa per mostrare "offerti xxx €" accanto al
         * prezzo — ma SOLO quando la proposta e' ancora attiva (vedi
         * StatoRicerca.offerta(), che ritorna null se o.attiva e' falso).
         * Un annuncio con proposta conclusa (accettata, rifiutata, venduto)
         * spariva quindi da qualunque segno visibile in elenco, anche se un
         * messaggio al venditore c'e' stato davvero.
         *
         * Aggiunta una seconda funzione, StatoRicerca.contattato(), che non
         * guarda "attiva": basta che esista una Offerta per quell'annuncio,
         * conclusa o no. Ogni riga dell'elenco annunci (RigaAnnuncio, sia
         * vista compatta che estesa — condividono Descrizione()) mostra ora
         * un'iconcina "inviato" (Icons.Filled.Send) accanto al nome della
         * fonte quando questo e' vero, indipendente dal testo rosso del
         * prezzo che resta legato alla sola proposta ancora aperta.
         *
         * --- versione precedente ---
         * versionCode = 51
         * versionName = "1.27.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.29.0 (2026-09-01) — NUOVO: "mi serve aggiungere ai filtri un
         * toggle per scartare gli annunci il cui venditore ha 0 recensioni".
         *
         * Il numero di recensioni Vinted arriva dalla STESSA chiamata che
         * LuoghiVinted gia' faceva per il luogo (GET /api/v2/users/<id>):
         * il campo "feedback_count" c'era gia' nella risposta, verificato su
         * tre punti diversi di una sessione reale (users/current,
         * promoted_closets, conversations — quest'ultimo lo chiama
         * "review_count" invece, ma e' lo stesso concetto). Nessuna chiamata
         * in piu', solo un campo in piu' letto da quella che gia' c'era.
         * Vedi LuoghiVinted.kt per i dettagli e per la correzione necessaria
         * alla coda (un venditore con solo il luogo in cache non doveva
         * restare per sempre senza recensioni).
         *
         * Su Subito il dato non c'e' ancora: esiste un sistema di recensioni
         * (hades.subito.it/v1/trust/feedback-api/…) ma finora una sonda ha
         * catturato solo l'endpoint che da' un token, non quello con il
         * numero vero. Il filtro (StatoRicerca.scartaSenzaRecensioni) tratta
         * quindi "non lo sappiamo" come "non scartare" — vale per gli
         * annunci Subito e per i Vinted la cui risposta non e' ancora
         * arrivata, non solo per uno zero vero.
         *
         * Nuovo interruttore in Filtri ("Nascondi venditori senza
         * recensioni"), con l'avviso che per ora vale solo su Vinted.
         *
         * --- versione precedente ---
         * versionCode = 52
         * versionName = "1.28.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.30.0 (2026-09-01) — COMPLETA la v1.29.0: recensioni anche su
         * Subito. La sonda chiesta ("una presa dal profilo di un venditore
         * Subito") ha dato l'endpoint mancante:
         *
         *   GET hades.subito.it/v1/trust/feedback/public/users/
         *       sdrn:subito:user:<id>/feedback?limit=1&page=0&sources=MEMBER
         *   -> pagination.totalCount = numero di recensioni
         *
         * "public" nel percorso, nessun token richiesto per leggerlo (la
         * sonda l'ha preso guardando il profilo di un ALTRO venditore, non
         * il proprio). Nuovo file RecensioniSubito.kt, stessa architettura
         * di LuoghiVinted.kt (coda, due alla volta, cache su file).
         *
         * Serviva anche l'id del venditore per ogni annuncio Subito, che
         * finora non veniva letto (Annuncio.venditore restava vuoto: solo
         * Vinted lo riempiva). E' "advertiser.user_id", gia' presente in
         * ogni risultato di ricerca — vedi Fonti.kt, FonteSubito.leggi().
         *
         * Il filtro "Nascondi venditori senza recensioni" (v1.29.0) ora
         * copre entrambe le fonti: tolto l'avviso "solo su Vinted" dal
         * pannello Filtri.
         *
         * --- versione precedente ---
         * versionCode = 53
         * versionName = "1.29.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.31.0 (2026-09-01) — due correzioni, non collegate fra loro.
         *
         * 1. "il doppio avvio nel log": controllo-log.txt mostrava coppie
         *    di "avvio" a pochi secondi/minuti l'una dall'altra con un solo
         *    "fine giro". Trovato un varco vero nel codice: "Controlla ora"
         *    (MainActivity.controllaOra) mette in coda il lavoro con
         *    WorkManager.enqueue() semplice, non enqueueUniqueWork, quindi
         *    nulla impedisce che parta insieme al giro periodico (quello si'
         *    "unique"). Corretto con una guardia di processo in
         *    Controllore.doWork() (vedi li' per i dettagli): un solo giro
         *    alla volta, chiunque lo richieda.
         *
         * 2. L'icona "hai scritto al venditore" (v1.28.0) diceva il
         *    contrario di cio' che l'utente vuole: doveva comparire per un
         *    messaggio SENZA offerta ("se e' stata fatta un'offerta abbiamo
         *    gia' il testo con l'importo"), non per qualunque proposta. Il
         *    dato per farlo bene (una conversazione Vinted senza offerta,
         *    l'elenco chat di Subito) non e' mai stato catturato da una
         *    sonda: l'icona e' tolta invece di indovinare i nomi dei campi
         *    — vedi i commenti in StatoRicerca.kt e SchermataRicerca.kt.
         *
         * --- versione precedente ---
         * versionCode = 54
         * versionName = "1.30.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.32.0 (2026-09-02) — due correzioni, dalla stessa sonda
         * (bdc42069-api.json, la conversazione Vinted con jhnmadsu, "Rtx 3060
         * gaming oc 12gb - Gigabyte") e una nuova.
         *
         * 1. "annunci con una mia proposta e un rilancio da parte del
         *    venditore sono scomparsi": non erano scomparsi, restavano
         *    marcati "Rifiutata" (la mia ultima offerta) anche quando il
         *    venditore aveva gia' rilanciato — la lettura riconosceva solo i
         *    messaggi "offer_request_message" (le mie offerte), non
         *    "offer_message" (i suoi rilanci), un tipo distinto trovato
         *    nella sonda. Corretto in Offerte.leggiConversazioneVinted (vedi
         *    li' per i dettagli): ora si distinguono i messaggi miei da
         *    quelli della controparte per user_id, non per tipo, e la
         *    scheda (SchermataRicerca.RigaOfferta) mostra entrambi gli
         *    importi quando c'e' un rilancio pendente.
         *
         * 2. "nella visualizzazione estesa non e' possibile scorrere le
         *    foto": la vista estesa mostrava sempre e solo la prima foto.
         *    Annuncio ora porta l'elenco completo (Annuncio.immagini) e la
         *    vista usa un HorizontalPager quando ce n'e' piu' di una (vedi
         *    SchermataRicerca.kt, RigaAnnuncio). Su Subito e' un dato certo
         *    (stesso array "images" gia' letto per la prima foto); su Vinted
         *    e' un'estensione ragionevole ma non ancora confermata da una
         *    sonda col contenuto vero — vedi il commento su Annuncio.immagini.
         *    La seconda meta' della segnalazione ("la descrizione appare
         *    solo per Subito") non e' un bug: il catalogo di ricerca Vinted
         *    non espone quel campo, e non da oggi — vedi Annuncio.kt.
         *
         * --- versione precedente ---
         * versionCode = 55
         * versionName = "1.31.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.33.0 (2026-09-02) — CORREZIONE minore, un irrobustimento non la
         * caccia a un bug ancora vivo: rileggendo la guardia anti-doppio-
         * avvio della v1.31.0 (Controllore.kt) per rispondere all'utente che
         * chiedeva conferma sul log gia' mandato, si e' visto che
         * "if (inCorso) return; inCorso = true" e' un controllo-poi-scrivi in
         * DUE passi, non atomico: una finestra in teoria apribile (minuscola,
         * poche istruzioni, non secondi) fra i due Controllore.doWork() che
         * la guardia dovrebbe proprio impedire di accavallarsi. Sostituito
         * con AtomicBoolean.compareAndSet(false, true), che fa la stessa cosa
         * in un'unica operazione garantita dalla CPU. Il log gia' analizzato
         * (controllo-log.txt fino al 2026-09-02 00:30) non mostra nessun
         * doppio avvio dopo l'installazione della v1.31.0: questa non e' la
         * correzione di un problema visto, e' la stessa garanzia resa vera
         * invece che "quasi sempre vera".
         *
         * --- versione precedente ---
         * versionCode = 56
         * versionName = "1.32.0"
         * --- fine versione precedente ---
         */
        /*
         * v1.34.0 (2026-09-02) — due correzioni sulla vista annunci, entrambe
         * segnalate dall'utente.
         *
         * 1. "in visualizzazione estesa i due pulsanti per preferiti e per
         *    nascondi sono sovrapposti": IconButton di Material3 impone
         *    un'area minima di tocco di 48dp anche quando gli si chiede una
         *    dimensione piu' piccola (qui 34dp) — l'area toccabile/dipinta
         *    risultava piu' larga della "fetta" di Row riservata dal layout
         *    in base ai 34dp dichiarati, e i due cerchi finivano per
         *    invadersi a vicenda. Sostituiti con un Box (clip circolare +
         *    sfondo + clickable) in SchermataRicerca.RigaAnnuncio: la
         *    dimensione dichiarata e' ora anche quella vera.
         *
         * 2. Nuovo: scorrere un annuncio da destra verso sinistra lo
         *    nasconde, sia in modalita' compatta che estesa, con un
         *    "pulsante di avviso" (sfondo colorato + icona + scritta
         *    "Nascondi l'annuncio") che compare durante lo scorrimento.
         *    Usa SwipeToDismissBox di Material3 (gia' nel compose-bom
         *    dell'app, nessuna libreria in piu'), e passa per la STESSA
         *    funzione "nascondi" gia' usata dalla ✕ — un solo percorso che
         *    nasconde davvero l'annuncio e offre "Annulla" nella snackbar,
         *    non due da tenere allineati.
         *
         * --- versione precedente ---
         * versionCode = 57
         * versionName = "1.33.0"
         * --- fine versione precedente ---
         */
        versionCode = 58
        versionName = "1.34.0"  // <-- aggiornare a ogni consegna
    }

    // Firma: keystore generato per il progetto, da conservare per tutti gli aggiornamenti futuri.
    signingConfigs {
        create("subitoplus") {
            storeFile = file("../keystore/subitoplus.jks")
            storePassword = "subitoplus"
            keyAlias = "subitoplus"
            keyPassword = "subitoplus"
        }
    }

    buildTypes {
        release {
            /*
             * v0.5.0 — con Compose l'APK non sfoltito arrivava a 18 MB.
             * Si attiva la rimozione del codice e delle risorse inutilizzate,
             * ma senza rinominare nulla (vedi proguard-rules.pro): i metodi del
             * ponte JavaScript sono chiamati per nome dalla pagina.
             *
             * --- versione precedente (fino alla v0.4.6, 2026-08-30) ---
             * isMinifyEnabled = false
             * --- fine versione precedente ---
             */
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("subitoplus")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // v0.5.0 — Fase 4, punto 1: fondamenta grafiche
    // v1.6.0 — buildConfig serve per mostrare la versione nella barra:
    // il numero deve venire da una fonte sola, quella di questo file.
    buildFeatures { compose = true; buildConfig = true }
}

/*
 * v0.2.0 (2026-08-30) — prima dipendenza esterna del progetto.
 * androidx.webkit serve per addDocumentStartJavaScript: iniettare il CSS
 * PRIMA che la pagina esegua i suoi script, cosi' i banner non lampeggiano
 * e in Fase 2 le card scartate non vengono mai disegnate.
 */
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")

    /*
     * v0.5.0 — Compose e Material 3.
     * Il resto dell'interfaccia e' ancora a viste tradizionali e ci resta finche'
     * non viene riscritta (punti 2 e seguenti): Compose e le viste convivono
     * nella stessa schermata, e questo permette di procedere un pezzo per volta
     * senza mai avere una build inutilizzabile.
     */
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.core:core-splashscreen:1.0.1")

    // v0.5.2 — caricamento immagini in Compose: cache, annullamento allo scorrimento,
    // priorita' a cio' che e' sullo schermo. Sostituisce il caricatore scritto a mano.
    implementation("io.coil-kt:coil-compose:2.7.0")

    // v0.6.0 — controlli periodici delle ricerche salvate
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
