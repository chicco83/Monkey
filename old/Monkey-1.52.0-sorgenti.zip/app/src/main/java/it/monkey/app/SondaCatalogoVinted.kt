package it.monkey.app

/*
 * Monkey — sonda: dove sta l'elenco degli annunci, ora che Vinted ha
 * cambiato pagina
 * v1.52.0 (2026-09-15) — nuovo
 *
 * IL PROBLEMA
 * "/api/v2/catalog/items" (usato dalla v0.4.0) ha smesso di funzionare:
 * l'utente ha segnalato errore 404, e una diagnostica ("ricerca-diagnostica.txt")
 * ha confermato che non e' un 404 JSON dell'API — e' la pagina generica
 * "non trovato" dell'app (stessa firma SVG gia' vista in passato per una
 * rotta inesistente, vedi DescrizioniVinted.kt). La rotta e' sparita.
 *
 * Una sonda sulla pagina di ricerca VERA di Vinted (Modalita' sonda, tab
 * "Sito", una ricerca fatta li' dentro) non ha mai mostrato nessuna
 * chiamata fetch/XHR che porti l'elenco degli annunci — solo suggerimenti
 * di ricerca, ricerche recenti, "promoted_closets" (gli annunci in
 * evidenza), banner. Ipotesi, sulla scorta di cosa e' gia' successo per la
 * descrizione dell'annuncio (v1.43.0, JSON-LD nell'HTML invece di una
 * chiamata a parte): l'elenco vero e proprio ora arriva DENTRO la pagina
 * quando la pagina stessa viene renderizzata (lato server), non con una
 * fetch separata che la sonda fetch/XHR possa vedere.
 *
 * COSA FA QUESTA SONDA
 * Attiva SOLO in "Modalita' sonda" e SOLO sulla pagina di ricerca/catalogo
 * di Vinted (l'indirizzo contiene "search_text=" o il percorso contiene
 * "/catalog" — non si sa ancora quale sia la forma esatta, si controllano
 * entrambe). Cerca prima il contenitore standard dei siti Next.js
 * (`<script id="__NEXT_DATA__">`, dati di partenza della pagina, gia' visti
 * altrove per siti costruiti allo stesso modo) e ne riporta l'inizio e un
 * pezzo intorno a un marcatore tipico di un oggetto-annuncio Vinted
 * ("catalog_items" o "favourite_count", un campo gia' noto dal vecchio
 * elenco JSON, vedi FonteVinted.leggi). Se __NEXT_DATA__ non c'e' o non
 * porta nulla di utile, scorre anche gli altri <script> della pagina in
 * cerca dello stesso marcatore — stessa tecnica gia' provata funzionante
 * per la descrizione (DescrizioniVinted.scriptSonda).
 *
 * Il risultato va nello stesso canale delle chiamate campionate (reportApi
 * -> ApiLog -> "api.json" in "Esporta diagnostica"), sotto il metodo
 * "SONDA-CATALOGO": compare insieme al resto, non serve un file a parte.
 *
 * QUESTA VERSIONE NON CAMBIA NULLA DI VISIBILE: e' solo la sonda. Una volta
 * letta la sua risposta si sapra' se e come cambiare FonteVinted.leggi()
 * per leggere l'elenco da dove sta davvero ora.
 *
 * Nota sintassi: niente template literal e niente simbolo dollaro nel JS,
 * come nel resto delle sonde di questo progetto (vedi DomProbe.kt e
 * DescrizioniVinted.scriptSonda).
 */
object SondaCatalogoVinted {

    fun script(ponte: String): String = """
    (function () {
      try {
        var href = String(location.href || '');
        var percorso = String(location.pathname || '');
        var isCatalogo = href.indexOf('search_text=') >= 0 || percorso.indexOf('/catalog') >= 0;
        if (!isCatalogo) return;

        var pezzi = [];
        var MARCATORI = ['catalog_items', 'favourite_count'];

        function cercaMarcatore(testo) {
          for (var m = 0; m < MARCATORI.length; m++) {
            var idx = testo.indexOf(MARCATORI[m]);
            if (idx >= 0) return { marcatore: MARCATORI[m], idx: idx };
          }
          return null;
        }

        var nd = document.getElementById('__NEXT_DATA__');
        if (nd) {
          var t = nd.textContent || '';
          pezzi.push('[__NEXT_DATA__] lunghezza=' + t.length + ' inizio=' + t.slice(0, 500));
          var trovNd = cercaMarcatore(t);
          if (trovNd) {
            pezzi.push('[__NEXT_DATA__ marcatore "' + trovNd.marcatore + '" a ' + trovNd.idx + '] ' +
              t.slice(Math.max(0, trovNd.idx - 80), trovNd.idx + 1200));
          } else {
            pezzi.push('[__NEXT_DATA__] nessun marcatore dentro');
          }
        } else {
          pezzi.push('[__NEXT_DATA__] assente');
        }

        var scripts = document.querySelectorAll('script');
        var trovatoAltrove = false;
        for (var i = 0; i < scripts.length; i++) {
          var s = scripts[i];
          if (s.id === '__NEXT_DATA__') continue;
          var c = s.textContent || '';
          var trov = cercaMarcatore(c);
          if (trov) {
            pezzi.push('[altro script #' + i + ', marcatore "' + trov.marcatore + '"] ' +
              c.slice(Math.max(0, trov.idx - 80), trov.idx + 1200));
            trovatoAltrove = true;
            break;
          }
        }
        if (!trovatoAltrove) pezzi.push('[altri script] nessun marcatore trovato (script totali: ' + scripts.length + ')');

        window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', 200, pezzi.join('\n---\n'));
      } catch (e) {
        try { window['$ponte'].reportApi(location.href, 'SONDA-CATALOGO', '', -1, String(e)); } catch (e2) {}
      }
    })();
    """.trimIndent()
}
