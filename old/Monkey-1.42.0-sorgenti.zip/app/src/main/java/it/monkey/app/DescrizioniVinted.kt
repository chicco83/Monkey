package it.monkey.app

/*
 * Monkey — il testo dell'annuncio, su Vinted
 * v1.40.0 (2026-09-05) — nuovo
 *
 * IL PROBLEMA, DALLA v1.7.0
 * La vista estesa mostra il testo dell'annuncio accanto ai dati: e' l'unica
 * cosa che in elenco manca davvero, ed e' cio' che fa decidere se aprire o no.
 * Su Subito arriva gia' con i risultati (campo "body", vedi FonteSubito.leggi),
 * su Vinted no: la sonda della v1.1.0 ha elencato i campi veri di un articolo
 * del catalogo —
 *   id, title, price, is_visible, brand_title, path, user, conversion, url,
 *   promoted, photos, photo, favourite_count, is_favourite, service_fee,
 *   total_item_price, view_count, size_title, status, item_box, ...
 * — e il testo non c'e', in nessuna forma. Da allora la colonna, sugli annunci
 * Vinted, resta semplicemente vuota.
 *
 * STESSA ARCHITETTURA DI LuoghiVinted.kt, e per lo stesso motivo
 * Il dato esiste sulla piattaforma ma sta su un'altra risposta, una per
 * articolo. E' identico a com'e' andata per il luogo del venditore: il
 * catalogo non lo espone, il profilo si'. Quindi qui si ripete lo schema che
 * la' funziona da nove versioni — coda, poche richieste per volta, pausa fra
 * l'una e l'altra, cache su file — invece di inventarne un altro.
 *
 * MA CON UNA DIFFERENZA CHE CAMBIA IL DOSAGGIO
 * Un venditore lo si incontra molte volte: la sua riga in cache viene riusata
 * da tutte le ricerche future, e il costo si ammortizza. Una descrizione no:
 * vale per QUEL solo annuncio, e un annuncio dell'usato lo si incrocia una
 * volta sola. Chiedere il testo di tutti e trenta i risultati di ogni pagina
 * vorrebbe dire trenta richieste per pagina che nessuna ricerca futura
 * riusera' mai — cioe' esattamente la firma che distingue un programma da una
 * persona (vedi "COME NON SEMBRARE UN BOT" in Controllore.kt).
 *
 * Percio' qui non si chiede nulla in anticipo: si chiede il testo SOLO degli
 * annunci che finiscono davvero sotto gli occhi, e solo in vista estesa —
 * l'unica in cui quel testo si vede (in vista compatta la colonna non esiste
 * proprio, vedi RigaAnnuncio in SchermataRicerca.kt). In pratica: le quattro o
 * cinque righe visibili, poi altre poche mentre si scorre. E' la stessa
 * andatura di chi guarda gli annunci uno dopo l'altro, non di chi li aspira.
 * Per lo stesso motivo qui si va con UNA richiesta per volta (PARALLELE = 1,
 * contro le due dei luoghi) e una pausa piu' lunga.
 *
 * L'INDIRIZZO — ED E' LA PARTE ANCORA DA CONFERMARE
 * La scheda articolo del sito legge GET /api/v2/items/<id>, che risponde
 * {"item": {..., "description": "..."}}. E' la stessa famiglia /api/v2/ gia'
 * usata da tutto il resto dell'app (catalogo, preferiti, profilo venditore,
 * conversazioni), chiamata in relativo dalla pagina vinted.it, con gli stessi
 * cookie: la strada e' quella di sempre, quindi il rischio e' basso. Quello
 * che NON e' stato ancora verificato su questa app e' il nome esatto del
 * campo nella risposta, perche' nessuna sonda ha mai catturato QUESTA
 * chiamata (le sonde fatte finora coprivano catalogo, preferiti, profili e
 * conversazioni).
 *
 * Invece di indovinare e basta, si fa come per la data (vedi CAMPI_DATA in
 * Fonti.kt): si prova una lista di nomi plausibili, in ordine, e ci si
 * accontenta del primo che porta del testo. E soprattutto — se NON ne porta
 * nessuno, la prima risposta illeggibile finisce nella diagnostica
 * (motore.diagnostica -> "ricerca-diagnostica.txt", "Esporta diagnostica"):
 * chiavi vere piu' un pezzo di corpo. Cosi' se questo tentativo sbaglia
 * bersaglio non serve un altro giro alla cieca, basta esportare una volta —
 * e' esattamente cio' che ha chiuso in due mosse il bug del controllo
 * automatico (v1.38.0), dopo che uno alla cieca (v1.37.0) aveva mancato.
 */

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File

object DescrizioniVinted {

    private const val FILE = "descrizioni_vinted.json"

    /*
     * Una per volta. I luoghi (LuoghiVinted) ne fanno due, ma li' la cache si
     * riusa fra ricerche diverse e la coda si esaurisce; qui ogni annuncio e'
     * una richiesta a perdere, quindi si va piu' piano — vedi il commento in
     * cima al file.
     */
    private const val PARALLELE = 1

    /** Pausa fra una richiesta e la successiva. */
    private const val PAUSA_MS = 600L

    /** Tetto della coda: si scorre in fretta, e cio' che e' gia' passato non serve piu'. */
    private const val CODA_MAX = 40

    /*
     * Quanto testo si tiene. In vista estesa se ne vedono al massimo sei righe
     * troncate (vedi RigaAnnuncio), quindi conservare l'annuncio intero
     * riempirebbe il file per niente. 800 caratteri stanno larghi dentro sei
     * righe su qualunque schermo.
     */
    private const val MAX_TESTO = 800

    /*
     * Quante descrizioni si conservano su file. A differenza dei luoghi — che
     * si riusano e quindi vale la pena tenere per sempre — queste servono
     * quasi solo a non richiedere due volte lo stesso annuncio nella stessa
     * giornata di ricerche (tornare indietro nell'elenco, ripetere una
     * ricerca, riaprire una ricerca salvata). Oltre il tetto cadono le piu'
     * vecchie: e' una cache, non un archivio.
     */
    private const val MAX_CACHE = 400

    private val ui = Handler(Looper.getMainLooper())

    /*
     * id annuncio -> testo gia' noto. Anche "" e' un valore buono: vuol dire
     * "chiesto, la piattaforma non ha dato testo" — senza, si richiederebbe
     * all'infinito lo stesso annuncio senza descrizione. LinkedHashMap perche'
     * l'ordine d'inserimento e' quello che serve per buttare via le piu'
     * vecchie quando si supera MAX_CACHE.
     */
    private val noti = LinkedHashMap<String, String>()

    private val coda = ArrayDeque<String>()
    private val inVolo = HashSet<String>()
    private var attivi = 0
    private var caricato = false
    private var daSalvare = false

    /*
     * La diagnostica si scrive una volta sola per sessione: serve a sapere
     * COM'E' FATTA la risposta, e la prima basta. Senza questa guardia, un
     * campo sbagliato riempirebbe il log con trenta copie della stessa cosa.
     */
    private var diagnosticaScritta = false

    // ------------------------------------------------------------------
    @Synchronized
    fun carica(ctx: Context) {
        if (caricato) return
        caricato = true
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return
        try {
            val root = JSONObject(f.readText())
            root.optJSONObject("descrizioni")?.let { o ->
                o.keys().forEach { k -> noti[k] = o.optString(k) }
            }
        } catch (t: Throwable) { /* file rovinato: si riparte da vuoto */ }
    }

    /** Testo gia' noto, oppure null se questo annuncio non e' ancora stato chiesto. */
    @Synchronized
    fun descrizione(id: String): String? = noti[id]

    /**
     * Chiede il testo di un annuncio Vinted, se non lo si ha gia'.
     *
     * Si chiama una riga per volta, da chi la sta DISEGNANDO in vista estesa
     * (vedi SchermataRicerca.RigaAnnuncio): e' il modo per chiedere solo cio'
     * che si guarda davvero — vedi il commento in cima al file.
     *
     * @param aggiornato invocato sul thread principale quando il testo e' pronto
     */
    /*
     * v1.42.0 (2026-09-08) — SOSPESA: la diagnostica mandata dall'utente ha
     * confermato che "GET /api/v2/items/<id>" non e' una rotta vera —
     * risponde 404 con la pagina generica dell'app (HTML con l'illustrazione
     * SVG "non trovato"), non un 404 JSON dell'API come quelli gia' visti
     * altrove (es. il 403 "access_denied" del cuore). E una sonda con
     * "Modalita' sonda" attiva, aperta su una scheda vera, non ha mai visto
     * IL CAMPIONATORE DI FETCH/XHR (ScriptApi) catturare nessuna chiamata per
     * il dettaglio: segno che il testo non arriva mai con una richiesta
     * separata, e' gia' dentro l'HTML della pagina quando arriva (reso lato
     * server). Insistere con questa chiamata userebbe solo richieste a
     * vuoto, per un endpoint che si sa gia' non esistere.
     *
     * Resta tutto il resto (cache, lettore, pulizia testo): quando la nuova
     * sonda qui sotto (scriptSonda) avra' confermato DOVE sta davvero il
     * testo nella pagina, tornera' una richiesta vera al posto del "return"
     * sottostante — stessa architettura, cambia solo come si arriva al dato.
     *
     * --- versione precedente (fino alla v1.41.0) ---
     * fun richiedi(
     *     ctx: Context,
     *     motore: MotoreRicerca,
     *     id: String,
     *     aggiornato: (id: String, testo: String) -> Unit
     * ) {
     *     carica(ctx)
     *     if (id.isBlank()) return
     *     if (noti.containsKey(id) || inVolo.contains(id) || coda.contains(id)) return
     *     if (coda.size >= CODA_MAX) return
     *     coda.addLast(id)
     *     while (attivi < PARALLELE && coda.isNotEmpty()) avviaProssimo(ctx, motore, aggiornato)
     * }
     * --- fine versione precedente ---
     */
    @Synchronized
    fun richiedi(
        ctx: Context,
        motore: MotoreRicerca,
        id: String,
        aggiornato: (id: String, testo: String) -> Unit
    ) {
        // v1.42.0 — sospesa, vedi il commento qui sopra: il corpo di prima
        // resta li', come "versione precedente", non qui sotto irraggiungibile.
    }

    /*
     * v1.42.0 (2026-09-08) — sonda per trovare DAVVERO come arriva il testo
     * di un annuncio Vinted, dopo che il tentativo per chiamata separata si
     * e' escluso da solo (vedi il commento su richiedi()).
     *
     * Se il testo e' gia' nell'HTML quando la pagina arriva, la forma piu'
     * comune (framework come Next.js/Nuxt, che Vinted usa per il proprio
     * sito) e' uno <script> con dentro lo stato iniziale della pagina in
     * JSON — spesso con id "__NEXT_DATA__" o simile, ma il nome esatto non
     * e' mai stato verificato qui, quindi questa sonda non lo presume:
     * scorre TUTTI gli <script> della pagina e si ferma al primo che
     * contiene la stringa '"description"', qualunque sia il suo id o tipo.
     * E' la stessa logica di "non si indovina, si guarda" gia' usata per i
     * campi delle risposte JSON (vedi CAMPI_TESTO sopra), spostata sull'HTML.
     *
     * Attiva SOLO in "Modalita' sonda" (come DomProbe) e SOLO sulle pagine
     * articolo di Vinted (percorso "/items/..."): su ogni altra pagina non
     * farebbe che sprecare un confronto a vuoto. Il risultato va a finire
     * nello stesso canale gia' usato per le chiamate campionate (reportApi
     * -> ApiLog -> "api.json" in "Esporta diagnostica"), cosi' compare
     * insieme a tutto il resto invece di aprire un file a parte.
     *
     * Nota sintassi: niente template literal e niente simbolo dollaro nel
     * JS, come nel resto delle sonde di questo progetto (vedi DomProbe.kt).
     */
    fun scriptSonda(ponte: String): String = """
    (function () {
      try {
        if (String(location.pathname || '').indexOf('/items/') === -1) return;
        var scripts = document.querySelectorAll('script');
        var trovato = null;
        for (var i = 0; i < scripts.length; i++) {
          var t = scripts[i].textContent || '';
          if (t.indexOf('"description"') >= 0) { trovato = t; break; }
        }
        if (trovato) {
          var idx = trovato.indexOf('"description"');
          var pezzo = trovato.slice(Math.max(0, idx - 80), idx + 2000);
          window['$ponte'].reportApi(location.href, 'SONDA-DESCRIZIONE', '', 200, pezzo);
        } else {
          window['$ponte'].reportApi(
            location.href, 'SONDA-DESCRIZIONE', '', 404,
            '(nessuno script con "description" trovato - script totali: ' + scripts.length + ')'
          );
        }
      } catch (e) {
        try { window['$ponte'].reportApi(location.href, 'SONDA-DESCRIZIONE', '', -1, String(e)); } catch (e2) {}
      }
    })();
    """.trimIndent()

    @Synchronized
    private fun avviaProssimo(
        ctx: Context,
        motore: MotoreRicerca,
        aggiornato: (String, String) -> Unit
    ) {
        val id = coda.removeFirstOrNull() ?: return
        inVolo.add(id)
        attivi++
        // Stessa strada di ricerca, preferiti e profili: dentro la pagina
        // Vinted, con i cookie dell'utente (vedi MotoreRicerca.azione).
        motore.azione(FonteVinted, Chiamata("GET", "/api/v2/items/$id")) { stato, corpo ->
            val testo = if (stato in 200..299) leggiDescrizione(corpo) else null
            if (testo == null) segnala(motore, id, stato, corpo)
            concluso(ctx, motore, id, testo, aggiornato)
        }
    }

    @Synchronized
    private fun concluso(
        ctx: Context,
        motore: MotoreRicerca,
        id: String,
        testo: String?,
        aggiornato: (String, String) -> Unit
    ) {
        inVolo.remove(id)
        attivi--
        if (testo != null) {
            noti[id] = testo
            // Il tetto si applica qui, subito: la piu' vecchia esce quando
            // entra la nuova, cosi' la mappa non cresce mai oltre MAX_CACHE.
            while (noti.size > MAX_CACHE) {
                val piuVecchia = noti.keys.firstOrNull() ?: break
                noti.remove(piuVecchia)
            }
            daSalvare = true
            if (testo.isNotBlank()) ui.post { aggiornato(id, testo) }
        }
        // Se la chiamata e' fallita non si registra nulla: la prossima volta
        // che l'annuncio compare si riprova. Nessuna lista di "falliti" come
        // in LuoghiVinted — li' un venditore torna spesso e insistere avrebbe
        // un costo, qui l'annuncio probabilmente non lo si rivede piu'.
        salvaFraPoco(ctx)
        if (coda.isNotEmpty()) ui.postDelayed({ avviaProssimo(ctx, motore, aggiornato) }, PAUSA_MS)
    }

    /*
     * I nomi plausibili del campo, in ordine. "description" e' quello che usa
     * la scheda articolo del sito; gli altri sono i nomi con cui lo stesso
     * concetto compare altrove nella stessa piattaforma e in quella di Subito
     * ("body", vedi FonteSubito.leggi) — costano una riga e coprono il caso in
     * cui l'indovinello sia mancato di poco. Stesso criterio di CAMPI_DATA in
     * Fonti.kt: si prova, non si pretende.
     */
    private val CAMPI_TESTO = listOf(
        "description", "body", "item_description", "description_text", "text"
    )

    private fun leggiDescrizione(corpo: String): String? = try {
        val root = JSONObject(corpo)
        // La risposta puo' essere {"item": {...}} oppure gia' l'articolo nudo.
        val o = root.optJSONObject("item") ?: root
        var trovato: String? = null
        for (k in CAMPI_TESTO) {
            val v = o.optString(k).trim()
            if (v.isNotEmpty() && v != "null") { trovato = v; break }
        }
        trovato?.let { pulisci(it) }
    } catch (t: Throwable) { null }

    /**
     * Il testo com'e' scritto dal venditore, solo accorciato e senza le righe
     * vuote di troppo: su Vinted si va spesso a capo per elencare misure e
     * difetti, e sei righe di elenco si riempirebbero di spazi invece che di
     * parole.
     */
    private fun pulisci(s: String): String {
        val compatto = s.replace(Regex("\n{2,}"), "\n").trim()
        return if (compatto.length <= MAX_TESTO) compatto
        else compatto.take(MAX_TESTO).trimEnd() + "…"
    }

    /*
     * La prova da mandare, se il campo non e' quello giusto. Non si scrive
     * l'intera risposta (puo' essere lunga e contiene anche i dati del
     * venditore): stato, chiavi di primo livello — che sono cio' che serve per
     * trovare il nome vero — e un pezzo di corpo per capirne la forma.
     */
    @Synchronized
    private fun segnala(motore: MotoreRicerca, id: String, stato: Int, corpo: String) {
        if (diagnosticaScritta) return
        diagnosticaScritta = true
        val chiavi = try {
            val root = JSONObject(corpo)
            val o = root.optJSONObject("item") ?: root
            o.keys().asSequence().joinToString(", ")
        } catch (t: Throwable) { "(risposta non JSON)" }
        motore.diagnostica.append(
            "[vinted] descrizione articolo $id -> stato $stato\n" +
                    "  campi cercati: ${CAMPI_TESTO.joinToString(", ")}\n" +
                    "  campi trovati: $chiavi\n" +
                    "  corpo (primi 1200): ${corpo.take(1200)}\n"
        )
    }

    // ------------------------------------------------------------------
    private fun salvaFraPoco(ctx: Context) {
        if (!daSalvare) return
        // Si scrive una volta sola a fine raffica, non a ogni risposta.
        ui.removeCallbacks(salvataggio)
        contesto = ctx.applicationContext
        ui.postDelayed(salvataggio, 1500)
    }

    private var contesto: Context? = null
    private val salvataggio = Runnable { salva() }

    @Synchronized
    private fun salva() {
        val ctx = contesto ?: return
        daSalvare = false
        try {
            val o = JSONObject()
            noti.forEach { (k, v) -> o.put(k, v) }
            File(ctx.filesDir, FILE).writeText(
                JSONObject().put("versione", "1.40.0").put("descrizioni", o).toString()
            )
        } catch (t: Throwable) { /* la cache e' un lusso, non un dato */ }
    }

    @Synchronized
    fun svuota(ctx: Context) {
        noti.clear(); coda.clear()
        try { File(ctx.filesDir, FILE).delete() } catch (t: Throwable) {}
    }
}
