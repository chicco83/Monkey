package it.zecchi.subitoplus

/*
 * Subito+ — filtri cosmetici
 * v0.2.0 (2026-08-30) — nuovo in Fase 1
 *
 * Il blocco di rete impedisce il download della pubblicita', ma nel DOM resta
 * il contenitore vuoto, che lascia un buco nel layout. Qui iniettiamo un foglio
 * di stile PRIMA che la pagina esegua i suoi script (document start), cosi'
 * non si vede nessun lampo, e un osservatore che richiude i contenitori
 * rimasti vuoti anche quando arrivano dopo, in scroll infinito.
 *
 * Il codice e' costruito a partire dalle regole caricate, non e' fisso.
 */
object Cosmetici {

    fun script(selettori: List<String>): String {
        if (selettori.isEmpty()) return "(function(){})();"
        val css = selettori.joinToString(",\n") { it } +
                "{display:none!important;height:0!important;min-height:0!important;margin:0!important;padding:0!important}"
        val cssJs = css.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "")

        return """
        (function () {
          var CSS = '$cssJs';

          function metti() {
            if (document.getElementById('subitoplus-css')) return;
            var testa = document.head || document.documentElement;
            if (!testa) return;
            var st = document.createElement('style');
            st.id = 'subitoplus-css';
            st.textContent = CSS;
            testa.appendChild(st);
          }
          metti();
          /* head puo' non esistere ancora al momento dell'iniezione */
          if (!document.getElementById('subitoplus-css')) {
            document.addEventListener('DOMContentLoaded', metti);
            var t = setInterval(function () {
              metti();
              if (document.getElementById('subitoplus-css')) clearInterval(t);
            }, 50);
          }

          /* Richiude i contenitori rimasti vuoti perche' la risorsa e' stata bloccata:
             solo elementi senza testo e senza figli visibili, per non toccare il sito. */
          function ripulisci() {
            var sospetti = document.querySelectorAll(
              'div[id*="adv"],div[id*="banner"],div[class*="adv"],div[class*="banner"],div[id^="div-gpt"]'
            );
            for (var i = 0; i < sospetti.length; i++) {
              var e = sospetti[i];
              if (e.dataset.spDone) continue;
              var vuoto = (e.textContent || '').trim().length === 0 && e.querySelector('img,video,canvas,svg,input,button,a') === null;
              if (vuoto && e.offsetHeight > 0) { e.style.setProperty('display', 'none', 'important'); }
              e.dataset.spDone = '1';
            }
          }

          var pend = false;
          function programma() {
            if (pend) return;
            pend = true;
            setTimeout(function () { pend = false; try { ripulisci(); } catch (e) {} }, 250);
          }
          document.addEventListener('DOMContentLoaded', function () {
            try { ripulisci(); } catch (e) {}
            try {
              new MutationObserver(programma).observe(document.documentElement,
                { childList: true, subtree: true });
            } catch (e) {}
          });
        })();
        """.trimIndent()
    }
}
