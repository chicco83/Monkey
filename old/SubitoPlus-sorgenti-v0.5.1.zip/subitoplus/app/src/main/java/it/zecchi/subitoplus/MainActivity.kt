package it.zecchi.subitoplus

/*
 * Subito+ — schermata principale
 * v0.5.1 (2026-08-30)
 *
 * Storia breve del file, perche' spiega com'e' fatto:
 *   v0.1.0  sonda: WebView nudo piu' registro delle richieste
 *   v0.2.0  blocco pubblicita' su shouldInterceptRequest, regole in JSON
 *   v0.3.0  scarto del singolo annuncio, archivio locale
 *   v0.3.2  riduzione delle tracce lasciate nella pagina
 *   v0.4.0  ricerca unificata Subito + Vinted come schermata principale
 *   v0.4.5  script iniettati messi a dieta (latenza sui pulsanti delle schede)
 *   v0.4.6  foto in elenco: resa da elenco invece dell'originale, coda a pila
 *   v0.5.0  Compose e Material 3: tema, icona, avvio, barra dei comandi
 *   v0.5.1  interruttore degli script di pagina, risposte bloccate con il tipo giusto
 *
 * Novita' della v0.5.0:
 *  - l'attivita' e' una ComponentActivity: serve a ospitare Compose e porta
 *    con se' la gestione moderna di "indietro" e dei risultati di attivita'
 *  - la fila di otto pulsanti diventa una barra Material 3 con un menu
 *  - tolto l'interruttore dello user agent: mascherarlo peggiora la
 *    riconoscibilita' invece di ridurla (vedi documento di piano), quindi
 *    resta sempre quello di sistema e non e' piu' una scelta esposta
 *
 * --- versione precedente (fino alla v0.4.6, 2026-08-30) ---
 * class MainActivity : Activity() ... barra: LinearLayout con otto Button
 * ... private var modoUa = 0 ... private fun cambiaUa() { ... }
 * --- fine versione precedente ---
 */

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private lateinit var prefs: SharedPreferences
    private lateinit var contenitore: FrameLayout
    private lateinit var motore: MotoreRicerca
    private lateinit var vista: VistaRicerca

    /** Nomi generati una volta per installazione: un nome fisso sarebbe un'impronta. */
    private lateinit var nomePonte: String
    private lateinit var pref: String

    @Volatile private var ultimoReportDom: String = "{}"

    private var bloccoAttivo = true
    private var vistaCompatta = false
    private var modoSonda = false
    /** v0.5.1 — spegne in blocco cio' che iniettiamo nelle pagine (vedi menu). */
    private var scriptPagina = true
    private var modoRicerca = true
    private var fonte = 0
    private var azzeraCronologia = false
    private var avanzamento: Int? = null

    private val HOME = arrayOf("https://www.subito.it/", "https://www.vinted.it/")

    private var scriptPrologo: androidx.webkit.ScriptHandler? = null
    private var scriptCosmetico: androidx.webkit.ScriptHandler? = null
    private var scriptAnnunci: androidx.webkit.ScriptHandler? = null
    private var scriptApi: androidx.webkit.ScriptHandler? = null

    /** Stato osservato dalla barra Compose. */
    private var statoBarra by mutableStateOf(
        StatoBarra(true, true, false, false, false, true, 0, "", null)
    )

    // ------------------------------------------------------------------
    // Risultati di attivita' esterne (selettore file e apertura documenti)
    // ------------------------------------------------------------------
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val selettoreFile = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        fileCallback?.onReceiveValue(
            WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
        )
        fileCallback = null
    }

    private val selettoreRegole = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) importaDocumento(uri) }

    // ------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()          // v0.5.0
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences("subitoplus", MODE_PRIVATE)
        bloccoAttivo = prefs.getBoolean("bloccoAttivo", true)
        vistaCompatta = prefs.getBoolean("vistaCompatta", false)
        modoSonda = prefs.getBoolean("modoSonda", false)
        scriptPagina = prefs.getBoolean("scriptPagina", true)
        nomePonte = nomeCasuale("nomePonte", "_")
        pref = nomeCasuale("prefisso", "")

        Regole.carica(this)
        Nascosti.carica(this)
        RequestLog.dettaglio = modoSonda
        Immagini.preparaCache(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // --- barra dei comandi in Compose ---
        root.addView(
            ComposeView(this).apply {
                setContent {
                    TemaSubitoPlus {
                        BarraSuperiore(statoBarra, azioni())
                    }
                }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // --- corpo: ricerca sopra, WebView sotto ---
        web = WebView(this)
        contenitore = FrameLayout(this)
        contenitore.addView(
            web,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        root.addView(
            contenitore,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)

        configuraWebView()
        registraScript()

        motore = MotoreRicerca(this, nomePonte, contenitore)
        Immagini.userAgent = WebSettings.getDefaultUserAgent(this)
        vista = VistaRicerca(
            this, motore,
            caricamento = { attivo ->
                avanzamento = if (attivo) -1 else null
                aggiornaStato()
            },
            apri = { a -> apriAnnuncio(a) },
            nascondi = { a ->
                Nascosti.aggiungi(this, a.chiave, a.titolo)
                vista.rimuovi(a)
                aggiornaStato()
            }
        )
        contenitore.addView(
            vista.radice,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        motore.prepara(FONTI)
        applicaModo()
        aggiornaStato()

        // v0.5.0 — "indietro": dalla scheda si torna alla ricerca, non fuori dall'app
        onBackPressedDispatcher.addCallback(this) {
            when {
                !modoRicerca && web.canGoBack() -> web.goBack()
                !modoRicerca -> { modoRicerca = true; applicaModo(); aggiornaStato() }
                else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        }
    }

    private fun azioni() = AzioniBarra(
        cambiaModo = { modoRicerca = !modoRicerca; applicaModo(); aggiornaStato() },
        cambiaBlocco = {
            bloccoAttivo = !bloccoAttivo
            prefs.edit().putBoolean("bloccoAttivo", bloccoAttivo).apply()
            registraScript(); web.reload(); aggiornaStato()
        },
        cambiaVista = {
            vistaCompatta = !vistaCompatta
            prefs.edit().putBoolean("vistaCompatta", vistaCompatta).apply()
            registraScript(); web.reload(); aggiornaStato()
        },
        cambiaScriptPagina = {
            scriptPagina = !scriptPagina
            prefs.edit().putBoolean("scriptPagina", scriptPagina).apply()
            toast(
                if (scriptPagina) "Script attivi: filtri, scarto annunci, vista compatta"
                else "Script spenti: la pagina gira come nel browser. Serve a capire di chi è una lentezza"
            )
            registraScript(); web.reload(); aggiornaStato()
        },
        cambiaSonda = {
            modoSonda = !modoSonda
            prefs.edit().putBoolean("modoSonda", modoSonda).apply()
            RequestLog.dettaglio = modoSonda
            toast(if (modoSonda) "Sonda accesa: lasciala accesa solo il tempo di raccogliere"
                  else "Sonda spenta")
            registraScript(); web.reload(); aggiornaStato()
        },
        cambiaFonte = {
            fonte = if (fonte == 0) 1 else 0
            modoRicerca = false
            applicaModo()
            azzeraCronologia = true
            web.loadUrl(HOME[fonte])
            aggiornaStato()
        },
        apriNascosti = { mostraNascosti() },
        caricaRegole = { selettoreRegole.launch(arrayOf("*/*")) },
        analizza = { analizzaPagina() },
        esporta = { esporta() },
        azzera = {
            RequestLog.reset(); Regole.bloccate = 0; ApiLog.reset()
            ultimoReportDom = "{}"; aggiornaStato()
        }
    )

    private fun nomeCasuale(chiave: String, prefisso: String): String {
        prefs.getString(chiave, null)?.let { return it }
        val lettere = "abcdefghijklmnopqrstuvwxyz"
        val alfa = lettere + "0123456789"
        val n = prefisso + lettere.random() + (1..10).map { alfa.random() }.joinToString("")
        prefs.edit().putString(chiave, n).apply()
        return n
    }

    // ------------------------------------------------------------------
    // WebView
    // ------------------------------------------------------------------
    private fun configuraWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = true

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        WebView.setWebContentsDebuggingEnabled(true)

        web.addJavascriptInterface(Ponte(), nomePonte)

        web.webViewClient = object : WebViewClient() {

            /* Qui passa ogni risorsa richiesta: e' il punto in cui si blocca. */
            override fun shouldInterceptRequest(
                view: WebView?, request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                RequestLog.record(url)
                if (!bloccoAttivo) return null
                if (!Regole.blocca(url)) return null
                Regole.bloccate++
                return rispostaVuota(url)
            }

            /*
             * v0.5.1 — una risposta vuota va servita con il tipo che la pagina
             * si aspetta. Un foglio di stile o uno script consegnati come
             * "text/plain" vengono rifiutati dal browser, e c'e' codice che in
             * quel caso ritenta o resta in attesa: proprio il genere di cosa
             * che si vede come qualche secondo di ritardo su un pulsante.
             */
            private fun rispostaVuota(url: String): WebResourceResponse {
                val u = url.substringBefore('?').lowercase()
                val tipo = when {
                    u.endsWith(".js") || u.contains(".js/") -> "application/javascript"
                    u.endsWith(".css") -> "text/css"
                    u.endsWith(".gif") || u.endsWith(".png") || u.endsWith(".jpg") ||
                    u.endsWith(".jpeg") || u.endsWith(".webp") || u.endsWith(".svg") -> "image/gif"
                    u.endsWith(".json") -> "application/json"
                    else -> "text/plain"
                }
                return WebResourceResponse(tipo, "utf-8", ByteArrayInputStream(ByteArray(0)))
            }

            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                if (u.scheme != "http" && u.scheme != "https") {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, u)); true }
                    catch (t: Throwable) { true }
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                if (bloccoAttivo && !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))
                    view?.evaluateJavascript(Cosmetici.script(Regole.cssNascondi, pref), null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (azzeraCronologia) { azzeraCronologia = false; view?.clearHistory() }
                avanzamento = null
                aggiornaStato()
                // La sonda DOM percorre l'intero albero: parte solo se richiesta.
                if (modoSonda) view?.postDelayed({ analizzaPagina() }, 1500)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try { selettoreFile.launch(params!!.createIntent()); true }
                catch (t: Throwable) { fileCallback = null; false }
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (!modoRicerca) avanzamento = if (newProgress in 1..99) newProgress else null
                aggiornaStato()
            }
        }
    }

    /** Iniezioni a document-start, nell'ordine in cui devono girare. */
    private fun registraScript() {
        scriptPrologo?.remove(); scriptPrologo = null
        scriptCosmetico?.remove(); scriptCosmetico = null
        scriptAnnunci?.remove(); scriptAnnunci = null
        scriptApi?.remove(); scriptApi = null
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return

        val subito = setOf("https://*.subito.it", "https://subito.it")
        val tutte = subito + setOf("https://*.vinted.it", "https://vinted.it")

        // Per primo: nasconde il ponte prima che la pagina possa vederlo.
        // Resta attivo anche a script spenti: e' l'unica cosa che tiene il ponte
        // fuori dalle proprieta' visibili di window.
        scriptPrologo = WebViewCompat.addDocumentStartJavaScript(web, Prologo.script(nomePonte), tutte)

        if (!scriptPagina) return   // v0.5.1

        if (bloccoAttivo) scriptCosmetico = WebViewCompat.addDocumentStartJavaScript(
            web, Cosmetici.script(Regole.cssNascondi, pref), subito
        )

        // Lo scarto degli annunci funziona anche con il blocco spento.
        scriptAnnunci = WebViewCompat.addDocumentStartJavaScript(
            web,
            ScriptAnnunci.script(Regole.sezioneIniziale, Regole.cercaApreForm, vistaCompatta, nomePonte, pref),
            subito
        )

        // Sostituire fetch e XHR e' la traccia piu' riconoscibile: solo su richiesta.
        if (modoSonda)
            scriptApi = WebViewCompat.addDocumentStartJavaScript(web, ScriptApi.script(nomePonte), tutte)
    }

    // ------------------------------------------------------------------
    // Ponte JS -> Kotlin
    // ------------------------------------------------------------------
    inner class Ponte {
        @JavascriptInterface
        fun nascondi(id: String, titolo: String) {
            Nascosti.aggiungi(this@MainActivity, id, titolo)
            runOnUiThread { aggiornaStato() }
        }

        @JavascriptInterface
        fun nascostiJson(): String = Nascosti.idJson()

        @JavascriptInterface
        fun reportDom(json: String) {
            ultimoReportDom = json
            runOnUiThread { aggiornaStato() }
        }

        @JavascriptInterface
        fun reportApi(url: String, stato: Int, corpo: String) {
            ApiLog.registra(url, stato, corpo)
            runOnUiThread { aggiornaStato() }
        }
    }

    // ------------------------------------------------------------------
    // Schermate e comandi
    // ------------------------------------------------------------------
    private fun applicaModo() {
        vista.radice.visibility = if (modoRicerca) View.VISIBLE else View.GONE
        web.visibility = if (modoRicerca) View.GONE else View.VISIBLE
        if (modoRicerca) avanzamento = null
        if (!modoRicerca && web.url.isNullOrBlank()) web.loadUrl(HOME[fonte])
    }

    private fun apriAnnuncio(a: Annuncio) {
        fonte = if (a.fonte == "subito") 0 else 1
        modoRicerca = false
        applicaModo()
        web.stopLoading()
        azzeraCronologia = true
        web.loadUrl(a.url)
        aggiornaStato()
    }

    private fun mostraNascosti() {
        val voci = Nascosti.elenco()
        if (voci.isEmpty()) { toast("Nessun annuncio nascosto"); return }
        val etichette = voci.map { (id, _, titolo) ->
            if (titolo.isBlank()) "annuncio $id" else titolo
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Nascosti (${voci.size}) — tocca per ripristinare")
            .setItems(etichette) { _, i ->
                Nascosti.rimuovi(this, voci[i].first)
                aggiornaStato(); web.reload()
            }
            .setNeutralButton("Ripristina tutti") { _, _ ->
                Nascosti.svuota(this); aggiornaStato(); web.reload()
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun analizzaPagina() =
        web.evaluateJavascript(DomProbe.script(Regole.cssNascondi, nomePonte), null)

    private fun aggiornaStato() {
        val j = try { org.json.JSONObject(ultimoReportDom) } catch (t: Throwable) { org.json.JSONObject() }
        val card = j.optInt("cardCandidate", -1)
        val riga = "richieste ${RequestLog.totalRequests()} · bloccate ${Regole.bloccate}" +
                (if (card >= 0) " · card $card" else "") +
                " · nascosti ${Nascosti.quanti()} · regole ${Regole.versioneRegole}"

        statoBarra = StatoBarra(
            modoRicerca = modoRicerca,
            bloccoAttivo = bloccoAttivo,
            vistaCompatta = vistaCompatta,
            modoSonda = modoSonda,
            fonteVinted = fonte == 1,
            scriptPagina = scriptPagina,
            nascosti = Nascosti.quanti(),
            riga = riga,
            avanzamento = avanzamento
        )
    }

    // ------------------------------------------------------------------
    // Import ed export
    // ------------------------------------------------------------------
    private fun importaDocumento(uri: Uri) {
        val testo = try {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
        } catch (t: Throwable) { null }

        // Lo stesso comando accetta due tipi di file, distinti dalla chiave "annunci".
        when {
            testo == null -> toast("File illeggibile")
            testo.contains("\"annunci\"") -> {
                val n = Nascosti.importa(this, testo)
                toast(if (n >= 0) "Importati $n annunci nascosti" else "Archivio non valido")
                aggiornaStato(); web.reload()
            }
            Regole.importa(this, testo) -> {
                registraScript(); web.reload()
                toast("Regole ${Regole.versioneRegole} attive")
                aggiornaStato()
            }
            else -> toast("File non riconosciuto")
        }
    }

    private fun esporta() {
        val ok = listOf(
            scriviInDownload("requests.json", RequestLog.requestsJson()),
            scriviInDownload("blocklist.json", RequestLog.blocklistJson()),
            scriviInDownload("selectors.json", ultimoReportDom),
            scriviInDownload("nascosti.json", Nascosti.esportaJson()),
            scriviInDownload("api.json", ApiLog.json()),
            scriviInDownload("ricerca-diagnostica.txt", motore.diagnostica.toString())
        ).all { it }
        toast(if (ok) "Esportati in Download/SubitoPlus" else "Esportazione non riuscita")
    }

    private fun scriviInDownload(nome: String, contenuto: String): Boolean = try {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nome)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/SubitoPlus")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
        uri?.let {
            contentResolver.openOutputStream(it, "wt")?.use { os ->
                os.write(contenuto.toByteArray(Charsets.UTF_8))
            }
            true
        } ?: false
    } catch (t: Throwable) { false }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
