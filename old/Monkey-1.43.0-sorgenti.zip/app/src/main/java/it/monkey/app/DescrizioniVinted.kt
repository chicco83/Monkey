package it.monkey.app

/*
 * Monkey — il testo dell'annuncio, su Vinted
 * v1.40.0 (2026-09-05) — nuovo
 *
 * IL PROBLEMA, DALLA v1.7.0
 * La vista estesa mostra il testo dell'annuncio accanto ai dati: e' l'unica
 * cosa che in elenco manca davvero, ed e' cio' che fa decidere se aprire o no.
 * Su Subito arriva gia' con i risultati (campo "body", vedi FonteSubito.leggi),
 * su Vinted no: la sonda della v1.1.0 ha elencato i campi veri di un articolo
 * del catalogo —
 *   id, title, price, is_visible, brand_title, path, user, conversion, url,
 *   promoted, photos, photo, favourite_count, is_favourite, service_fee,
 *   total_item_price, view_count, size_title, status, item_box, ...
 * — e il testo non c'e', in nessuna forma. Da allora la colonna, sugli annunci
 * Vinted, resta semplicemente vuota.
 *
 * STESSA ARCHITETTURA DI LuoghiVinted.kt, e per lo stesso motivo
 * Il dato esiste sulla piattaforma ma sta su un'altra risposta, una per
 * articolo. E' identico a com'e' andata per il luogo del venditore: il
 * catalogo non lo espone, il profilo si'. Quindi qui si ripete lo schema che
 * la' funziona da nove versioni — coda, poche richieste per volta, pausa fra
 * l'una e l'altra, cache su file — invece di inventarne un altro.
 *
 * MA CON UNA DIFFERENZA CHE CAMBIA IL DOSAGGIO
 * Un venditore lo si incontra molte volte: la sua riga in cache viene riusata
 * da tutte le ricerche future, e il costo si ammortizza. Una descrizione no:
 * vale per QUEL solo annuncio, e un annuncio dell'usato lo si incrocia una
 * volta sola. Chiedere il testo di tutti e trenta i risultati di ogni pagina
 * vorrebbe dire trenta richieste per pagina che nessuna ricerca futura
 * riusera' mai — cioe' esattamente la firma che distingue un programma da una
 * persona (vedi "COME NON SEMBRARE UN BOT" in Controllore.kt).
 *
 * Percio' qui non si chiede nulla in anticipo: si chiede il testo SOLO degli
 * annunci che finiscono davvero sotto gli occhi, e solo in vista estesa —
 * l'unica in cui quel testo si vede (in vista compatta la colonna non esiste
 * proprio, vedi RigaAnnuncio in SchermataRicerca.kt). In pratica: le quattro o
 * cinque righe visibili, poi altre poche mentre si scorre. E' la stessa
 * andatura di chi guarda gli annunci uno dopo l'altro, non di chi li aspira.
 * Per lo stesso motivo qui si va con UNA richiesta per volta (PARALLELE = 1,
 * contro le due dei luoghi) e una pausa piu' lunga.
 *
 * L'INDIRIZZO — IL PRIMO TENTATIVO, SBAGLIATO (v1.40.0)
 * Si era provato GET /api/v2/items/<id>, per analogia con la stessa famiglia
 * /api/v2/ gia' usata da tutto il resto dell'app. Una diagnostica mandata
 * dall'utente ha mostrato che risponde 404 con la pagina generica dell'app
 * (HTML con l'illustrazione SVG "non trovato"), non un 404 JSON come quelli
 * gia' visti altrove: la rotta non esiste. Vedi il commento su richiedi(),
 * piu' sotto, per il resto dell'indagine (sospesa in v1.42.0).
 *
 * L'INDIRIZZO VERO, TROVATO CON LA SONDA (v1.43.0)
 * Con "Modalita' sonda" attiva su una scheda Vinted vera, la sonda aggiunta
 * in v1.42.0 (scriptSonda, sotto) ha trovato il testo scorrendo gli <script>
 * della pagina: non arriva mai con una chiamata separata, e' gia' dentro
 * l'HTML quando la pagina arriva (reso lato server), in un blocco JSON-LD
 * standard — <script type="application/ld+json">{"@type":"Product",
 * "description":"...", ...}</script>. E' la stessa marcatura SEO che quasi
 * ogni sito di e-commerce mette sulla scheda di un prodotto: non un segreto
 * interno di Vinted, uno standard schema.org. Un esempio vero (dalla sonda):
 *
 *   {"@type":"Product","name":"Wled controller esp32 home assistant",
 *    "description":"New, sealed package.\n\nDm for questions",
 *    "image":"https://images1.vinted.net/...","brand":{"@type":"Brand",
 *    "name":"wled"},"offers":{"@type":"Offer","url":"https://www.vinted.it/
 *    items/...","priceCurrency":"EUR","price":15,"availability":"InStock",
 *    "itemCondition":"NewCondition"},"category":"Elettronica Altri
 *    accessori","color":"Nero","@context":"https://schema.org"}
 *
 * Quindi da questa versione non si chiama piu' un endpoint dell'API: si
 * scarica la PAGINA vera dell'annuncio (Annuncio.url, gia' salvato per ogni
 * risultato) con la stessa motore.azione() usata finora, e si legge il testo
 * dal blocco JSON-LD dentro l'HTML — vedi richiedi()/leggiDescrizioneHtml()
 * piu' sotto per i dettagli.
 */

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object DescrizioniVinted {

    private const val FILE = "descrizioni_vinted.json"

    /*
     * Una per volta. I luoghi (LuoghiVinted) ne fanno due, ma li' la cache si
     * riusa fra ricerche diverse e la coda si esaurisce; qui ogni annuncio e'
     * una richiesta a perdere, quindi si va piu' piano — vedi il commento in
     * cima al file.
     */
    private const val PARALLELE = 1

    /** Pausa fra una richiesta e la successiva. */
    private const val PAUSA_MS = 600L

    /** Tetto della coda: si scorre in fretta, e cio' che e' gia' passato non serve piu'. */
    private const val CODA_MAX = 40

    /*
     * Quanto testo si tiene. In vista estesa se ne vedono al massimo sei righe
     * troncate (vedi RigaAnnuncio), quindi conservare l'annuncio intero
     * riempirebbe il file per niente. 800 caratteri stanno larghi dentro sei
     * righe su qualunque schermo.
     */
    private const val MAX_TESTO = 800

    /*
     * Quante descrizioni si conservano su file. A differenza dei luoghi — che
     * si riusano e quindi vale la pena tenere per sempre — queste servono
     * quasi solo a non richiedere due volte lo stesso annuncio nella stessa
     * giornata di ricerche (tornare indietro nell'elenco, ripetere una
     * ricerca, riaprire una ricerca salvata). Oltre il tetto cadono le piu'
     * vecchie: e' una cache, non un archivio.
     */
    private const val MAX_CACHE = 400

    private val ui = Handler(Looper.getMainLooper())

    /*
     * id annuncio -> testo gia' noto. Anche "" e' un valore buono: vuol dire
     * "chiesto, la piattaforma non ha dato testo" — senza, si richiederebbe
     * all'infinito lo stesso annuncio senza descrizione. LinkedHashMap perche'
     * l'ordine d'inserimento e' quello che serve per buttare via le piu'
     * vecchie quando si supera MAX_CACHE.
     */
    private val noti = LinkedHashMap<String, String>()

    private val coda = ArrayDeque<String>()

    /*
     * v1.43.0 — l'url della pagina dell'annuncio, per ogni id in coda.
     * Prima la chiamata era sempre allo stesso indirizzo (solo l'id
     * cambiava, "/api/v2/items/<id>"); ora si scarica la PAGINA vera
     * dell'annuncio (vedi il commento in cima al file), il cui indirizzo
     * cambia da un annuncio all'altro e va quindi portato con la coda.
     */
    private val urlPerId = HashMap<String, String>()

    private val inVolo = HashSet<String>()
    private var attivi = 0
    private var caricato = false
    private var daSalvare = false

    /*
     * La diagnostica si scrive una volta sola per sessione: serve a sapere
     * COM'E' FATTA la risposta, e la prima basta. Senza questa guardia, un
     * campo sbagliato riempirebbe il log con trenta copie della stessa cosa.
     */
    private var diagnosticaScritta = false

    // ------------------------------------------------------------------
    @Synchronized
    fun carica(ctx: Context) {
        if (caricato) return
        caricato = true
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return
        try {
            val root = JSONObject(f.readText())
            root.optJSONObject("descrizioni")?.let { o ->
                o.keys().forEach { k -> noti[k] = o.optString(k) }
            }
        } catch (t: Throwable) { /* file rovinato: si riparte da vuoto */ }
    }

    /** Testo gia' noto, oppure null se questo annuncio non e' ancora stato chiesto. */
    @Synchronized
    fun descrizione(id: String): String? = noti[id]

    /**
     * Chiede il testo di un annuncio Vinted, se non lo si ha gia'.
     *
     * Si chiama una riga per volta, da chi la sta DISEGNANDO in vista estesa
     * (vedi SchermataRicerca.RigaAnnuncio): e' il modo per chiedere solo cio'
     * che si guarda davvero — vedi il commento in cima al file.
     *
     * @param url la pagina vera dell'annuncio (Annuncio.url): da v1.43.0 e'
     *        quella che si scarica, non piu' un endpoint dell'API — vedi il
     *        commento in cima al file.
     * @param aggiornato invocato sul thread principale quando il testo e' pronto
     */
    /*
     * v1.43.0 (2026-09-08) — RIATTIVATA con l'indirizzo vero: la sonda
     * scriptSonda (sotto) ha trovato il testo in un blocco JSON-LD dentro
     * l'HTML della pagina annuncio (schema.org "Product", campo
     * "description") — vedi il commento in cima al file per l'esempio vero
     * catturato. Non si chiama piu' un endpoint API: si scarica la pagina
     * vera (Annuncio.url) con motore.azione(), e si legge il testo dal primo
     * <script> che lo contiene (leggiDescrizioneHtml, piu' sotto) — stessa
     * coda/cache/dosaggio di prima, cambia solo COME si arriva al dato.
     *
     * --- versione precedente (v1.42.0, 2026-09-08) — SOSPESA ---
     * // La diagnostica mandata dall'utente ha confermato che
     * // "GET /api/v2/items/<id>" non e' una rotta vera — risponde 404 con
     * // la pagina generica dell'app (HTML con l'illustrazione SVG "non
     * // trovato"), non un 404 JSON dell'API come quelli gia' visti altrove
     * // (es. il 403 "access_denied" del cuore). E una sonda con "Modalita'
     * // sonda" attiva, aperta su una scheda vera, non ha mai visto IL
     * // CAMPIONATORE DI FETCH/XHR (ScriptApi) catturare nessuna chiamata
     * // per il dettaglio: segno che il testo non arriva mai con una
     * // richiesta separata, e' gia' dentro l'HTML della pagina quando
     * // arriva (reso lato server). Insistere con questa chiamata userebbe
     * // solo richieste a vuoto, per un endpoint che si sa gia' non
     * // esistere.
     * fun richiedi(
     *     ctx: Context,
     *     motore: MotoreRicerca,
     *     id: String,
     *     aggiornato: (id: String, testo: String) -> Unit
     * ) {
     *     // v1.42.0 — sospesa: il corpo di prima resta li', come
     *     // "versione precedente", non qui sotto irraggiungibile.
     * }
     * --- fine versione precedente ---
     *
     * --- versione precedente (fino alla v1.41.0) ---
     * fun richiedi(
     *     ctx: Context,
     *     motore: MotoreRicerca,
     *     id: String,
     *     aggiornato: (id: String, testo: String) -> Unit
     * ) {
     *     carica(ctx)
     *     if (id.isBlank()) return
     *     if (noti.containsKey(id) || inVolo.contains(id) || coda.contains(id)) return
     *     if (coda.size >= CODA_MAX) return
     *     coda.addLast(id)
     *     while (attivi < PARALLELE && coda.isNotEmpty()) avviaProssimo(ctx, motore, aggiornato)
     * }
     * --- fine versione precedente ---
     */
    @Synchronized
    fun richiedi(
        ctx: Context,
        motore: MotoreRicerca,
        id: String,
        url: String,
        aggiornato: (id: String, testo: String) -> Unit
    ) {
        carica(ctx)
        if (id.isBlank() || url.isBlank()) return
        if (noti.containsKey(id) || inVolo.contains(id) || coda.contains(id)) return
        if (coda.size >= CODA_MAX) return
        coda.addLast(id)
        urlPerId[id] = url
        while (attivi < PARALLELE && coda.isNotEmpty()) avviaProssimo(ctx, motore, aggiornato)
    }

    /*
     * v1.42.0 (2026-09-08) — sonda per trovare DAVVERO come arriva il testo
     * di un annuncio Vinted, dopo che il tentativo per chiamata separata si
     * e' escluso da solo (vedi il commento su richiedi()).
     *
     * Se il testo e' gia' nell'HTML quando la pagina arriva, la forma piu'
     * comune (framework come Next.js/Nuxt, che Vinted usa per il proprio
     * sito) e' uno <script> con dentro lo stato iniziale della pagina in
     * JSON — spesso con id "__NEXT_DATA__" o simile, ma il nome esatto non
     * e' mai stato verificato qui, quindi questa sonda non lo presume:
     * scorre TUTTI gli <script> della pagina e si ferma al primo che
     * contiene la stringa '"description"', qualunque sia il suo id o tipo.
     * E' la stessa logica di "non si indovina, si guarda" gia' usata per i
     * campi delle risposte JSON (vedi CAMPI_TESTO, versione precedente piu'
     * sotto), spostata sull'HTML.
     *
     * RISULTATO (v1.43.0): ha trovato un blocco JSON-LD schema.org/Product
     * — vedi il commento in cima al file. La sonda resta nel codice anche
     * dopo il successo: come "Modalita' sonda" in generale, serve a
     * diagnosticare un domani se Vinted cambia pagina e il testo smette di
     * arrivare (stessa logica per cui non si toglie mai "Esporta
     * diagnostica" a bug chiuso).
     *
     * Attiva SOLO in "Modalita' sonda" (come DomProbe) e SOLO sulle pagine
     * articolo di Vinted (percorso "/items/..."): su ogni altra pagina non
     * farebbe che sprecare un confronto a vuoto. Il risultato va a finire
     * nello stesso canale gia' usato per le chiamate campionate (reportApi
     * -> ApiLog -> "api.json" in "Esporta diagnostica"), cosi' compare
     * insieme a tutto il resto invece di aprire un file a parte.
     *
     * Nota sintassi: niente template literal e niente simbolo dollaro nel
     * JS, come nel resto delle sonde di questo progetto (vedi DomProbe.kt).
     */
    fun scriptSonda(ponte: String): String = """
    (function () {
      try {
        if (String(location.pathname || '').indexOf('/items/') === -1) return;
        var scripts = document.querySelectorAll('script');
        var trovato = null;
        for (var i = 0; i < scripts.length; i++) {
          var t = scripts[i].textContent || '';
          if (t.indexOf('"description"') >= 0) { trovato = t; break; }
        }
        if (trovato) {
          var idx = trovato.indexOf('"description"');
          var pezzo = trovato.slice(Math.max(0, idx - 80), idx + 2000);
          window['$ponte'].reportApi(location.href, 'SONDA-DESCRIZIONE', '', 200, pezzo);
        } else {
          window['$ponte'].reportApi(
            location.href, 'SONDA-DESCRIZIONE', '', 404,
            '(nessuno script con "description" trovato - script totali: ' + scripts.length + ')'
          );
        }
      } catch (e) {
        try { window['$ponte'].reportApi(location.href, 'SONDA-DESCRIZIONE', '', -1, String(e)); } catch (e2) {}
      }
    })();
    """.trimIndent()

    @Synchronized
    private fun avviaProssimo(
        ctx: Context,
        motore: MotoreRicerca,
        aggiornato: (String, String) -> Unit
    ) {
        val id = coda.removeFirstOrNull() ?: return
        val url = urlPerId.remove(id)
        if (url.isNullOrBlank()) {
            // Non dovrebbe succedere (richiedi() li scrive insieme), ma se
            // capita non si perde il turno: si passa al prossimo in coda.
            avviaProssimo(ctx, motore, aggiornato)
            return
        }
        inVolo.add(id)
        attivi++
        /*
         * v1.43.0 — non piu' l'endpoint API (vedi versione precedente su
         * richiedi()): si scarica la PAGINA vera dell'annuncio, stessa
         * sessione con i cookie dell'utente di sempre (vedi
         * MotoreRicerca.azione). La risposta e' HTML, non JSON — leggiamo il
         * testo da li' con leggiDescrizioneHtml(), non con un campo di primo
         * livello come prima.
         *
         * --- versione precedente (fino alla v1.41.0) ---
         * motore.azione(FonteVinted, Chiamata("GET", "/api/v2/items/$id")) { stato, corpo ->
         *     val testo = if (stato in 200..299) leggiDescrizione(corpo) else null
         *     if (testo == null) segnala(motore, id, stato, corpo)
         *     concluso(ctx, motore, id, testo, aggiornato)
         * }
         * --- fine versione precedente ---
         */
        motore.azione(FonteVinted, Chiamata("GET", url)) { stato, corpo ->
            val testo = if (stato in 200..299) leggiDescrizioneHtml(corpo) else null
            if (testo == null) segnala(motore, id, stato, corpo)
            concluso(ctx, motore, id, testo, aggiornato)
        }
    }

    @Synchronized
    private fun concluso(
        ctx: Context,
        motore: MotoreRicerca,
        id: String,
        testo: String?,
        aggiornato: (String, String) -> Unit
    ) {
        inVolo.remove(id)
        attivi--
        if (testo != null) {
            noti[id] = testo
            // Il tetto si applica qui, subito: la piu' vecchia esce quando
            // entra la nuova, cosi' la mappa non cresce mai oltre MAX_CACHE.
            while (noti.size > MAX_CACHE) {
                val piuVecchia = noti.keys.firstOrNull() ?: break
                noti.remove(piuVecchia)
            }
            daSalvare = true
            if (testo.isNotBlank()) ui.post { aggiornato(id, testo) }
        }
        // Se la chiamata e' fallita non si registra nulla: la prossima volta
        // che l'annuncio compare si riprova. Nessuna lista di "falliti" come
        // in LuoghiVinted — li' un venditore torna spesso e insistere avrebbe
        // un costo, qui l'annuncio probabilmente non lo si rivede piu'.
        salvaFraPoco(ctx)
        if (coda.isNotEmpty()) ui.postDelayed({ avviaProssimo(ctx, motore, aggiornato) }, PAUSA_MS)
    }

    /*
     * v1.43.0 — lettura del testo dalla PAGINA HTML dell'annuncio, non piu'
     * da un campo JSON di primo livello (vedi il commento in cima al file:
     * l'indirizzo cambiato da API a pagina vera).
     *
     * Stessa filosofia di "non si indovina, si guarda" di prima: si cerca
     * PRIMA nella forma standard e piu' affidabile (uno <script
     * type="application/ld+json"> — marcatura SEO schema.org, quella che la
     * sonda ha trovato per davvero, vedi l'esempio in cima al file), e SOLO
     * se non si trova nulla li' si ripiega su qualunque <script> contenga la
     * stringa '"description"' (stessa euristica della sonda scriptSonda,
     * sopra) provando a leggerlo come JSON. Se nessuna delle due strade porta
     * testo, la risposta finisce in diagnostica (segnala(), sotto) invece di
     * restare un buco silenzioso.
     */
    private val SCRIPT_LDJSON = Regex(
        "<script[^>]*type=[\"']application/ld\\+json[\"'][^>]*>([\\s\\S]*?)</script>",
        RegexOption.IGNORE_CASE
    )
    private val SCRIPT_QUALSIASI = Regex(
        "<script[^>]*>([\\s\\S]*?)</script>",
        RegexOption.IGNORE_CASE
    )

    private fun leggiDescrizioneHtml(html: String): String? {
        for (m in SCRIPT_LDJSON.findAll(html)) {
            leggiDaBloccoJson(m.groupValues[1])?.let { return pulisci(it) }
        }
        for (m in SCRIPT_QUALSIASI.findAll(html)) {
            val corpo = m.groupValues[1]
            if (corpo.contains("\"description\"")) {
                leggiDaBloccoJson(corpo)?.let { return pulisci(it) }
            }
        }
        return null
    }

    /**
     * Prova a leggere "description" da un blocco che dovrebbe essere JSON
     * puro (il contenuto di uno <script> ld+json, o comunque qualunque
     * <script> il cui intero corpo si legga come JSON). Un oggetto nudo
     * ({"@type":"Product",...}, il caso confermato dalla sonda), un array
     * ([{...}, {...}], caso schema.org valido ma non ancora visto qui), o un
     * oggetto con "@graph" (altra forma standard di JSON-LD con piu' entita'
     * nella stessa pagina) — si prova ognuna, si accetta la prima con del
     * testo vero.
     */
    private fun leggiDaBloccoJson(testo: String): String? = try {
        val t = testo.trim()
        when {
            t.startsWith("[") -> leggiDescrizioneDaArray(JSONArray(t))
            t.startsWith("{") -> {
                val o = JSONObject(t)
                val graph = o.optJSONArray("@graph")
                if (graph != null) leggiDescrizioneDaArray(graph)
                else campoTesto(o)
            }
            else -> null
        }
    } catch (e: Throwable) { null }

    private fun leggiDescrizioneDaArray(arr: JSONArray): String? {
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            campoTesto(o)?.let { return it }
        }
        return null
    }

    private fun campoTesto(o: JSONObject): String? {
        val v = o.optString("description").trim()
        return if (v.isNotEmpty() && v != "null") v else null
    }

    /*
     * --- versione precedente (fino alla v1.42.0, lettura da risposta JSON
     *     dell'API "/api/v2/items/<id>", mai risultata una rotta vera) ---
     * private val CAMPI_TESTO = listOf(
     *     "description", "body", "item_description", "description_text", "text"
     * )
     *
     * private fun leggiDescrizione(corpo: String): String? = try {
     *     val root = JSONObject(corpo)
     *     val o = root.optJSONObject("item") ?: root
     *     var trovato: String? = null
     *     for (k in CAMPI_TESTO) {
     *         val v = o.optString(k).trim()
     *         if (v.isNotEmpty() && v != "null") { trovato = v; break }
     *     }
     *     trovato?.let { pulisci(it) }
     * } catch (t: Throwable) { null }
     * --- fine versione precedente ---
     */

    /**
     * Il testo com'e' scritto dal venditore, solo accorciato e senza le righe
     * vuote di troppo: su Vinted si va spesso a capo per elencare misure e
     * difetti, e sei righe di elenco si riempirebbero di spazi invece che di
     * parole.
     */
    private fun pulisci(s: String): String {
        val compatto = s.replace(Regex("\n{2,}"), "\n").trim()
        return if (compatto.length <= MAX_TESTO) compatto
        else compatto.take(MAX_TESTO).trimEnd() + "…"
    }

    /*
     * La prova da mandare, se non si e' trovato testo. Non si scrive l'intera
     * pagina (puo' pesare svariati megabyte): stato e un pezzo di corpo, che
     * bastano a capire se la pagina e' arrivata per davvero (HTML vero) o se
     * la sessione ha ricevuto qualcos'altro (per esempio un blocco anti-bot).
     */
    /*
     * v1.43.0 — adattata alla risposta HTML (prima leggeva le chiavi di primo
     * livello di una risposta JSON, che qui non esiste piu').
     *
     * --- versione precedente (fino alla v1.42.0) ---
     * @Synchronized
     * private fun segnala(motore: MotoreRicerca, id: String, stato: Int, corpo: String) {
     *     if (diagnosticaScritta) return
     *     diagnosticaScritta = true
     *     val chiavi = try {
     *         val root = JSONObject(corpo)
     *         val o = root.optJSONObject("item") ?: root
     *         o.keys().asSequence().joinToString(", ")
     *     } catch (t: Throwable) { "(risposta non JSON)" }
     *     motore.diagnostica.append(
     *         "[vinted] descrizione articolo $id -> stato $stato\n" +
     *                 "  campi cercati: ${CAMPI_TESTO.joinToString(", ")}\n" +
     *                 "  campi trovati: $chiavi\n" +
     *                 "  corpo (primi 1200): ${corpo.take(1200)}\n"
     *     )
     * }
     * --- fine versione precedente ---
     */
    @Synchronized
    private fun segnala(motore: MotoreRicerca, id: String, stato: Int, corpo: String) {
        if (diagnosticaScritta) return
        diagnosticaScritta = true
        motore.diagnostica.append(
            "[vinted] descrizione articolo $id -> stato $stato\n" +
                    "  cercato: uno <script> (preferibilmente ld+json) con un campo " +
                    "\"description\" leggibile come JSON\n" +
                    "  corpo (primi 1200): ${corpo.take(1200)}\n"
        )
    }

    // ------------------------------------------------------------------
    private fun salvaFraPoco(ctx: Context) {
        if (!daSalvare) return
        // Si scrive una volta sola a fine raffica, non a ogni risposta.
        ui.removeCallbacks(salvataggio)
        contesto = ctx.applicationContext
        ui.postDelayed(salvataggio, 1500)
    }

    private var contesto: Context? = null
    private val salvataggio = Runnable { salva() }

    @Synchronized
    private fun salva() {
        val ctx = contesto ?: return
        daSalvare = false
        try {
            val o = JSONObject()
            noti.forEach { (k, v) -> o.put(k, v) }
            File(ctx.filesDir, FILE).writeText(
                JSONObject().put("versione", "1.43.0").put("descrizioni", o).toString()
            )
        } catch (t: Throwable) { /* la cache e' un lusso, non un dato */ }
    }

    @Synchronized
    fun svuota(ctx: Context) {
        noti.clear(); coda.clear(); urlPerId.clear()
        try { File(ctx.filesDir, FILE).delete() } catch (t: Throwable) {}
    }
}
