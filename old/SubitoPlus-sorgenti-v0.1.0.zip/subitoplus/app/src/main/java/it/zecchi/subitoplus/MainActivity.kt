package it.zecchi.subitoplus

/*
 * Subito+ — Fase 0 "Sonda"
 * v0.1.0 (2026-08-30)
 *
 * Cosa fa questa build:
 *  - apre subito.it dentro un WebView configurato come lo sara' l'app finale
 *  - osserva (senza bloccare) ogni richiesta di rete e la classifica
 *  - analizza la struttura della pagina per trovare l'ancora delle card annuncio
 *  - esporta tre file JSON in Download/SubitoPlus da cui nascono Fase 1 e Fase 2
 *
 * Cosa NON fa ancora: bloccare pubblicita', nascondere annunci, notificare.
 * Quelle sono Fase 1, 2 e 3.
 */

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var stato: TextView

    /** Ultimo report DOM ricevuto dallo script iniettato. */
    @Volatile private var ultimoReportDom: String = "{}"

    /** Selettore file per i campi <input type=file> (serve gia' per pubblicare un annuncio). */
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val RC_FILE = 1001

    /*
     * User agent: la sonda serve anche a capire se il sito si comporta diversamente
     * quando riconosce un WebView (stringa che contiene "; wv").
     * 0 = default del sistema, 1 = stessa stringa senza il marcatore wv.
     */
    private var modoUa = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ---------- interfaccia costruita a mano: zero dipendenze, zero layout XML ----------
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val barra = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
        }
        barra.addView(bottone("Analizza") { analizzaPagina() })
        barra.addView(bottone("Esporta") { esporta() })
        barra.addView(bottone("Azzera") {
            RequestLog.reset(); ultimoReportDom = "{}"; aggiornaStato(); toast("Contatori azzerati")
        })
        barra.addView(bottone("UA") { cambiaUa() })

        val scroller = HorizontalScrollView(this).apply { addView(barra) }
        root.addView(scroller, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT))

        stato = TextView(this).apply {
            setPadding(16, 0, 16, 8)
            textSize = 12f
        }
        root.addView(stato)

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        configuraWebView()
        web.loadUrl("https://www.subito.it/")
        aggiornaStato()
    }

    private fun bottone(testo: String, azione: () -> Unit) = Button(this).apply {
        text = testo
        textSize = 13f
        setOnClickListener { azione() }
    }

    // ------------------------------------------------------------------
    // Configurazione del WebView: e' la stessa che usera' l'app definitiva
    // ------------------------------------------------------------------
    private fun configuraWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = true
        if (modoUa == 1) s.userAgentString = s.userAgentString.replace("; wv", "")

        // Cookie: senza terze parti login e chat possono non reggere.
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        WebView.setWebContentsDebuggingEnabled(true) // solo in Fase 0

        web.addJavascriptInterface(Bridge(), "SondaBridge")

        web.webViewClient = object : WebViewClient() {

            /*
             * Punto chiave dell'intera architettura: qui passa OGNI risorsa richiesta.
             * In Fase 0 osserviamo e lasciamo passare (return null).
             * In Fase 1 questa stessa funzione restituira' una risposta vuota
             * per gli host in blocklist.
             */
            override fun shouldInterceptRequest(
                view: WebView?, request: WebResourceRequest?
            ): WebResourceResponse? {
                request?.url?.toString()?.let { RequestLog.record(it) }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView?, req: WebResourceRequest?): Boolean {
                val u = req?.url ?: return false
                // I link non http (tel:, mailto:, intent:) escono verso le app di sistema.
                if (u.scheme != "http" && u.scheme != "https") {
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, u)); true
                    } catch (t: Throwable) { true }
                }
                return false // tutto il resto resta dentro l'app
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                aggiornaStato()
                // analisi automatica: cosi' il report c'e' anche se non premi "Analizza"
                view?.postDelayed({ analizzaPagina() }, 1200)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    startActivityForResult(params!!.createIntent(), RC_FILE); true
                } catch (t: Throwable) {
                    fileCallback = null; false
                }
            }
            override fun onProgressChanged(view: WebView?, newProgress: Int) = aggiornaStato()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == RC_FILE) {
            val res = if (resultCode == Activity.RESULT_OK)
                WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCallback?.onReceiveValue(res)
            fileCallback = null
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush() // la sessione deve sopravvivere alla chiusura
    }

    // ------------------------------------------------------------------
    // Ponte JS -> Kotlin: in Fase 2 sara' la stessa strada usata dal
    // pulsante "nascondi annuncio" per scrivere l'ID nel database locale.
    // ------------------------------------------------------------------
    inner class Bridge {
        @JavascriptInterface
        fun report(json: String) {
            ultimoReportDom = json
            runOnUiThread { aggiornaStato() }
        }
    }

    private fun analizzaPagina() {
        web.evaluateJavascript(DomProbe.SCRIPT, null)
    }

    private fun cambiaUa() {
        modoUa = if (modoUa == 0) 1 else 0
        val s = web.settings
        s.userAgentString = if (modoUa == 1)
            WebSettings.getDefaultUserAgent(this).replace("; wv", "")
        else
            WebSettings.getDefaultUserAgent(this)
        toast(if (modoUa == 1) "UA senza marcatore WebView" else "UA di sistema")
        web.reload()
    }

    private fun aggiornaStato() {
        val cards = try { org.json.JSONObject(ultimoReportDom).optInt("cardTrovate", -1) } catch (t: Throwable) { -1 }
        stato.text = "richieste ${RequestLog.totalRequests()} · host ${RequestLog.totalHosts()} · " +
                "sospetti ${RequestLog.suspectHosts()} · card rilevate ${if (cards < 0) "-" else cards}"
    }

    // ------------------------------------------------------------------
    // Esportazione: tre file in Download/SubitoPlus, leggibili da qualsiasi
    // file manager e condivisibili in chat senza permessi aggiuntivi.
    // ------------------------------------------------------------------
    private fun esporta() {
        val ok = listOf(
            scriviInDownload("requests.json", RequestLog.requestsJson()),
            scriviInDownload("blocklist.json", RequestLog.blocklistJson()),
            scriviInDownload("selectors.json", ultimoReportDom)
        ).all { it }
        toast(if (ok) "Esportati in Download/SubitoPlus" else "Esportazione non riuscita")
    }

    private fun scriviInDownload(nome: String, contenuto: String): Boolean = try {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nome)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/SubitoPlus")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
        uri?.let {
            contentResolver.openOutputStream(it, "wt")?.use { os ->
                os.write(contenuto.toByteArray(Charsets.UTF_8))
            }
            true
        } ?: false
    } catch (t: Throwable) { false }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
