package it.zecchi.subitoplus

/*
 * Subito+ / Fase 0 "Sonda" — rilevamento della struttura della pagina
 * v0.1.0 (2026-08-30)
 *
 * Questo script viene iniettato a pagina caricata e risponde a due domande
 * da cui dipende tutta la Fase 2:
 *   1) qual e' l'ancora stabile per riconoscere una card annuncio e il suo ID
 *   2) quale antenato della card va nascosto per non lasciare buchi nel layout
 * In piu' segnala i contenitori pubblicitari rimasti nel DOM (filtri cosmetici, Fase 1).
 *
 * Nota sintassi: niente template literal e niente simbolo dollaro nel JS,
 * perche' la stringa e' un raw string Kotlin.
 */
object DomProbe {

    val SCRIPT: String = """
    (function () {
      function cls(el) {
        try { return String(el.className || '').trim().slice(0, 160); } catch (e) { return ''; }
      }
      function datasetOf(el) {
        var out = {};
        try {
          for (var i = 0; i < el.attributes.length; i++) {
            var a = el.attributes[i];
            if (a.name.indexOf('data-') === 0 || a.name === 'id' || a.name === 'role')
              out[a.name] = String(a.value).slice(0, 120);
          }
        } catch (e) {}
        return out;
      }
      function chain(el, up) {
        var out = [], cur = el;
        for (var i = 0; i < up && cur; i++) {
          out.push({ tag: cur.tagName, cls: cls(cur), attrs: datasetOf(cur) });
          cur = cur.parentElement;
        }
        return out;
      }

      var report = { url: location.href, titolo: document.title, ts: Date.now() };

      /* --- 1. card annuncio: ancora sul link /vi/<id>.htm --- */
      var re = /\/vi\/(\d+)\.htm/;
      var links = Array.prototype.slice.call(document.querySelectorAll('a[href]'));
      var cards = [];
      for (var i = 0; i < links.length; i++) {
        var m = re.exec(links[i].getAttribute('href') || '');
        if (m) cards.push({ id: m[1], el: links[i] });
      }
      report.cardTrovate = cards.length;
      report.campioni = [];
      for (var j = 0; j < Math.min(cards.length, 4); j++) {
        report.campioni.push({
          idAnnuncio: cards[j].id,
          href: (cards[j].el.getAttribute('href') || '').slice(0, 200),
          antenati: chain(cards[j].el, 6)
        });
      }

      /* --- 2. marcatori "sponsorizzato" dentro le card --- */
      var spon = [];
      var tutti = document.querySelectorAll('*');
      var parole = ['sponsor', 'promoss', 'in evidenza', 'pubblicit', 'advert'];
      for (var k = 0; k < tutti.length && spon.length < 12; k++) {
        var t = (tutti[k].childElementCount === 0) ? (tutti[k].textContent || '') : '';
        t = t.trim().toLowerCase();
        if (t && t.length < 40) {
          for (var p = 0; p < parole.length; p++) {
            if (t.indexOf(parole[p]) >= 0) {
              spon.push({ testo: t.slice(0, 40), tag: tutti[k].tagName, cls: cls(tutti[k]),
                          antenati: chain(tutti[k], 4) });
              break;
            }
          }
        }
      }
      report.marcatoriSponsor = spon;

      /* --- 3. contenitori pubblicitari: iframe di terze parti e id/classi parlanti --- */
      var ads = [];
      var iframes = document.querySelectorAll('iframe');
      for (var f = 0; f < iframes.length; f++) {
        var src = iframes[f].getAttribute('src') || '';
        ads.push({ tipo: 'iframe', src: src.slice(0, 160), cls: cls(iframes[f]),
                   antenati: chain(iframes[f], 3) });
      }
      var sospetti = document.querySelectorAll(
        '[id*="ad-"],[id*="ads"],[id*="banner"],[class*="ad-"],[class*="ads"],[class*="banner"],[class*="Adv"],[data-testid*="ad"]'
      );
      for (var s = 0; s < sospetti.length && ads.length < 30; s++) {
        var r = sospetti[s].getBoundingClientRect();
        ads.push({ tipo: 'nodo', tag: sospetti[s].tagName, cls: cls(sospetti[s]),
                   id: sospetti[s].id || '', w: Math.round(r.width), h: Math.round(r.height) });
      }
      report.contenitoriAdv = ads;

      /* --- 4. stato sessione: utile per capire se il login regge nel WebView --- */
      report.cookieAbilitati = navigator.cookieEnabled;
      report.userAgent = navigator.userAgent;
      report.scrollInfinito = document.querySelectorAll('[class*="infinite"],[class*="pagination"]').length;

      try { SondaBridge.report(JSON.stringify(report)); } catch (e) {}
    })();
    """.trimIndent()
}
