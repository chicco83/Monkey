// Subito+ — script radice
// v0.1.0 (2026-08-30)
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
